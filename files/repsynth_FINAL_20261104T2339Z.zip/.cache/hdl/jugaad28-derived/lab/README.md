# The low-cost laboratory

A complete digital flow with no licensed tool and no foundry relationship,
running on an ordinary laptop. This is the Holy Grail lab pattern for
silicon: repeatable, local, and sufficient to reach a signed-off GDSII on an
open PDK.

## What the container carries
- RTL entry and linting
- simulation and coverage
- synthesis to an open standard-cell library
- floorplan, place and route
- DRC and LVS
- GDSII out, and a report set at each rung

Every tool in it is free software. No step requires a licence server.

## What it does not carry, stated plainly
- No foundry PDK. The flow targets an open PDK only.
- No commercial simulator, synthesiser or signoff tool.
- No analogue or RF signoff. The analogue and mixed-signal descriptors
  (J28-004, 005, 007, 008, 009, 010, 011, 013) reach SPICE and schematic
  level in this lab and no further. Their PHYSICAL rung needs tooling this
  container does not have, and that is recorded rather than glossed.
- No shuttle booking, and no cost figure. Multi-project wafer pricing and
  access terms change, and we have not verified any of it. Every cost field
  in the catalogue reads `not established` for that reason.

## Build
    cd lab && docker build -t jugaad28-lab .
    docker run --rm -it -v "$PWD/..":/work jugaad28-lab

## Rung reachability in this lab
| rung | digital | analogue and mixed-signal |
|---|---|---|
| CONCEPT   | yes | yes |
| SPEC      | yes | yes |
| RTL       | yes | schematic and SPICE |
| VERIFIED  | yes | SPICE only |
| PHYSICAL  | yes, open PDK | no |
| SIGNOFF   | yes, open PDK | no |
| TAPEOUT   | no, needs a shuttle | no |
| SILICON   | no | no |

A rung marked no here is not a rung you can claim. See CONTRACT J3.
