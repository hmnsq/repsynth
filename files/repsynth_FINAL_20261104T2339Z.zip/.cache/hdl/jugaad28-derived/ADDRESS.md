# An address to the ecosystem

Silicon is where most architectures stop. Not because the ideas run out, but
because the flow between an idea and a taped-out die is held privately: the
process files, the tool licences, the shuttle access, the figures. A
researcher with a good architecture and no foundry relationship has nowhere
to put it.

jugaad28 is the opposite arrangement. The catalogue is open. The rung model
is open. The laboratory runs on an open PDK on a laptop. Every claim carries
the artefact that establishes it, and every hole says it is a hole.

Three things are asked of anyone who takes this up.

**Declare your substrate.** A 28 nm bulk CMOS flow is not a wish. It makes
digital, analogue, mixed-signal, sub-6-GHz RF and CMOS-compatible
neuromorphic devices. It does not make qubits, photonics, III-V or MEMS.
Those are welcome here and they declare their own substrate and their own
tapeout path. Conflating them is the single most common way silicon work
becomes unbuildable.

**Climb the rungs.** CONCEPT, SPEC, RTL, VERIFIED, PHYSICAL, SIGNOFF,
TAPEOUT, SILICON. Each one needs the evidence of the one below. A descriptor
at VERIFIED with no testbench is not at VERIFIED; the tool will say so and
refuse. This is not bureaucracy. It is the difference between a catalogue and
a wish list.

**Leave the holes open.** `not established` is a legitimate and final answer.
It is better than a plausible number, and it is far better than a number
inherited from a document you were not free to read. Unknown refuses
arithmetic here, so a hole cannot be quietly summed into a margin.

What you get in return is a laboratory: a dockerised open-PDK flow, a
descriptor schema, a validator that enforces the eight invariants, a rung
gate, and a set of descriptor stubs across fourteen IC classes that you can
fork, fill and take to a shuttle. Take one class. Fill it to SPEC. Push it
back, or do not, and build it yourself. Both are the point.

The architecture is federated. The estate does not need to own your work for
your work to belong to the ecosystem.

Build on what exists. Enable what is possible. Together.
