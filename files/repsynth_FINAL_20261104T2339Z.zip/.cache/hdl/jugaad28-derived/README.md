# jugaad28

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.22818408.svg)](https://doi.org/10.5281/zenodo.22818408)


Integrated circuits that can be taped out on a 28 nm process, held as
machine-checkable descriptors with an evidence-gated rung model, plus a
low-cost open laboratory that takes any of them from descriptor to signed-off
GDSII on a laptop.

**Nothing in this catalogue has been fabricated.** Every unestablished field
reads `not established`, and `not established` refuses arithmetic.

## The boundary this repo states on its face

A 28 nm bulk CMOS logic process does not produce qubits. What it produces,
and what this catalogue carries, is the cryogenic CMOS control and readout
that sits at 4 K beside a qubit array on a different substrate. The same
applies to silicon photonics, III-V, MEMS and ternary MTCMOS cells. Each of
those is present as a `tapeout_path: separate` descriptor so the distinction
cannot quietly collapse.

## Fourteen classes

Digital: RV64GC application core, systolic matrix accelerator.
Neuromorphic: CMOS-compatible spiking array, resistive crossbar macro
(separate substrate).
Quantum-adjacent: cryogenic control and readout ASIC, and the
superconducting qubit array as a boundary marker (separate substrate).
Analogue and mixed-signal: 12-bit pipelined ADC, fractional-N PLL, 10 Gbps
SerDes, sub-6 GHz RF front-end, neural recording front-end.
Infrastructure: PUF and TRNG with crypto accelerator, power management.
Emerging: ternary MTCMOS test macro (separate substrate).

    python3 ops/jugaad28.py report

## The eight rungs

CONCEPT, SPEC, RTL, VERIFIED, PHYSICAL, SIGNOFF, TAPEOUT, SILICON.

A rung is climbed, never claimed. Promotion needs the evidence of the rung
below it, named in the descriptor. The validator refuses; it does not warn.
Every descriptor currently stands at CONCEPT, because none of them has a
spec artefact yet, and saying so is the point.

## The eight invariants

J1 a number without evidence is not a number · J2 Unknown refuses arithmetic ·
J3 a rung is climbed, never claimed · J4 the substrate is declared and the
process cannot be wished · J5 no vocabulary leak · J6 an edge is declared at
both ends or it is OWED · J7 every descriptor names its enablement ·
J8 nothing proprietary enters this repo.

    bash ops/verify.sh

## The laboratory

    cd lab && docker build -t jugaad28-lab . && docker run --rm -it -v "$PWD/..":/work jugaad28-lab

Open toolchain only. `lab/README.md` states which rungs it can reach for
digital and which it cannot reach for analogue, and it does not quote a
shuttle price, because we have not verified one.

## Contributing

Take one class. Fill it to SPEC with evidence. Leave the holes reading
`not established`. Work packages are `cyclers/*.pni`. Read `AGENTS.md` first.

Push and mint are the author's typed gates. They are not delegated.

See `ADDRESS.md` for why this repository is arranged the way it is.

<!-- trademarks:begin -->
---
AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary in India, used and claimed worldwide since
2019. The names of his products and projects are his trademarks; see [legal/TRADEMARKS.md](legal/TRADEMARKS.md). Code
licences in this repository grant copyright permissions only and no right in any mark.
© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.
<!-- trademarks:end -->
