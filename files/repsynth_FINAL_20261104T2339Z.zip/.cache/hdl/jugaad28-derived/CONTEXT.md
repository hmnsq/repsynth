# CONTEXT: zistgah/jugaad28

## What this is
A catalogue of integrated circuits that can be taped out on a 28 nm process,
held as machine-checkable descriptors with a rung model, and a low-cost
laboratory pattern that lets a collaborator take any one of them from
descriptor to silicon without asking permission.

It is a catalogue and a gate, not a chip. Nothing here has been fabricated.
Every unestablished field reads `not established`.

## Where it sits in the ecosystem
- `zistgah` is the habitat envelope. jugaad28 is an element within it.
- `zistgah/dhancha` is the domain-invariant spine. jugaad28 SHARES the
  `core.unknown` primitive and the idea of evidence-gated rungs. It does NOT
  share dhancha's workflow, state model or invariants, per dhancha's own D9:
  the engine is common, the workflow is not. jugaad28 authors its own eight
  rungs and its own eight invariants.
- `zistgah/zamin` owns the ternary MTCMOS hardware stack, the TEL
  accumulator, the CDM crossbar, TSV routing and the thermal and
  microfluidic work. jugaad28 does not duplicate it. Where the two meet,
  the edge is declared. zamin's end of that edge is OWED.
- `zistgah/asab` (zasab) is the embedded device-control spine, ESP32 and HAL,
  and ports to ASICs. jugaad28 is where such an ASIC is specified. Edge
  declared, far end OWED.
- `zistgah/pratik` is computational realisation; `zistgah/fakir` is the
  domain lattice. An IC in this catalogue is a realisation target reachable
  from a FAKIR lattice point, not a domain of its own.
- QNBCI (quantum neuromorphic BCI) contributes the neural front-end and the
  cryogenic control requirement. Edge declared, far end OWED.

## The honest correction this repo carries on its face
"Quantum chips on 28 nm" conflates two different artefacts. A 28 nm bulk CMOS
logic process does not produce qubits. What it does produce, and what is
genuinely valuable, is the cryogenic CMOS control and readout electronics
that sit at 4 K beside a qubit array on a different substrate. Both are in
this catalogue. They are not the same descriptor and they do not share a
tapeout path. The same applies to silicon photonics, III-V and MEMS.

## Who this is for
Any collaborator domain on the Humanesque Collaborator Domain Map whose work
reaches silicon. The invitation is a reproducible laboratory for their own
work, not a request to join an architecture.

## What is NOT here, stated plainly
No foundry PDK. No vendor process file. No NDA figure. No fabricated area,
power or yield number. No taped-out part. No shuttle booking. No cost quote.
The economics in `lab/README.md` are open-source-flow economics only, and
the MPW figures are marked `not established` because they change and we have
not verified them.
