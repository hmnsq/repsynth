# AGENTS.md: zistgah/jugaad28

Read `CONTRACT.md` and `CONTEXT.md` before touching anything. Then read the
master contract at `zistgah/governance`.

## Before you start
1. Build context: this repo canonical at `/shared/estate/github/zistgah/jugaad28`,
   else clone from the forge. Never edit canonical in place (C38).
2. `bash ops/selftest.sh` must be green before and after your change.
3. `python3 ops/jugaad28.py check` must be green before you push anything.

## What you may do without asking
- Fill fields in an existing descriptor, WITH evidence (J1).
- Add a descriptor for an IC class not yet present, at rung CONCEPT or SPEC.
- Add a test.
- Add a lab recipe under `lab/` for an open toolchain.

## What you may not do
- Promote a rung without the evidence of the rung below (J3).
- Write a number without an evidence reference (J1).
- Put a foundry PDK, vendor process file or NDA figure anywhere (J8).
- Sum across an Unknown (J2).
- Use another element's vocabulary without declaring the edge (J5).
- Push or mint. Only the author does that, under a typed gate.

## Handover
Bounded work packages are `cyclers/*.pni` (PANINI). One package, one
descriptor, one rung, one acceptance criterion. Take a package, fill it,
return the descriptor and its evidence.
