# CONTRACT: zistgah/jugaad28

This is a THIN OVERLAY on the master contract at `zistgah/governance/CONTRACT.md`.
It ADDS constraints. It never relaxes one.

Master clauses 1-12 and C31-C38 apply in full, in particular:
clause 1 sole author / AyeAI affiliation only · clause 3 no fabrication ·
clause 4 verify by execution · clause 5 read before write · clause 6 gated
irreversibility · clause 8 provenance travels · C31 retrieval before
assumption · C37 never bluff · C38 build context before you touch a repo.

## Added clauses

**J1. A number without evidence is not a number.**
Every numeric field in a descriptor (area, power, frequency, yield, cost)
carries an `evidence` reference naming the artefact that establishes it. A
field with no evidence reads `not established` and is stored as Unknown. A
figure quoted from a foundry document under NDA is not evidence; it is a
disclosure violation and does not enter this repo.

**J2. Unknown refuses arithmetic.**
`not established` is not zero. No budget, total, margin or score may be
computed across a descriptor containing an Unknown in the summed field. The
computation refuses and names the holes. Shares the primitive with
`zistgah/dhancha core.unknown`; it does not share dhancha's architecture.

**J3. A rung is climbed, never claimed.**
CONCEPT → SPEC → RTL → VERIFIED → PHYSICAL → SIGNOFF → TAPEOUT → SILICON.
Promotion to a rung requires the evidence of the rung below it to be present
and named. A descriptor that claims a rung without that evidence fails
validation. It does not warn.

**J4. The substrate is declared, and the process cannot be wished.**
Every descriptor declares `substrate`. A 28 nm bulk CMOS logic flow produces
digital, analogue, mixed-signal, RF-to-sub-6-GHz and CMOS-compatible
neuromorphic devices. It does not produce superconducting qubits, spin-qubit
host wafers, silicon photonics, III-V devices, MEMS or ternary MTCMOS cells.
Any of those declares its own substrate explicitly and is marked
`tapeout_path: separate`. A descriptor claiming 28 nm bulk CMOS for a class
the flow cannot produce fails validation.

**J5. No vocabulary leak.**
A descriptor may not wear another estate element's vocabulary without a
declared edge. `zistgah/zamin` owns ternary MTCMOS, the TEL accumulator, the
CDM crossbar, TSV routing and the thermal and microfluidic stack. If jugaad28
touches those terms it declares `edges: [zistgah/zamin]` and says at which
interface. Enforced as a test, not a review.

**J6. An edge is declared at both ends, or it is OWED.**
A declared edge whose far end does not yet declare it back is reported as
OWED, with the repo and the reason. It is not silently accepted and it is not
treated as a failure, because the far end may not yet be pushed.

**J7. Every descriptor names its enablement.**
What a collaborator in that IC's field actually gets: the lab, the flow, the
artefacts, the acceptance criteria. Boilerplate fails. An empty enablement
fails.

**J8. Nothing proprietary enters this repo.**
No foundry PDK, no vendor process file, no NDA figure, no licensed IP, no
netlist derived from any of them. The repo carries open-PDK targets and its
own RTL only. `ops/jugaad28.py check` refuses on any known proprietary PDK
name.

Reconstruct faithfully. Critique with evidence, not tone.
Maintain contract and context.
