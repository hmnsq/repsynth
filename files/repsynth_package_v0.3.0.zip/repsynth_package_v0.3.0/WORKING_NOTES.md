# Working notes for package repsynth 0.3.0

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

Not print-ready. Status and instructions the filed documents do not carry.

## Rulings recorded on 4 November 2026

- Repository names accepted as suggested, projection names included (RD1, RD2, RD10).
- Reference-unit memory: P0.6 measures it (RD4).
- Binary and balanced ternary: decided at your request (RD5). Both run. Binary is the performance baseline every figure is reported beside; balanced ternary is the representation-change demonstrator. One parametric Tier B family produces both machines, and the mechanical lane has adders for both.
- Every other decision stands as a working decision for the build. You review them once you see the build running; nothing waits on you before then.

## Speech-interface corrections applied

- Paris read as paras; P.6 as P0.6; balance ternary as balanced ternary; Shakti as SHAKTI.

## Starting order

- Small, self-contained packets suit any implementer, including one that is weaker at integration: P1.3, P1.4, P9.2, P9.3 and P9.6 are specifications and oracles with exhaustive or analytic acceptance.
- Integration packets need the stronger implementer: P0.1 (containers and doctor), P9.1 (BURP probe and container), P9.4 (shared core).
- Every packet is judged by its acceptance command, so work from different implementers is judged the same way.

## Not in this package, on purpose

- The ILM packets and the FAKIR packets.
- Which agents run on your laptop, and how the AI resources are routed.
- Crowdsourcing and monetisation.

## What is not established

- BURP's coverage of JavaScript (P9.1 probes it first).
- SHAKTI's extension mechanism (P5.6 reads it).
- NI2A2 (a conversation summary only), MSRR (not in your record) and the three R2 assets.

## What changed from 0.2.0

- Document 00, the Sovereignty Architecture: the whole stack bottom-up, how this build complements paras and SHAKTI, and the build matrix.
- Rulings applied; every decision now carries a state (ruled, measured, decided, working, or your act at release).
- Binary performance baseline: NUM-06, P4.13, P5.11, D14, T-28, T-29. Both Tier B machines: ISB-01, P7.1 to P7.5. Binary and ternary mechanical adders: MEC-03, P10.3.
- New requirements INT-11 (binary and ternary) and INT-12 (every build cell separately buildable).
- Corrected: the MRD summary still said seven demonstrators; there are fourteen.
