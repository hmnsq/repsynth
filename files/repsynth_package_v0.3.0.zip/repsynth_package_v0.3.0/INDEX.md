# Package repsynth 0.3.0

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

| File | What it is |
|---|---|
| 00_Sovereignty_Architecture_v0.3.0.docx | The whole stack, bottom-up: layers, what paras, Parashakti and SHAKTI provide, what this build adds, and the build matrix. |
| 01_MRD_repsynth_v0.3.0.docx | Market requirements document: what is required, and why. Supersedes 0.1.0 and 0.2.0. |
| 02_Implementation_Guidelines_v0.3.0.docx | How it is built: rules, library admission, numerical methods, element catalogues, formats, protocol. |
| 03_Repository_Map_v0.3.0.docx | Repository names (accepted), organisations, dependencies, projection names, seeding order. |
| 04_Build_Plan_v0.3.0.docx | Tracks, milestones, iterations and every packet with its acceptance condition. |
| 05_Test_Plan_v0.3.0.docx | Test levels, oracles, tolerances, the test catalogue, mutation and ingestibility testing. |
| briefs/brief_track_H_iteration_I1.md | First-person brief for the harness implementer. |
| briefs/brief_track_S_iteration_S1.md | First-person brief for the simulator implementer. |
| data/*.csv | Requirements, packets, tests, milestones, iterations, repositories and traceability, as data. |
| WORKING_NOTES.md | Rulings recorded, starting order, what is left out on purpose. Not print-ready. |
| MANIFEST.sha256 | SHA-256 of every other file in the package. |

Requirements: 163. Packets: 102. Tests: 61. Demonstrators: 14. Decisions: 14, each with its state.
