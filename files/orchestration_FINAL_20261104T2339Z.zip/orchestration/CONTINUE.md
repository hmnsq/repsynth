<!-- © 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI. SPDX-License-Identifier: CC-BY-SA-4.0 -->
# How to continue from any checkpoint

1. Unzip each repository zip into its own folder (repsynth/, subcore/, mechsim/, anasim/). Each is a git
   repository: the zip carries .git, so `git log` shows every step and nothing is lost.
2. Read, in order: the repository's RESUME.md (generated packet states with evidence), reports/status/*.json,
   reports/completion/*.md, and the latest files in records/ (run records with commands and exit codes).
3. The board across repositories: `python3 orchestration/board.py -v` (in the orchestration zip).
4. Rerun anything: `ops/run.sh --iteration <N>` (containers) or `ops/run.sh --iteration <N> --native`.
   Iterations: plan/iterations.csv; steps: ops/iterations/<N>.steps. Runs resume without repeating steps.
5. The resumption point is the first packet in RESUME.md whose state is not `done`, in Build Plan order,
   respecting each packet's prerequisites (plan/packets.csv).
6. Large upstream sources (QEMU, Linux, binutils, Embench, cores) are not in the zips; each lane fetches its
   pinned commit again on first run (recorded in records/ and reports/).
