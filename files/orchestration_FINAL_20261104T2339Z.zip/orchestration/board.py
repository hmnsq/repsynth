# © 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.
# SPDX-License-Identifier: GPL-3.0-or-later
"""Aggregate packet states across the four repositories against the Build Plan."""
import csv, json, sys
from pathlib import Path
B = Path(__file__).resolve().parent.parent
rows = list(csv.DictReader(open(B / "orchestration/package/data/packets.csv", encoding="utf-8")))
repo_of = {"hmnsq/repsynth": "repsynth", "hmnsq/subcore": "subcore", "hmnsq/mechsim": "mechsim", "hmnsq/anasim": "anasim", "hmnsq/optisim": "repsynth"}
counts, lines = {}, []
for r in rows:
    repo = next((v for k, v in repo_of.items() if r["repository"].startswith(k)), "repsynth")
    f = B / repo / "reports/status" / f"{r['id']}.json"
    st = json.loads(f.read_text())["state"] if f.exists() else "not_built"
    s = json.loads(f.read_text()).get("summary", "") if f.exists() else ""
    counts[st] = counts.get(st, 0) + 1
    lines.append(f"{r['id']:7s} {repo:9s} {st:15s} {r['title'][:50]:50s} {s[:110]}")
print(" ".join(f"{k}={v}" for k, v in sorted(counts.items())), f"total={len(rows)}")
if "-v" in sys.argv:
    print("\n".join(lines))
