#!/usr/bin/env bash
# © 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.
# SPDX-License-Identifier: GPL-3.0-or-later
# Self-contained checkpoint: each repository's whole working tree with its .git history, generated
# artefacts (out/), run logs (.cache/logs, lane logs), records and reports; plus the orchestration folder.
# Excludes only re-fetchable upstream sources and build trees.
set -uo pipefail
cd "$(dirname "$0")/.."
TAG="${1:-checkpoint}"
STAMP="$(date -u +%Y%m%dT%H%MZ)"
mkdir -p deliverables
for r in repsynth subcore mechsim anasim; do
  [ -d "$r/.git" ] || continue
  (cd "$r" && { [ -f repsynth/report.py ] && python3 -m repsynth report >/dev/null 2>&1; } || true)
  out="deliverables/${r}_${TAG}_${STAMP}.zip"
  (cd "$r" && {
     git ls-files -co --exclude-standard
     find .git -type f
     [ -d out ] && find out -type f -size -5M -not -path "out/mutants/*"
     [ -d .cache ] && find .cache -type f \( -name "*.log" -o -name "*.out" -o -name "*.txt" -o -name "*.json" -o -name "*.md" \) -size -2M \
          -not -path "*/qemu-*/*" -not -path "*/linux-*/*" -not -path "*/binutils-*/*" -not -path "*/assets/*" \
          -not -path "*/embench-iot/*" -not -path "*/riscv-opcodes/*" -not -path "*/xv6-riscv/*" -not -path "*/ccache/*" \
          -not -path "*/node_modules/*" -not -path "*/site-packages/*" 2>/dev/null
     [ -d node_modules ] && true
   } | sort -u | zip -q -X -@ "../$out")
  echo "$out $(du -h "$out" | cut -f1) $(cd $r && git rev-parse --short HEAD 2>/dev/null)"
done
python3 orchestration/board.py -v > orchestration/BOARD.txt 2>&1 || true
zip -q -r -X "deliverables/orchestration_${TAG}_${STAMP}.zip" orchestration -x "orchestration/package/*.docx" -x "orchestration/grok_I1_S1/*"
echo "deliverables/orchestration_${TAG}_${STAMP}.zip"
