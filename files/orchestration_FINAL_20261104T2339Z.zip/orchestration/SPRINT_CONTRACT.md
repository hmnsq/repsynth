# Sprint contract for every worker on this build

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

You are one worker in a coordinated build of package repsynth 0.3.0. An orchestrator owns the spine and
assigns you a lane. Read this file completely, then your assignment, before you write anything.

## 1 Sources of truth (read before writing)

- `/home/user/build/orchestration/package/` holds the package. Markdown reading copies of documents 00 to 05
  sit beside the .docx files (`00_Sovereignty_Architecture_v0.3.0.md`, `01_MRD_repsynth_v0.3.0.md`,
  `02_Implementation_Guidelines_v0.3.0.md`, `03_Repository_Map_v0.3.0.md`, `04_Build_Plan_v0.3.0.md`,
  `05_Test_Plan_v0.3.0.md`). `data/*.csv` holds requirements, packets, tests and traceability as data.
- The MRD governs. The Build Plan's `accepted_when` column (data/packets.csv) is the acceptance test for
  each packet. The Test Plan section 5 gives the numeric tolerances.
- `/home/user/build/orchestration/grok_I1_S1/` holds an earlier attempt by another implementer. It has
  known defects (placeholder vectors with `"expected": "ref"`, a validator that accepts guessed values,
  a run.sh that takes `--iteration` as the iteration name, a substrate schema its own specs fail, a BURP
  probe that writes a fake result to the wrong path). Reuse nothing from it without checking it.

## 2 Workspace

- Repositories (local git, branch main; commit often with clear messages; never push):
  `/home/user/build/repsynth`, `/home/user/build/subcore`, `/home/user/build/mechsim`, `/home/user/build/anasim`.
- Touch only the repository and the paths your assignment names. Other workers are editing the other
  paths at the same time. If you need something from another lane, read it; do not edit it. If it is
  missing, record the dependency in your report and carry on with what it does not block.
- Large downloaded sources and build trees (QEMU, binutils, Linux, xv6, cores, Embench, vendored
  library checkouts) go under `<repo>/.cache/<name>/` which is git-ignored. Generated, small, reviewable
  outputs go in the tree.
- Never write to /tmp. Use `<repo>/.cache/tmp/`.
- Machine: 4 processors, 15 GB memory. Use `make -j3` at most so other lanes still run. A long build
  goes in the background with its log in `<repo>/.cache/logs/`; poll it, do not sleep blindly for long.

## 3 Tools available here

- Installed natively: gcc, clang, lld, wabt, ninja, cmake, make, git, node 22, python 3.13 with jsonschema,
  pyyaml, hypothesis, z3-solver, mpmath, cocotb, cffi, burp-ilm (`burp`), paras-ilm (`paras`);
  qemu-user and qemu-system-misc (Ubuntu QEMU 8.2), gcc-riscv64-linux-gnu, gcc-riscv64-unknown-elf with
  picolibc, verilator 5.020, ghdl 4.1, yosys 0.33, iverilog, ngspice 42, nextpnr-ice40, fpga-icestorm.
- `apt-get install` and `pip install` work for standard packages. npm registry works. crates.io works.
- GitHub: `git clone` over https works for public repositories (use `--depth 1` or pinned shallow fetches).
  Web/API access to github.com (curl, gh api) is blocked. GitLab web returns redirects; prefer GitHub mirrors.
- Docker works (`docker build`, `docker run`). Docker Hub may answer 429: use `mirror.gcr.io/library/<image>`
  as the base, with the upstream name in a comment. Inside `docker build`, outbound network needs the
  proxy: pass `--network host --build-arg http_proxy --build-arg https_proxy` and the CA bundle
  `/root/.ccr/ca-bundle.crt`; keep that in an optional build hook so the author's machine (no proxy) is unaffected.
- The author's own repositories are public and are oracles, read only: hindawiai/hindawi2026.10,
  hindawiai/chintamani, project-ilm/romenagri2026.10, hmnsq/paras, hmnsq/burp, zistgah/paniniq,
  zistgah/zamin, zistgah/jugaad28, zistgah/dhancha, zistgah/tajziya, project-ilm/ilm.codes,
  project-ilm/chandah, project-ilm/qedler, ayevdi/ayevdi.

## 4 Rules that are never relaxed

1. Done means executed. A packet is `done` only if its acceptance command ran here and passed. Otherwise
   it is `wired_unproven` (code exists, acceptance not run or not passing) or `not_built`. Never claim more.
2. Nothing pretends. An unimplemented function raises. No placeholder expected values. No fake outputs.
   Every gate is shown refusing a planted defect before it is trusted (record that run).
3. Failures are shown: command, exit code and the relevant output, in the report.
4. We do not reinvent the wheel: drive QEMU, binutils, GCC, Verilator, GHDL, Yosys, nextpnr, ngspice,
   OpenModelica, math.js etc. Read a tool's --help or source before driving it (GOV-15); never recall flags
   or patch anchors from memory without checking.
5. Legacy and the author's repositories are read only. Never edit a clone; derived builds live elsewhere.
   Record each clone's commit and tree hash before and after.
6. Every file you create starts with the copyright line
   `© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.` and an SPDX identifier
   (software GPL-3.0-or-later; schemas and data CC0-1.0; documents CC-BY-SA-4.0; files compiled into
   QEMU or Linux GPL-2.0-or-later; into binutils or GCC GPL-3.0-or-later). In JSON files, put these in a
   `"_notice"` key or a sidecar; in CSV a leading `#` comment line.
7. No AI or model name appears anywhere in the trees (no "Claude", "Grok", "GPT", "AI-generated", in code,
   comments, commit messages or reports). Commits are authored as the repository's configured user.
8. British spelling, plain prose, no em dashes.
9. Generation is deterministic: no timestamps inside generated files; generated files carry the
   specification hash and generator version. Run records may carry UTC ISO 8601 times.
10. JavaScript (Track S): plain ES2020 modules, no build step, relative imports with extensions, no eval
    or new Function, no Math.random, numerical modules never touch the DOM, vendored libraries as
    readable source under `docs/vendor/<name>/<version>/` with LICENCE and PROVENANCE, never edited.

## 5 Shared interfaces (fixed by the orchestrator; do not change them, ask instead)

### 5.1 Vector files (CNF-01)

Path: `repsynth/conformance/vectors/<spec_id>/<op>.<width>.vec`. Plain text:

```
# repsynth-vectors 1
# spec: <spec_id>
# version: <spec version>
# spec_sha256: <hex of canonical spec>
# op: <op name>
# width: <digits> (<register bits>-bit register)
# fields: <in1> <in2> -> <out>
# generator: repsynth.vectors <version>
# cases: <n>
<hex> <hex> <hex>
```

Every field is a lower-case hexadecimal unsigned integer of the register width (no 0x). Unary operations
have one input field. Comment lines start with `#`.

### 5.2 Reference functions (SPC-03)

`repsynth/spec/ref/<spec_id>/<spec_id>.h` and `.c`: restricted C11, pure, `<stdint.h>` types only.
Each operation is `uint64_t <prefix>_<op><width>(uint64_t a, uint64_t b)` (unary ops ignore b), so every
runner (native, WebAssembly, Python, QEMU helper, cocotb) calls one uniform signature. The spec's
`operations[].reference.symbol` names the function.

### 5.3 Run records (PRV-01) and packet status

- Every lane command writes `<repo>/records/<UTC compact time>_<packet>_<step>.json` with keys:
  `packet`, `step`, `command`, `exit_code`, `started_utc`, `finished_utc`, `inputs` (path to sha256),
  `outputs` (path to sha256), `tool_versions` (name to version string), `image_digests`, `results`,
  `state` (one of `done`, `wired_unproven`, `not_built`, `failed`), `notes`.
  Python helper: `repsynth/repsynth/records.py` (`write_record(...)`); JS repos have their own equivalent in
  `tools/record.mjs`.
- Packet status for RESUME.md: `<repo>/reports/status/<packet>.json` with keys `packet`, `state`,
  `evidence` (list of record paths), `summary` (one or two sentences), `blocked_by` (list or empty).
- Completion report per packet: `<repo>/reports/completion/<packet>.md` with the sections of MRD section 13:
  intent as written, commands run with exit codes, what was produced, what was not done, the test shown
  failing before it passed, what was reused (file and sha256), questions for the author.

### 5.4 Entry points

- repsynth: `python3 -m repsynth <subcommand>` (spine). Lanes add a module `repsynth/lanes/<lane>.py` with
  `def run(ctx) -> int` and register a subcommand in `repsynth/lanes/__init__.py` (the only shared file
  lanes may append to; append one line, do not rewrite it).
- Every repository: `ops/run.sh --iteration <N> [--native]`. Default runs inside the containers; `--native`
  runs on the current machine (this is how we run here). The iteration's steps are listed in
  `ops/iterations/<N>.steps`, one command per line, so each lane adds its own file.

## 6 How to finish

- Commit your work in small commits as you go.
- At the end, write your completion reports and status files, and reply to the orchestrator with: each
  packet and its honest state, the acceptance commands with exit codes, what is not done and why,
  and anything another lane needs from you. Keep the reply under 60 lines.
