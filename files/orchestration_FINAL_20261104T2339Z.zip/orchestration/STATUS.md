# Sprint status board (orchestrator)

Deadline for cloud credit: 07:59 UTC, 5 November 2026 (13:29 IST).

| Lane | Repository | Owner | State |
|---|---|---|---|
| Spine: meta-model, specs, refs, oracles, vectors, software conformance, mutation, dependency engine, runner, reports | repsynth | orchestrator | running |
| Intake, oracles, licences, host, received docs, extractions P1.5 to P1.8, SHAKTI and Panini Q readings | repsynth | worker: intake | running |
| Tier A: QEMU, ledger, insn, intrinsics, baseline, binutils, xv6, Linux, Hindawi path | repsynth | worker: tier A | running |
| Hardware: HDL units, cocotb, Yosys and nextpnr, core co-simulation, jugaad28 | repsynth | worker: hardware | running |
| Track S foundations (subcore) | subcore | worker: subcore | running |
| Mechanical simulator | mechsim | worker: mechsim | running |
| Analogue simulator | anasim | worker: anasim | running |
| Tier B machines | repsynth | worker: tier B | running |
| Script lane | repsynth | worker: script | running |
| Cross-substrate and quantum | repsynth | worker: xsc | running |
