**Build Plan**

Tracks, milestones, iterations and packets

*Package repsynth 0.3.0*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: defined. Generated from the same source as the other four
documents of the package.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 Purpose

3 Tracks

4 Milestones

5 Iterations

6 Packets

7 Critical path and parallel work

8 Resources

9 Definition of done

10 Hand-off for seeding

# 1 Document control

| **Item**   | **Value**                                                                                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title      | Build Plan                                                                                                                                              |
| Package    | repsynth 0.3.0, document 04; the package holds documents 00 to 05                                                                                       |
| Version    | 0.3.0, 4 November 2026                                                                                                                                  |
| Author     | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                   |
| Applies to | hmnsq/repsynth, hmnsq/subcore, hmnsq/mechsim, hmnsq/anasim, hmnsq/optisim                                                                               |
| Status     | Defined. Nothing described here is built; claims follow AyeKnow states.                                                                                 |
| Licences   | Documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0 (master contract clause 2).                                                 |
| Trademarks | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification. |

# 2 Purpose

This plan orders the work of the MRD into tracks, milestones, iterations
and packets. Every packet names its repository, prerequisites, outputs,
acceptance condition and capability labels. Acceptance is mechanical: a
command runs and its record decides.

# 3 Tracks

| **Track**     | **Repositories**                                                | **Milestones** | **Iterations** | **Joins**                                  |
|---------------|-----------------------------------------------------------------|----------------|----------------|--------------------------------------------|
| H, harness    | hmnsq/repsynth                                                  | M0 to M8       | I1 to I9       | J1 needs M4                                |
| S, substrates | hmnsq/subcore, hmnsq/mechsim, hmnsq/anasim; later hmnsq/optisim | M9 to M11; M13 | S1 to S6       | J1 needs M10 and M11                       |
| J, joint      | hmnsq/repsynth                                                  | M12            | J1             | Routed by the author to either implementer |

Each track has an external implementer, an AI system or a person; one
implementer may hold both. Both tracks can start on the same day.

# 4 Milestones

| **ID** | **Milestone**                                | **Repository** | **Prerequisites**                | **Closes with**                      |
|--------|----------------------------------------------|----------------|----------------------------------|--------------------------------------|
| M0     | Intake and baseline                          | hmnsq/repsynth | None                             | Asset register; oracle logs          |
| M1     | Specifications                               | hmnsq/repsynth | M0 for the legacy specifications | Specifications validate              |
| M2     | Software conformance                         | hmnsq/repsynth | M1                               | D1                                   |
| M3     | Dependency and impact                        | hmnsq/repsynth | M2                               | D2 over software                     |
| M4     | Tier A                                       | hmnsq/repsynth | M3                               | D3, D5; binary baseline counts       |
| M5     | Hardware                                     | hmnsq/repsynth | M4                               | D4; D2 again; D14                    |
| M6     | Script lane                                  | hmnsq/repsynth | M0                               | D6                                   |
| M7     | Tier B: binary and balanced ternary machines | hmnsq/repsynth | M4                               | D7                                   |
| M8     | Applications and release readiness           | hmnsq/repsynth | M3, M4 and every lane            | Release readiness                    |
| M9     | Substrate foundations                        | hmnsq/subcore  | None                             | BURP probe; core parity and accuracy |
| M10    | Mechanical simulator                         | hmnsq/mechsim  | M9                               | D8                                   |
| M11    | Analogue simulator                           | hmnsq/anasim   | M9                               | D9                                   |
| M12    | Cross-substrate compilation and quantum      | hmnsq/repsynth | M4, M10, M11                     | D10, D11                             |
| M13    | Optical (later)                              | hmnsq/optisim  | M12                              | D13                                  |

<img src="media/91320c86ff23a973daf9fa63764e83c7a273a296.png"
title="Build path" style="width:6.66667in;height:3.19792in"
alt="Figure 1. Build path in two tracks, joined at M12." />

*Figure 1. Build path in two tracks, joined at M12.*

# 5 Iterations

Each iteration closes with one command on the author’s machine, the
repository’s ops/run.sh, which runs everything inside its containers;
acceptance is read from that run’s records.

| **Iteration** | **Packets**                                                                | **Closes with**                                            |
|---------------|----------------------------------------------------------------------------|------------------------------------------------------------|
| I1            | P0.1, P0.4, P0.5, P0.6, P1.1 to P1.4, P2.1, and the code for P0.2 and P0.3 | Intake run; specifications without legacy code validated   |
| I2            | P1.5 to P1.8, P2.2 to P2.5                                                 | D1                                                         |
| I3            | P3.1 to P3.6                                                               | D2 over software artefacts                                 |
| I4            | P4.1 to P4.4, P4.12                                                        | Tier A in user mode; promotion report                      |
| I5            | P4.5 to P4.9, P4.13                                                        | D3, D5; binary baseline counts                             |
| I6            | P5.1 to P5.9, P5.11                                                        | D4; D2 over instruction and hardware artefacts; D14        |
| I7            | P6.1 to P6.7                                                               | D6                                                         |
| I8            | P7.1 to P7.5                                                               | D7                                                         |
| I9            | P8.1 to P8.5, P4.10, P4.11, P5.10                                          | Release readiness                                          |
| S1            | P9.1 to P9.4, P9.6, P9.7                                                   | BURP probe recorded; core parity and accuracy              |
| S2            | P9.5, P10.1 to P10.3, P11.1 to P11.3                                       | Reference containers; ideal mechanical and analogue models |
| S3            | P11.4 to P11.7, P11.9                                                      | Analogue references agree                                  |
| S4            | P10.4 to P10.8, P10.10                                                     | Mechanical references agree                                |
| S5            | P10.9, P11.8, P9.8, P10.11, P11.10                                         | D8, D9, D12; three repositories ready for seeding          |
| J1            | P12.1 to P12.6 (needs M4 of Track H)                                       | D10, D11                                                   |
| S6            | P13.1 (later)                                                              | D13                                                        |

# 6 Packets

## 6.1 M0 Intake and baseline

Repository: hmnsq/repsynth.

| **Packet**                                       | **Produces**                                                                                                                                                                                                                                                                                              | **Accepted when**                                                                                                                                                                                                  | **Labels**                |
|--------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|
| **P0.1** Containers and doctor                   | Dockerfiles for the containers of MRD section 9.7; repsynth doctor, timed, installing nothing on the host; doctor --build builds the containers once                                                                                                                                                      | doctor exits 0 and lists every container with its image digest and the time taken; every install step in the build log runs inside a container                                                                     | needs:code                |
| **P0.2** Intake of the author’s work. After P0.1 | repsynth intake: shallow, pinned clones of every asset in MRD section 7.1, discovered across the author’s organisations with paginated listing, using the GitHub CLI login handed into the container as paras does; a search for the three received-only assets; no token written to the tree or the logs | reports/asset_register lists every asset with its commit, or as not found with every place searched; every clone’s tree hash is unchanged after the run; no proposed repository name collides with an existing one | needs:code                |
| **P0.3** Oracle builds and runs. After P0.2      | Oracle runners for Hindawi (through the shaili drivers), Romenagri, APCISR and AyeHandSum                                                                                                                                                                                                                 | Each oracle’s run log records the commands, exit codes and outputs on its own samples; no finding says anything does not work without its command and output                                                       | needs:code, needs:testing |
| **P0.4** Licence intake. After P0.1              | reports/licences from each external tool’s own licence file, with SPDX identifiers                                                                                                                                                                                                                        | Every tool in MRD section 8 has a licence recorded from its own file, with the path                                                                                                                                | needs:code, needs:legal   |
| **P0.5** Received material                       | sources/ holding R1 and R2 as given, with hashes, a cleaned reading copy of each and the invisible-character report                                                                                                                                                                                       | The originals are byte-identical to what was received; the report lists every invisible character found                                                                                                            | needs:code                |
| **P0.6** Host profile. After P0.1                | reports/host: measured memory, processors, free disk and container storage                                                                                                                                                                                                                                | Memory, processors and disk are measured, and the measured memory settles decision RD4                                                                                                                             | needs:code                |

## 6.2 M1 Specifications

Repository: hmnsq/repsynth.

| **Packet**                                                          | **Produces**                                                                                           | **Accepted when**                                                                                                                                                                                                                                                                                                                  | **Labels**                 |
|---------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|
| **P1.1** Meta-model and validator                                   | spec/schema in JSON Schema 2020-12; the YAML loader; repsynth spec check; not_established handling     | The first specifications validate, and each planted defect is refused with its path named: a missing section, a guessed value in place of not_established, an undefined reference function                                                                                                                                         | needs:code, needs:ontology |
| **P1.2** Canonical form, paths and hashes. After P1.1               | The canonical serialiser, JSON Pointer paths and slice hashes                                          | Property tests show a slice hash unchanged by key order and whitespace and changed by any change of value                                                                                                                                                                                                                          | needs:code, needs:testing  |
| **P1.3** Balanced ternary. After P1.1                               | The specification with both trit encodings (NUM-02, NUM-03) and its reference functions                | Exhaustive checks over operands restricted to the low 12 trits for unary operations and the low 6 trits for binary operations, seeded random checks at full width and boundary cases all agree with the arbitrary-precision oracle; overflow, invalid codes and out-of-range conversion give the results the specification defines | needs:code, needs:proof    |
| **P1.4** Packed decimal and the binary integer baseline. After P1.1 | Both specifications with reference functions; the binary integer is the performance baseline (RD5)     | Exhaustive checks over 3-digit operand pairs and seeded random checks beyond agree with Python’s decimal module and native integer arithmetic                                                                                                                                                                                      | needs:code                 |
| **P1.5** Romenagri. After P0.3, P1.1                                | Extracted tables and transforms with provenance                                                        | Executing Romenagri on its corpus reproduces every extracted mapping; disagreements are resolved for the oracle and recorded                                                                                                                                                                                                       | needs:code, needs:testing  |
| **P1.6** APCISR, Devanagari. After P0.3, P1.1                       | The extracted grid instance with provenance, and the draft reading record of the 9-grid model for P6.1 | Executing APCISR on its corpus reproduces every extracted cell assignment                                                                                                                                                                                                                                                          | needs:code, needs:human    |
| **P1.7** AyeHandSum. After P0.2, P0.3, P1.1                         | The extracted encoding with provenance; the packet starts only once P0.2 has located the asset         | Executing AyeHandSum on its corpus reproduces every extracted rule                                                                                                                                                                                                                                                                 | needs:code                 |
| **P1.8** Hindawi pipeline descriptor. After P0.3, P1.1              | A descriptor of the composing pipeline as opaque transforms, per shaili                                | Forward and reverse runs through the shaili drivers on Hindawi’s own samples are recorded, and the descriptor names each transform with its driver                                                                                                                                                                                 | needs:code                 |

## 6.3 M2 Software and conformance

Repository: hmnsq/repsynth.

| **Packet**                                        | **Produces**                                                                                      | **Accepted when**                                                                                  | **Labels**                 |
|---------------------------------------------------|---------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------|----------------------------|
| **P2.1** Vector format and generator. After P1.2  | conformance/vectors from specifications: exhaustive enumerators, boundary and seeded random cases | Vector files carry the specification identifier, version and hash, and regenerate byte-identically | needs:code                 |
| **P2.2** Software builds. After P1.3 to P1.7      | Generated C for new specifications; unmodified legacy builds; WebAssembly and Python for both     | Every build succeeds in its container, and every legacy tree hash is unchanged after it            | needs:code                 |
| **P2.3** Differential runner. After P2.1, P2.2    | Runners for native, WebAssembly, Python and oracle; the differ; the report                        | repsynth conform --lane software exits 0: every runner agrees with the reference on every vector   | needs:code, needs:testing  |
| **P2.4** Property-based tests. After P2.2         | Hypothesis suites per specification; bounded proofs where widths are small (CNF-05)               | The suites pass, and a defect planted in each specification’s software is found                    | needs:testing, needs:proof |
| **P2.5** Mutation self-test, software. After P2.3 | Planted table, off-by-one and swapped-operand defects                                             | The report shows every planted defect caught                                                       | needs:testing              |

## 6.4 M3 Dependency and impact

Repository: hmnsq/repsynth.

| **Packet**                                            | **Produces**                                                                                   | **Accepted when**                                                                                         | **Labels**                |
|-------------------------------------------------------|------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|---------------------------|
| **P3.1** Read declarations and accessor. After P1.2   | Generators declare their reads; the accessor records actual reads                              | A generator that reads an undeclared path fails its own test, naming the path                             | needs:code                |
| **P3.2** Slices and Ninja. After P3.1                 | The slice writer (write on change only) and the build.ninja generator with restat              | Touching one slice rebuilds only its dependants, judged by output hashes                                  | needs:code                |
| **P3.3** Edge list and rendering. After P3.1          | graph/edges.txt with the seven edge types; a generated rendering                               | Every artefact has at least one implements or validates edge, and the rendering regenerates from the list | needs:code                |
| **P3.4** Impact command. After P3.2, P3.3             | repsynth impact: predicted artefacts and conformance cells; post-build confirmation            | For every case in P3.5, the predicted set equals the observed set                                         | needs:code, needs:testing |
| **P3.5** D2 over software artefacts. After P3.4, P2.3 | The four changes of DEP-05, run over software artefacts                                        | Each change regenerates exactly its expected set, and every other artefact hash is unchanged              | needs:testing             |
| **P3.6** Expected divergence. After P3.4              | Derived builds of legacy assets with deliberate changes, each with its expected-divergence set | Conformance passes when observed differences equal the expected set and fails on any other difference     | needs:code, needs:testing |

## 6.5 M4 Tier A, toolchain and operating systems

Repository: hmnsq/repsynth.

| **Packet**                                                          | **Produces**                                                                                                                                                                                              | **Accepted when**                                                                                                                                           | **Labels**                |
|---------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|
| **P4.1** Allocation ledger. After P1.3                              | Allocation in the custom opcode space; collision checks                                                                                                                                                   | A collision with a standard extension is refused, a collision with a known vendor extension is reported, and regeneration leaves every allocation unchanged | needs:code                |
| **P4.2** QEMU generator and patcher. After P4.1                     | Decodetree files, translation functions, helpers, the CPU property and build entries; exact-anchor patches; QEMU built with plugins                                                                       | QEMU builds in its container; a moved anchor stops the patcher, which names it                                                                              | needs:code                |
| **P4.3** Zero-patch toolchain and user-mode tests. After P4.2, P2.1 | .insn macros, the intrinsics header and test programs, run in qemu-riscv64 and qemu-riscv32                                                                                                               | With the property on, results equal the vectors; with it off, each new instruction raises SIGILL                                                            | needs:code, needs:testing |
| **P4.4** Benefit measurement and promotion. After P4.3              | Instruction counts from the counting plugin, base set against extension; the promotion report                                                                                                             | Every candidate has measured counts; only candidates with recorded benefit are promoted                                                                     | needs:code, needs:testing |
| **P4.5** binutils patch path. After P4.1                            | Opcode entries, extension registration and gas tests, built in repsynth-gnu                                                                                                                               | gas assembles every mnemonic, objdump disassembles it, and the generated gas tests pass                                                                     | needs:code                |
| **P4.6** xv6-riscv. After P4.3                                      | A derived build with a test program, and its boot script                                                                                                                                                  | The test program’s output inside xv6-riscv equals the vectors with the property on                                                                          | needs:code, needs:testing |
| **P4.7** Linux. After P4.3                                          | A minimal kernel, a static initramfs with the test binary, and the boot script                                                                                                                            | The binary’s output on the booted kernel equals the vectors; the firmware source used is recorded                                                           | needs:code, needs:testing |
| **P4.8** Compatibility matrix. After P4.6, P4.7                     | reports/compatibility from the run records                                                                                                                                                                | Every cell reads executed, with its record, or not established                                                                                              | needs:code                |
| **P4.9** Hindawi path. After P4.3, P0.3                             | The construct list of new mnemonics; a test program in a Hindawi language compiled through Hindawi’s front end to the cross compiler                                                                      | The program runs in QEMU with the vector results, or an issue text for the Hindawi repository records the command, exit code and output                     | needs:code, needs:human   |
| **P4.10** GCC patch path (SHOULD). After P4.5                       | Builtins, machine-description patterns and the -march name                                                                                                                                                | Test programs compiled with the builtins give the same results as with the intrinsics                                                                       | needs:code                |
| **P4.11** Sail and LLVM (MAY). After P4.3                           | Sail clauses; TableGen definitions                                                                                                                                                                        | The Sail emulator agrees with QEMU on the vectors                                                                                                           | needs:code, needs:proof   |
| **P4.12** Mutation self-test, instructions. After P4.3              | Planted defects: a wrong funct3, swapped operands in an intrinsic, a wrong helper                                                                                                                         | Every planted defect is caught                                                                                                                              | needs:testing             |
| **P4.13** Binary performance baseline. After P4.3                   | Embench-IoT kernels and the CMS-03 continuous models as fixed-point programs, built with the GNU cross tools for RV32 and RV64; dynamic instruction counts in QEMU; the baseline table on the status page | Counts are recorded with tool versions and reproduce exactly on rerun; every extension figure is shown beside its binary baseline                           | needs:code, needs:testing |

## 6.6 M5 Hardware

Repository: hmnsq/repsynth.

| **Packet**                                                            | **Produces**                                                                                                                              | **Accepted when**                                                                                           | **Labels**                |
|-----------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|---------------------------|
| **P5.1** Direct HDL generator. After P4.4                             | SystemVerilog and VHDL-2008 units for promoted operations defined by tables and bit layouts                                               | Units lint clean in Verilator and analyse cleanly in GHDL                                                   | needs:code                |
| **P5.2** HLS route record. After P5.1                                 | One unit through an open HLS tool; an architecture decision record choosing the route per unit                                            | The record gives measured resources and latency of both routes for the unit                                 | needs:code                |
| **P5.3** Unit simulation. After P5.1, P2.1                            | cocotb tests reading the shared vectors, on Verilator and GHDL                                                                            | Every vector passes on both simulators                                                                      | needs:testing             |
| **P5.4** Synthesis reports. After P5.1                                | Yosys and nextpnr runs for one low-cost FPGA family with an open flow                                                                     | Resource and timing figures are recorded as measurements, with tool versions                                | needs:code                |
| **P5.5** Coprocessor and co-simulation (SHOULD). After P5.3, P4.3     | The CV-X-IF wrapper; a Verilated open core running the compiled test program                                                              | Results on the Verilated core equal QEMU’s for the same binary on every vector                              | needs:code, needs:testing |
| **P5.6** SHAKTI study. After P0.2                                     | A record of the SHAKTI core’s extension mechanism, read from the sources Parashakti ingested                                              | The record cites the files and lines it relies on; no mechanism is assumed                                  | needs:code, needs:human   |
| **P5.7** Physical hand-off. After P5.3                                | jugaad28 descriptors at rung RTL or VERIFIED; the zamin boundary statement                                                                | The descriptors pass jugaad28’s own validation; native ternary circuits are routed to zamin                 | needs:code                |
| **P5.8** Mutation self-test, hardware. After P5.3                     | Planted defects: a flipped bit, swapped ports                                                                                             | Every planted defect is caught                                                                              | needs:testing             |
| **P5.9** D2 over instruction and hardware artefacts. After P3.5, P5.3 | The four changes of DEP-05, rerun with instruction and hardware artefacts present                                                         | Each change regenerates exactly its expected set, now including QEMU helpers, intrinsics and hardware units | needs:testing             |
| **P5.10** On-board run (MAY). After P5.4                              | A run on a board at hand                                                                                                                  | The board, toolchain version and result are recorded together                                               | needs:human               |
| **P5.11** Binary hardware baseline. After P5.5, P4.13                 | The same workloads on the Verilated open core; cycle counts; synthesis figures for the core and the generated units on the open FPGA flow | Cycles and synthesis figures are recorded with tool versions and reproduce on rerun                         | needs:code, needs:testing |

## 6.7 M6 Script lane

Repository: hmnsq/repsynth.

| **Packet**                                                    | **Produces**                                                                               | **Accepted when**                                                                                                      | **Labels**                  |
|---------------------------------------------------------------|--------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| **P6.1** Reading record of the 9-grid model. After P0.3, P1.6 | The model as APCISR’s source and the author’s paper define it                              | The author confirms the record before P6.3 runs                                                                        | needs:human, needs:ontology |
| **P6.2** Script references. After P0.1                        | Unicode data, CLDR, HarfBuzz and Noto fonts pinned in repsynth-script                      | Versions and hashes of every reference are recorded                                                                    | needs:code                  |
| **P6.3** Table generator and builds. After P6.1, P6.2         | Candidate grid tables for the working set; APCISR built per script, native and WebAssembly | Builds succeed for every working-set script, and the generated Devanagari tables reproduce APCISR’s own tables exactly | needs:code                  |
| **P6.4** Script conformance. After P6.3                       | Cluster and positional-class comparison with HarfBuzz; grapheme cluster rules              | Per-script results are recorded as status, with their evidence                                                         | needs:code, needs:testing   |
| **P6.5** Registry-wide run. After P6.4                        | Every script in the pinned ILM registry                                                    | The status page lists every registry script with its state; coverage is never a gate                                   | needs:code                  |
| **P6.6** Native-reader review. After P6.4                     | One review packet per working-set script                                                   | Each review is recorded with the reviewer’s role, the date and the samples reviewed                                    | needs:human                 |
| **P6.7** Findings register. After P6.4                        | Grid-model gaps with their evidence                                                        | Every gap cites its script, text and measurement, and none is closed by the harness                                    | needs:ontology              |

## 6.8 M7 Tier B

Repository: hmnsq/repsynth.

| **Packet**                                        | **Produces**                                                                                                                                   | **Accepted when**                                                                                                               | **Labels**              |
|---------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| **P7.1** Machine specifications. After P1.3, P1.4 | One parametric machine family and its two instances, a binary word machine and a balanced ternary word machine on a binary host encoding (RD5) | Both specifications validate, and their reference functions pass their properties                                               | needs:code, needs:proof |
| **P7.2** QEMU target generator. After P7.1, P4.2  | For each machine: target directory, CPU, decodetree translation, helpers and a minimal board with memory, a UART and an exit device            | QEMU builds with both new targets                                                                                               | needs:code              |
| **P7.3** Assembler definitions. After P7.1        | customasm instruction definitions and test images for both machines                                                                            | Assembling and decoding round-trip against each specification’s encodings                                                       | needs:code              |
| **P7.4** Boot and conformance. After P7.2, P7.3   | Bare-metal test images run on both targets; the binary machine’s workload counts recorded beside RV64                                          | Vectors pass on both targets, and the mutation self-tests catch every planted defect; workload counts are reported, never gated | needs:testing           |
| **P7.5** binutils ports (SHOULD). After P7.3      | Generated ports for both machines                                                                                                              | The ports assemble the P7.3 sources to identical images                                                                         | needs:code              |

## 6.9 M8 Applications, teaching and release readiness

Repository: hmnsq/repsynth.

| **Packet**                                     | **Produces**                                                                                                          | **Accepted when**                                                                         | **Labels**               |
|------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|--------------------------|
| **P8.1** Application specification. After M4   | The application specification interface and one worked example through the lanes                                      | The example’s representation choices and instruction candidates are measured and reported | needs:code               |
| **P8.2** Teaching lab. After M3, M4            | Exercises: add an instruction, change an encoding, watch the stack regenerate                                         | Each exercise runs on the reference unit from one command                                 | needs:code, needs:human  |
| **P8.3** Release readiness. After All lanes    | ops/verify.sh (essentials only); CONTRACT, CONTEXT and AGENTS overlays; README, NOTICE, CITATION.cff; the status page | ops/verify.sh passes on essentials, and secondary checks report                           | needs:code               |
| **P8.4** paras round trip (SHOULD). After P8.3 | paras ingestion of the harness’s repository                                                                           | Every Hindawi language round-trips exactly                                                | needs:code               |
| **P8.5** AyeVDI wiring (MAY). After P8.3       | A container wiring description for AyeVDI                                                                             | AyeVDI loads the description                                                              | needs:code, needs:visual |

## 6.10 M9 Substrate foundations

Repository: hmnsq/subcore.

| **Packet**                                                      | **Produces**                                                                                                                                                                                                                                                                                | **Accepted when**                                                                                                                                                                                     | **Labels**                 |
|-----------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|
| **P9.1** BURP JavaScript probe and the substrate-node container | The substrate-node container (Node.js at a pinned LTS release, Python with burp-ilm and mpmath, Playwright browser engines); a probe that runs BURP’s round trip on a minimal ES module and on each candidate library’s vendored sources, per Hindawi language; issue texts for BURP’s gaps | A table of library by language gives an exact round trip or the gap’s command, exit code and output; vendor/ADMISSIONS.csv records each library’s state                                               | needs:code, needs:testing  |
| **P9.2** Substrate meta-model                                   | spec/schema/substrate (JSON Schema 2020-12) with the sections of MRD section 9.9, following the conventions of MRD section 9.3; specifications of the five substrates                                                                                                                       | The five specifications validate, and planted defects are refused with their paths: a parameter without an evidence state, a quantity without a unit                                                  | needs:code, needs:ontology |
| **P9.3** Computational-model meta-model and expression grammar  | spec/schema/model; the restricted expression grammar in EBNF; its parser; generators to Modelica equations and SPICE behavioural expressions; the CMS-03 models                                                                                                                             | Every CMS-03 model parses, and its Modelica and SPICE forms re-parse to the same syntax tree                                                                                                          | needs:code, needs:proof    |
| **P9.4** Shared web core. After P9.1, P9.3                      | The command surface for browser and Node.js; YAML loading; units; expression evaluation; fixed-step RK4 and an adaptive Dormand-Prince solver from an admitted library; event location; a seeded generator with its published reference vectors; trace and vector input and output          | Fixed-step traces are byte-identical between Node.js and Chromium and within the cross-engine bound elsewhere; adaptive runs meet the analytic bounds; the generator reproduces its reference vectors | needs:code, needs:testing  |
| **P9.5** Reference containers and runner. After P9.1            | The substrate-ref container (OpenModelica, ngspice, Project Chrono, Qiskit Aer, QuTiP); tools/ref.sh, which runs a model in a reference and records its output with tool version, image digest and hash                                                                                     | The runner lists each tool’s version and image size; one sample model runs in each, and its recorded output is hashed                                                                                 | needs:code                 |
| **P9.6** Analytic and high-precision oracles. After P9.1, P9.3  | Closed-form solutions for decay, the oscillator and the damped driven oscillator; mpmath references for the Lorenz system; vector files                                                                                                                                                     | Oracle values carry their stated error bounds, and vector files regenerate byte-identically                                                                                                           | needs:code, needs:proof    |
| **P9.7** Mutation self-test, core. After P9.4                   | Planted defects: a wrong RK4 coefficient, a wrong unit factor, a parser precedence error                                                                                                                                                                                                    | Every planted defect is caught                                                                                                                                                                        | needs:testing              |
| **P9.8** Release readiness, core. After P9.4                    | ops/verify.sh (essentials only); notices; README; CITATION.cff; a Pages page with a live demonstration                                                                                                                                                                                      | ops/verify.sh passes on essentials, BURP results are attached, and secondary checks report                                                                                                            | needs:code                 |

## 6.11 M10 Mechanical simulator

Repository: hmnsq/mechsim.

| **Packet**                                             | **Produces**                                                                                                 | **Accepted when**                                                                                                          | **Labels**                 |
|--------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|----------------------------|
| **P10.1** Mechanism configuration schema. After P9.2   | A schema for shafts, elements, connections, inputs and outputs; configurations for the CMS-03 models         | Configurations validate, and planted defects are refused: an unconnected shaft, an over-constrained loop                   | needs:code, needs:ontology |
| **P10.2** Ideal kinematic engine. After P10.1, P9.4    | Constraint propagation for gears and differentials; integrator equations; cams from tables                   | Gear ratios and differential means are exact; integrators meet the analytic bounds; Node.js and browser agree under WEB-06 | needs:code, needs:testing  |
| **P10.3** Discrete mechanisms. After P10.2, P1.3, P1.4 | Detent wheels, carries and ratchets; mechanical binary and balanced ternary adders from their specifications | Both adders equal their reference functions on every vector                                                                | needs:code, needs:testing  |
| **P10.4** Lumped dynamic model. After P10.2            | Inertia, compliance, backlash, friction and integrator slip, with evidence states on parameters              | Step and sine responses meet the Modelica bounds of P10.7; the backlash dead band equals its configured value              | needs:code, needs:testing  |
| **P10.5** Views. After P10.2                           | A 2D SVG or canvas view of mechanisms and dials; a plotter; a 3D view with three.js                          | Every CMS-03 configuration renders on phone and desktop profiles; frame times are recorded                                 | needs:code, needs:visual   |
| **P10.6** Geometry export. After P10.1                 | Involute gears, cams and frames through JSCAD as STL or 3MF, with tolerances recorded                        | Profiles meet the involute checks, and meshes are watertight                                                               | needs:code                 |
| **P10.7** Modelica cross-check. After P10.4, P9.5      | A Modelica generator for configurations; recorded OpenModelica runs                                          | Deviations meet the Test Plan bounds for every configuration                                                               | needs:code, needs:testing  |
| **P10.8** Chrono cross-check. After P10.4, P9.5        | Chrono scripts for one gear train and one differential; recorded runs                                        | Ratios and phases meet the Test Plan bounds                                                                                | needs:code, needs:testing  |
| **P10.9** Differential analyser. After P10.2, P9.6     | Configurations solving the CMS-03 continuous models mechanically                                             | D8                                                                                                                         | needs:testing              |
| **P10.10** Mutation self-test, mechanical. After P10.2 | Planted defects: a wrong ratio, swapped differential inputs, an integrator sign                              | Every planted defect is caught                                                                                             | needs:testing              |
| **P10.11** Release readiness, mechanical. After P10.9  | ops/verify.sh; notices; README; CITATION.cff; Pages                                                          | ops/verify.sh passes on essentials, and BURP results are attached                                                          | needs:code                 |

## 6.12 M11 Analogue simulator

Repository: hmnsq/anasim.

| **Packet**                                                        | **Produces**                                                                                                         | **Accepted when**                                                                                                | **Labels**                 |
|-------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|----------------------------|
| **P11.1** Patch schema. After P9.2                                | A schema for elements, connections, coefficients, initial conditions and mode control; patches for the CMS-03 models | Patches validate, and planted defects are refused: an algebraic loop without an integrator, an unconnected input | needs:code, needs:ontology |
| **P11.2** Patch compiler. After P11.1, P9.4                       | Magnitude and time scaling; overload prediction; ODE assembly                                                        | Scale factors are recorded, and predicted overloads match simulated ones                                         | needs:code                 |
| **P11.3** Ideal simulation. After P11.2, P9.6                     | Ideal-element runs of every CMS-03 patch                                                                             | Results meet the analytic and high-precision bounds                                                              | needs:code, needs:testing  |
| **P11.4** Non-ideal elements. After P11.3                         | Finite gain and bandwidth, offset, drift, saturation, tolerances and seeded noise                                    | Deviations match first-order theory within the Test Plan bounds, and seeds reproduce runs exactly                | needs:code, needs:testing  |
| **P11.5** SPICE export and ngspice cross-check. After P11.4, P9.5 | Netlists of op-amp realisations with a generic macro-model; recorded ngspice runs                                    | Waveforms and overload onsets meet the Test Plan bounds                                                          | needs:code, needs:testing  |
| **P11.6** Modelica export and cross-check. After P11.3, P9.5      | Modelica models of patches; recorded OpenModelica runs                                                               | Deviations meet the Test Plan bounds                                                                             | needs:code, needs:testing  |
| **P11.7** Views. After P11.3                                      | A patch diagram in SVG; scope traces; mode controls                                                                  | Every CMS-03 patch renders on phone and desktop profiles and works offline after first load                      | needs:code, needs:visual   |
| **P11.8** Physical realisation model (SHOULD). After P11.5        | A bill of materials by generic part class and a breadboard-level netlist                                             | Every part is named by a generic class, not by one vendor’s catalogue number                                     | needs:code                 |
| **P11.9** Mutation self-test, analogue. After P11.3               | Planted defects: a summer sign, a coefficient, an initial condition                                                  | Every planted defect is caught                                                                                   | needs:testing              |
| **P11.10** Release readiness, analogue. After P11.7               | ops/verify.sh; notices; README; CITATION.cff; Pages                                                                  | ops/verify.sh passes on essentials, and BURP results are attached                                                | needs:code                 |

## 6.13 M12 Cross-substrate compilation and quantum

Repository: hmnsq/repsynth (Panini Q read, not changed).

| **Packet**                                                             | **Produces**                                                                                                              | **Accepted when**                                                                 | **Labels**                |
|------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|---------------------------|
| **P12.1** Cross-substrate compiler. After P10.2, P11.2, P4.3           | Compilation of CMS models to mechanism configurations, patches, RV64 programs and quantum circuits, with scaling          | The harmonic oscillator compiles to every substrate with a class and its evidence | needs:code                |
| **P12.2** Capability matrix. After P12.1                               | The matrix of models by substrates on the status page                                                                     | Every cell has a class with its record; no cell is asserted without a run         | needs:code                |
| **P12.3** Panini Q reading record and adapter. After P0.2              | A record of Panini Q’s interface from its source; an adapter for the circuits it covers                                   | The record cites files and lines, and uncovered operations are listed             | needs:code, needs:human   |
| **P12.4** Quantum circuit set and references. After P12.3, P9.5        | A circuit set; the browser library face; Qiskit Aer and QuTiP runs through the reference runner; convention mapping tests | Distributions and state vectors meet the Test Plan bounds, and mapping tests pass | needs:code, needs:testing |
| **P12.5** One model, four substrates. After P12.2, P12.4, P10.9, P11.3 | The harmonic oscillator across mechanical, analogue, digital and quantum substrates                                       | D10                                                                               | needs:testing             |
| **P12.6** Mutation self-test, cross-substrate. After P12.1             | Planted defects: a wrong scale factor, a reversed qubit order                                                             | Every planted defect is caught                                                    | needs:testing             |

## 6.14 M13 Optical (SHOULD, later)

Repository: hmnsq/optisim.

| **Packet**                          | **Produces**                                                                                                      | **Accepted when**                                                                       | **Labels**                |
|-------------------------------------|-------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|---------------------------|
| **P13.1** Optical lane. After P12.2 | The optical substrate instance; mesh decomposition of unitary matrices; the browser face; photonic reference runs | Mesh products meet the Test Plan bound against direct matrix products and the reference | needs:code, needs:testing |

# 7 Critical path and parallel work

- Track H’s critical path runs M0, M1, M2, M3 and M4; M5, M7 and M8
  follow M4, and M6 runs beside everything from M0.

- Track S starts at once: M9 needs nothing from Track H, and its only
  links back are P1.3 and P1.4 for the mechanical adders (P10.3) and
  P4.3 for the digital cell of D10 (P12.1).

- M10 and M11 run in parallel on the shared core.

- M12 joins the tracks and needs M4, M10 and M11.

- Ingestibility (D12) is checked from S1, so a library BURP cannot
  round-trip is found before code depends on it.

# 8 Resources

- Track S’s browser work is light: it runs in browsers and in Node.js on
  the reference unit.

- Reference containers are heavy: OpenModelica, Project Chrono and the
  quantum references are measured at P9.5 and reported against free disk
  (PRF-05).

- Track H’s patched GNU and QEMU builds run one at a time (TCH-03).

- Phone checks need one physical low-cost phone for the needs:human
  packets; automated checks use browser engines in containers.

# 9 Definition of done

- The packet’s acceptance command ran, and its record is in the tree.

- A test was shown failing before it passed.

- The completion report lists what was produced, what was not done, what
  was reused (file and hash) and the packet’s intent verbatim.

- Every library used carries its admission state.

- Nothing in the packet pretends: unimplemented functions raise.

# 10 Hand-off for seeding

- Implementers deliver zips; they never push, publish, mint or create
  repositories.

- The author seeds each repository with one seed or update script, its
  own payload and its own gate (ops/verify.sh), on his machine, with
  typed gates for the irreversible steps.

- Pages serve docs/ in every substrate repository; the simulators are
  their pages.

- DOIs come through the author’s procedure; later versions of a
  repository are minted beneath its concept DOI.
