**Implementation Guidelines**

How the harness and the substrate simulators are built

*Package repsynth 0.3.0*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: defined. Generated from the same source as the other four
documents of the package.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 How the documents fit together

3 Principles

4 Repository conventions

5 JavaScript rules

6 Library admission

7 Numerical methods

8 Mechanical simulator

9 Analogue simulator

10 Quantum lane

11 Optical lane

12 Cross-substrate compiler

13 Formats

14 Containers and recorded references

15 Implementer protocol

16 House style

# 1 Document control

| **Item**   | **Value**                                                                                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title      | Implementation Guidelines                                                                                                                               |
| Package    | repsynth 0.3.0, document 02; the package holds documents 00 to 05                                                                                       |
| Version    | 0.3.0, 4 November 2026                                                                                                                                  |
| Author     | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                   |
| Applies to | hmnsq/repsynth, hmnsq/subcore, hmnsq/mechsim, hmnsq/anasim, hmnsq/optisim                                                                               |
| Status     | Defined. Nothing described here is built; claims follow AyeKnow states.                                                                                 |
| Licences   | Documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0 (master contract clause 2).                                                 |
| Trademarks | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification. |

# 2 How the documents fit together

| **Document**                 | **Answers**                                                                 |
|------------------------------|-----------------------------------------------------------------------------|
| 00 Sovereignty Architecture  | The whole stack, bottom-up, and how this build complements paras and SHAKTI |
| 01 MRD                       | What is required, and why                                                   |
| 02 Implementation Guidelines | How it is built                                                             |
| 03 Repository Map            | Where each part lives, and under what name                                  |
| 04 Build Plan                | In what order, packet by packet                                             |
| 05 Test Plan                 | How each claim is proven                                                    |

Where two documents seem to differ, the MRD’s requirement governs, and
the difference is reported in the completion report.

# 3 Principles

- We do not reinvent the wheel. Drive existing tools and libraries,
  generate their inputs, and validate against established free and
  open-source references.

- The author’s existing work is the reference. Legacy implementations
  are read-only oracles, run through their own drivers.

- Web first. Simulators and browser faces are plain JavaScript ES
  modules served as static files, with no build step.

- Ingestible. Every shipped source, vendored libraries included, must
  survive a BURP round trip byte for byte.

- One semantic source. Each discrete operation has one reference
  function and each continuous model one set of equations; everything
  else is checked against them.

- Nothing pretends. An unimplemented function raises; a gate is shown to
  refuse before it is trusted; done means executed.

- Evidence on everything. Claims use AyeKnow states, parameters carry
  evidence states, and an unknown value is not established, never a
  guess.

- Simulated is not built. A simulation result never becomes a claim
  about a physical machine (XSC-04).

- Global by default. No country, language, script, numeral system or
  locale is the default; parts are named by generic class.

- Nothing on the host. Everything installs in containers that are built
  once and kept; scripts stay in the folder they run from.

- Failures are shown, not asserted. Nothing is called broken without its
  command, exit code and output.

- Notices everywhere, and no AI named as author or contributor in
  anything published.

# 4 Repository conventions

## 4.1 A simulator repository

\<simulator\>/

docs/index.html the simulator page (Pages serves docs/)

docs/src/ simulator modules (ES modules)

docs/src/elements/ one module per element kind

docs/src/compile/ program-to-model compilation and scaling

docs/src/export/ Modelica, SPICE and geometry exporters

docs/src/ui/ views: the only modules that touch the DOM

docs/vendor/\<name\>/\<version\>/ third-party sources, readable, with
LICENCE and PROVENANCE

docs/vendor/subcore/\<version\>/ the shared core, vendored by version
and commit

docs/programs/ example programs (configurations or patches)

tools/cli.mjs the headless command surface for Node.js

tests/ vectors/ refs/ records/

ops/run.sh ops/verify.sh ops/selftest.sh

RESUME.md README.md NOTICE.md CONTRACT.md CONTEXT.md AGENTS.md
CITATION.cff VERSION

## 4.2 The shared core

subcore/

docs/index.html API reference and a live demonstration

docs/src/ spec, units, expr, solve, events, prng, trace, vectors, cli

docs/vendor/\<name\>/\<version\>/ math.js and js-yaml as readable
sources

spec/schema/ substrate and model meta-models (JSON Schema 2020-12)

spec/grammar/expr.ebnf the restricted expression grammar

spec/models/ the CMS-03 models

containers/ substrate-node and substrate-ref

tools/cli.mjs tools/ref.sh tests/ vectors/ records/ ops/

## 4.3 Files every repository carries

| **File**                           | **Purpose**                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------|
| README.md                          | What the repository is, how to run it in a browser and in Node.js, and its notices         |
| NOTICE.md                          | Copyright, the repository’s licences and those of every vendored library, trademarks       |
| CONTRACT.md, CONTEXT.md, AGENTS.md | Thin overlays on the author’s master contract; they add constraints and never relax one    |
| CITATION.cff                       | Citation metadata; affiliation AyeAI                                                       |
| VERSION                            | The semantic version                                                                       |
| ops/run.sh                         | One command that builds the repository’s containers once and runs an iteration inside them |
| ops/verify.sh                      | The release gate: essentials only (GOV-07)                                                 |
| ops/selftest.sh                    | Mutation self-tests                                                                        |
| vendor/ADMISSIONS.csv              | Each library’s admission state and BURP result                                             |
| records/                           | Generated run records                                                                      |
| RESUME.md                          | Generated state per packet, never edited by hand                                           |

## 4.4 Branches and versions

- main holds the English baseline; lang/\<language\> branches come from
  paras; no other long-lived branch exists.

- Versions are semantic, kept in VERSION and tagged vX.Y.Z; the shared
  core is vendored by version and commit.

- Implementers deliver zips; the author merges, pushes, seeds and mints
  (GOV-12).

# 5 JavaScript rules

- ES2020 modules loaded with script type module; relative import paths
  with file extensions; no bare module specifiers.

- No build step, bundler, transpiler, TypeScript or JSX in shipped
  sources. Tests and tools use Node.js built-ins, plus Playwright inside
  containers.

- No eval, no new Function and no dynamic import of addresses taken from
  data.

- Numerical modules never touch the DOM; only docs/src/ui does, so every
  numerical module imports unchanged in Node.js.

- Numbers are IEEE 754 doubles; exact discrete arithmetic beyond 53 bits
  uses BigInt; Math.random is never used, and randomness comes from the
  core’s seeded generator.

- Transcendental functions (Math.sin, Math.exp and the like) may differ
  in the last bits between engines. Byte equality is required between
  Node.js and Chromium-based browsers, which share an engine; other
  engines are compared within the Test Plan’s cross-engine bound.

- Quantities are held in SI base units at run time; UCUM units in
  specifications are converted once, at load.

- Long runs execute in module Web Workers; the page stays responsive,
  and runs can be cancelled and resumed.

- Every step checks finiteness; a non-finite value stops the run with an
  event naming the element and the time.

- Errors carry a code and the path of the element or field that caused
  them.

- Logs are verbose: the Node.js command prints every stage, the page
  keeps a log panel, and nothing is discarded.

- Layouts are responsive and touch-operable, with no hover-only
  controls; keyboard operation and reduced motion are respected.

- No analytics, trackers, fonts or scripts from other sites; a page
  works from its own files.

- Every file starts with the copyright line and an SPDX licence
  identifier.

# 6 Library admission

## 6.1 Procedure

1.  Read the licence file and record its SPDX identifier; the licence
    must allow distribution under GPL-3.0-or-later.

2.  Take readable source at a tagged release from the upstream
    repository, never a minified bundle; an ES module form is required.

3.  Vendor it under docs/vendor/\<name\>/\<version\>/ with LICENCE and
    PROVENANCE (upstream address, tag, commit and the sha256 of every
    file).

4.  Run the BURP round trip on the vendored files (P9.1) and record the
    result per language.

5.  Run the library’s own tests, where it ships them, in a container.

6.  Record the admission state (admitted, pending BURP, rejected) in
    vendor/ADMISSIONS.csv.

7.  Never edit vendored files; adapt behaviour in a wrapping module of
    the repository’s own.

## 6.2 Candidates

| **Role**                                                | **Candidates**                                                   | **Notes**                                                        |
|---------------------------------------------------------|------------------------------------------------------------------|------------------------------------------------------------------|
| Numerics, units, expressions, complex numbers, matrices | math.js                                                          | Readable ES module source; its ODE solver is confirmed at intake |
| YAML                                                    | js-yaml                                                          | Reads specifications and programs                                |
| Plots                                                   | uPlot                                                            | Scope and plotter traces                                         |
| 3D views                                                | three.js                                                         | The readable src tree is vendored, not the generated bundle      |
| Geometry                                                | JSCAD modelling package                                          | An ES module form is confirmed at intake                         |
| 2D contact dynamics (optional)                          | planck.js                                                        | Only where kinematic and lumped models do not suffice            |
| Quantum circuits                                        | quantum-circuit; Quirk                                           | One is chosen at P12.4 (RD12)                                    |
| Seeded random numbers                                   | A published generator (SplitMix64 or xoshiro128\*\*) in the core | Tested against its published reference vectors                   |
| Fixed-step RK4                                          | In the core                                                      | A textbook method, tested against analytic solutions             |

# 7 Numerical methods

- Fixed-step classical RK4 for parity vectors and interactive runs;
  adaptive Dormand-Prince 5(4) with recorded relative and absolute
  tolerances for accuracy runs. Step sizes and tolerances go in the run
  record.

- Events (comparator switching, overloads, detents, carries, mode
  changes) are located by bisection on the event function to within
  1e-12 of the step, and integration restarts from the event.

- Kinematic constraints are explicit relations solved along a spanning
  tree of the mechanism graph; a closed loop must be consistent, and an
  over-constrained loop is a validation error.

- Summers and coefficients in a patch are algebraic relations evaluated
  in dependency order; an algebraic loop without an integrator is a
  validation error.

- Stiffness shows as step-size collapse in the adaptive solver; it is
  reported with the model and the time, never hidden by a looser
  tolerance.

- Chaotic models are compared over a short horizon and by attractor
  statistics.

- Every comparison states its metric and its bound from the Test Plan.

- Performance figures are dynamic instruction counts from QEMU’s
  counting plugin, cycles from Verilated cores, and resources and
  maximum frequency from Yosys and nextpnr. Emulator figures are never
  stated as hardware speed. Binary is the baseline, and every other
  figure is shown beside it (NUM-06).

# 8 Mechanical simulator

## 8.1 Element catalogue

| **Element**                       | **Ideal relation**                                                       | **Lumped dynamic additions**         |
|-----------------------------------|--------------------------------------------------------------------------|--------------------------------------|
| Shaft                             | Angle θ in radians, speed ω                                              | Inertia J; viscous loss c            |
| External gear pair (z1, z2 teeth) | θ2 = -(z1/z2) θ1                                                         | Backlash; mesh stiffness; efficiency |
| Internal gear pair or belt        | θ2 = (z1/z2) θ1                                                          | As above                             |
| Differential                      | θc = (θa + θb)/2                                                         | Carrier inertia; friction            |
| Wheel-and-disc integrator         | dθw = (r/Rw) dθd, with r set by the integrand shaft through a lead screw | Wheel slip above a torque limit      |
| Lead screw (pitch p)              | x = p θ/(2π)                                                             | Friction; backlash                   |
| Cam and follower                  | y = f(θ) from a table with C1 interpolation                              | Follower inertia; loss of contact    |
| Counter wheel                     | Discrete positions with a carry on wrap                                  | Detent torque                        |
| Ratchet                           | One-way coupling                                                         | Pawl backlash                        |
| Crank, dial, plotter              | Inputs and outputs                                                       | None                                 |

## 8.2 Programs

A mechanism configuration lists shafts, elements and their connections,
inputs and outputs. The fragment below is illustrative; the schema of
P10.1 governs.

model: harmonic-oscillator

substrate: mechanical

shafts: \[time, x, v\]

elements:

\- integrator: {disc: time, integrand: x, output: v, gain: -1}

\- integrator: {disc: time, integrand: v, output: x, gain: 1}

inputs: \[{crank: time}\]

outputs: \[{plotter: \[time, x\]}\]

## 8.3 Balanced ternary mechanism

Each wheel has three detent positions for the trits -1, 0 and +1. Adding
two trits gives a sum trit and a carry from -1, 0 and +1: +1 plus +1
gives -1 with a carry of +1, and -1 plus -1 gives +1 with a carry of -1.
The mechanism simulates as a discrete state machine and is tested
exhaustively against the balanced ternary reference function at reduced
width.

## 8.4 Geometry

Gears use involute profiles from module, tooth count and pressure angle
(working value 20 degrees); clearances and backlash are recorded with
the geometry, and cams come from the function tables of their
configuration. JSCAD writes STL or 3MF; the licence of generated
geometry follows RD6.

## 8.5 References

The Modelica generator maps shafts to rotational inertias and flanges,
gear pairs to ideal gears with optional backlash and friction elements,
and integrators to their equations; the element names of the Modelica
Standard Library are read at intake (GOV-15). Project Chrono checks one
gear train and one differential in three dimensions.

# 9 Analogue simulator

## 9.1 Element catalogue

| **Element**               | **Ideal relation (machine units, inverting convention)**                   | **Non-ideal additions**                                     |
|---------------------------|----------------------------------------------------------------------------|-------------------------------------------------------------|
| Integrator                | dv/dt = -Σ wi ui, starting from its initial condition; frozen in hold mode | Finite gain (leakage), bandwidth, offset, drift, saturation |
| Summer                    | v = -Σ wi ui                                                               | Finite gain, offset, saturation                             |
| Inverter                  | v = -u                                                                     | As the summer                                               |
| Coefficient potentiometer | v = k u, with 0 ≤ k ≤ 1                                                    | Setting error; loading                                      |
| Multiplier                | v = u1 u2                                                                  | Offset; scale error; bandwidth                              |
| Comparator                | Switches between two levels when u1 - u2 crosses zero                      | Hysteresis; delay                                           |
| Limiter                   | v = min(max(u, low), high)                                                 | Soft knee                                                   |
| Function generator        | Piecewise linear through breakpoints                                       | Breakpoint error                                            |
| Sample and hold           | Tracks while sampling, holds while holding                                 | Droop                                                       |

## 9.2 Mode control, machine unit and scaling

Mode control follows analogue practice: in initial-condition mode
integrators hold their initial values, in operate mode they integrate,
and in hold mode they freeze. Computation uses a normalised machine unit
of 1; displays and circuit realisations show ±10 V (working value,
RD11). The patch compiler scales each variable by its declared maximum
so that it stays within the machine unit, and scales time so that the
fastest dynamics stay within the elements’ bandwidth; every factor is
recorded and undone for display.

## 9.3 SPICE and Modelica

Each element maps to an op-amp realisation: an integrator to an
amplifier with capacitive feedback and one input resistor per weight, a
summer to resistive feedback. The op-amp is a generic single-pole
macro-model with gain, gain-bandwidth and output limits written in plain
SPICE elements, so no vendor model file is needed. The Modelica
generator uses block-level elements for ideal comparisons and
electrical-level elements for circuit comparisons; element names are
read at intake (GOV-15).

## 9.4 Physical realisation model

A patch’s physical realisation model is a bill of materials by generic
part class (quad op-amps, precision resistors, film capacitors, an
analogue multiplier class) and a breadboard-level netlist. It is a
realisation model, not a claim of a working build; parts are named by
class so that a builder anywhere can source them.

# 10 Quantum lane

- OpenQASM 3 is the interchange; circuits are generated, never copied by
  hand between tools.

- Conventions are recorded per tool (qubit ordering, bit-string order of
  measurements, global phase), and mapping tests run before any
  comparison.

- Panini Q is read first, and its reading record cites files and lines
  (P12.3); its interface decides which circuits run through it.

- The browser face uses an existing circuit library chosen at P12.4
  (RD12).

- Noise models come from the reference tools with their parameters
  stated; the lane invents no noise model.

- The harmonic oscillator maps to a truncated oscillator Hamiltonian. A
  coherent state’s position expectation follows the classical
  trajectory, so truncation and time-step errors give the approximate
  class with its bound.

# 11 Optical lane

Unitary transfer matrices are realised as meshes of Mach-Zehnder
interferometers by the Reck (1994) or Clements (2016) decomposition.
Losses and phase errors are the non-ideal parameters. A photonic
reference (Perceval or Strawberry Fields) checks the mesh in M13.

# 12 Cross-substrate compiler

The compiler reads a computational model and a substrate specification,
chooses elements for each operation from the substrate’s capabilities,
scales the program, writes it in the substrate’s program form, runs it
through the substrate’s simulator and the oracle, and assigns the class
by the rules of MRD section 9.12. A class is assigned only from a run’s
record.

# 13 Formats

| **Artefact**                     | **Format**                    | **Notes**                                                                                                    |
|----------------------------------|-------------------------------|--------------------------------------------------------------------------------------------------------------|
| Specifications, models, programs | YAML                          | Validated against JSON Schema 2020-12                                                                        |
| Vectors                          | Plain text, one case per line | A header naming specification, version and hash; doubles with 17 significant digits; integers in hexadecimal |
| Traces                           | CSV with header lines         | Model, substrate, parameter hash, solver, step or tolerances, seed                                           |
| Run records                      | JSON                          | The fields of PRV-01                                                                                         |
| Attestations                     | in-toto Statement v1          | Candor’s form                                                                                                |
| Geometry                         | STL or 3MF                    | With tolerances in a YAML sidecar                                                                            |
| Circuits                         | SPICE netlists; OpenQASM 3    | Generated, never edited by hand                                                                              |
| Times                            | UTC, ISO 8601                 | None                                                                                                         |

# 14 Containers and recorded references

- The harness uses the containers of MRD section 9.7; the substrate
  repositories use substrate-node and substrate-ref from hmnsq/subcore.

- tools/ref.sh \<tool\> \<model\> runs a reference and writes its
  output, with tool version, image digest and hash, into the requesting
  repository’s refs/ directory.

- Simulator tests compare against recorded reference outputs, so they
  run in Node.js without the reference containers; a changed model
  reruns its references (DEP-04).

- Nothing is installed on the host; images are built once and kept
  (PRF-05).

# 15 Implementer protocol

- Iterations are numbered. Each returns one zip of the whole tree, never
  a delta, named with the iteration number.

- Each iteration carries, for every packet it touches, a completion
  report: the commands run with their exit codes, what was produced,
  what was not done, the test shown failing before it passed, what was
  reused (file and hash), and the packet’s intent as written in this
  document.

- Done means executed. A packet whose acceptance command has not run is
  reported as not built, or as wired but unproven, never as done.

- Nothing pretends. An unimplemented function raises rather than
  returning a plausible value, and a gate is shown to refuse a planted
  defect before it is trusted.

- Steps that need the network, containers or the forge are delivered as
  code that the author runs with one command (repsynth run --iteration
  N). Acceptance is read from that run’s records. The author is never
  handed a sequence of commands.

- At the start of every iteration the implementer reads RESUME.md and
  the latest run records. After a context compaction it rereads them and
  never reconstructs state from memory.

- A packet that does not fit one working context is split, and the split
  is recorded.

- Received documents are cleaned of invisible characters before they are
  read (GOV-11).

- Questions for the author go in the completion report, and work
  continues on the packets they do not block.

- The implementer never pushes, publishes, mints or creates
  repositories, and never edits a legacy source or a paras fork (GOV-03,
  GOV-04, GOV-12).

- When the author seeds an iteration, every file of the zip is kept; a
  fix made on his side is recorded as a diff, with the original kept in
  an origin folder.

- Every library used carries its admission state (WEB-03), and the
  completion report lists those states.

- The Implementation Guidelines (document 02) hold the coding rules, the
  library admission procedure and this protocol in full.

- Track S iterations close with ops/run.sh --iteration Sn in the
  repository concerned; reference runs go through tools/ref.sh in
  hmnsq/subcore.

# 16 House style

- British spelling; no em dashes; plain, direct prose.

- Claims carry AyeKnow states; parameters carry evidence states.

- The copyright line, licence and trademark notices on every artefact;
  affiliation AyeAI.

- No AI is named as author or contributor in anything published.
