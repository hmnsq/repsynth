**Sovereignty Architecture**

A bottom-up reference architecture for the build, complementing paras
and SHAKTI

*Package repsynth 0.3.0*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: defined. Generated from the same source as the other four
documents of the package.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 The aim

3 Dimensions of sovereignty

4 Layers, bottom-up

5 How this build complements paras and SHAKTI

6 The build matrix

7 Binary and balanced ternary

8 Global by default

9 Principles at every layer

10 Working decisions

11 Evidence

# 1 Document control

| **Item**   | **Value**                                                                                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title      | Sovereignty Architecture                                                                                                                                |
| Package    | repsynth 0.3.0, document 00; the package holds documents 00 to 05                                                                                       |
| Version    | 0.3.0, 4 November 2026                                                                                                                                  |
| Author     | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                   |
| Applies to | The whole stack of this build and its relation to paras, Parashakti and SHAKTI                                                                          |
| Status     | Defined. Nothing described here is built; claims follow AyeKnow states.                                                                                 |
| Licences   | Documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0 (master contract clause 2).                                                 |
| Trademarks | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification. |

# 2 The aim

This is a bottom-up reference architecture: it starts at the physical
substrate and rises through circuits, instruction sets, firmware,
operating systems, toolchains, languages, representations and
computational models to applications. It does not start from nothing. It
complements paras, which ingests the sources of every layer into every
Hindawi language, and Parashakti, which packages the demonstrated
sovereign stack through Hindawi on the SHAKTI processor.

The author’s aim, as recorded on 16 October 2026: a sovereign stack from
hardware definition through every layer and every kind of engineering,
expressible in any language without referring to a single character of
another language. Gaps are for that language and its authorities to
fill; until they do, it may borrow.

Parashakti’s sovereign stack, as recorded on 21 October 2026: a complete
operating-system stack that could become a distribution, from silicon
through every piece of infrastructure and the build utilities, with each
package also ingestible on its own through paras.

This build adds what that stack did not yet carry: the choice of
representations, and the choice of the physical substrate of
computation.

# 3 Dimensions of sovereignty

The architecture carries sovereignty along six dimensions. The grouping
is the drafter’s; the author’s terms govern wherever they differ.

| **Dimension**  | **What it means here**                                                                                                                                                 | **Carried by**                                                                | **State**                                                                                 |
|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|
| Source         | Every layer’s source can be read, built and changed, in any language                                                                                                   | paras, BURP, Hindawi 2026.10; hmnsq forks with one branch per language        | Existing: 58 of 71 stack packages published as forks on 22 October 2026 (author’s record) |
| Language       | Every layer can be expressed in any language without another language’s characters                                                                                     | Hindawi shailis, Romenagri, Project ILM, tajziya, chandah                     | Existing; coverage published as status                                                    |
| Silicon        | Processors whose designs are open and can be changed                                                                                                                   | SHAKTI through Parashakti; any open RISC-V core by parameter; jugaad28; zamin | Existing in part; this build adds hardware units and a coprocessor interface              |
| Representation | Number systems, encodings, scripts and instruction extensions are chosen, and the stack regenerates                                                                    | hmnsq/repsynth                                                                | Added by this build                                                                       |
| Substrate      | Computation is not bound to one fabrication process: mechanical, analogue, digital, quantum and optical realisations, simulated first, some buildable with local parts | hmnsq/subcore, hmnsq/mechsim, hmnsq/anasim, hmnsq/optisim; zistgah/paniniq    | Added by this build                                                                       |
| Provenance     | Every artefact carries its origin, its intent and its evidence                                                                                                         | zops, Candor, Tok DOI, misty-doi, satsneha; AyeKnow states                    | Existing                                                                                  |

# 4 Layers, bottom-up

<img src="media/2856765a679e00809552c2b4b1fc675e0f87dd0f.png"
title="Layers" style="width:6.66667in;height:4.5in"
alt="Figure 1. The layers, bottom-up: what paras, Parashakti, SHAKTI and the estate already provide, and what this build adds." />

*Figure 1. The layers, bottom-up: what paras, Parashakti, SHAKTI and the
estate already provide, and what this build adds.*

| **Layer**                            | **What it holds**                                                                  | **Already provided**                                                                           | **Added by this build**                                                    | **Interface**                             |
|--------------------------------------|------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------|-------------------------------------------|
| L0 Physical substrate                | Mechanisms, analogue circuits, CMOS logic, ternary MTCMOS cells, qubits, photonics | jugaad28 (28 nm catalogue), zamin (ternary hardware), Panini Q (quantum simulation)            | Substrate specifications; the mechanical, analogue and optical simulators  | Substrate specification (SUB)             |
| L1 Circuits and hardware description | RTL, cores, process design kits                                                    | SHAKTI cores through Parashakti; jugaad28’s open-PDK laboratory; VHDL tests in Hindawi 2026.10 | Hardware units for promoted instructions; a CV-X-IF wrapper                | SystemVerilog, VHDL; jugaad28 descriptors |
| L2 Instruction set                   | RISC-V base profiles, extensions, standalone machines                              | RISC-V on SHAKTI through Parashakti                                                            | Tier A extensions; Tier B machines, binary and balanced ternary            | Allocation ledger; QEMU decodetree        |
| L3 Firmware and boot                 | SeaBIOS, coreboot, OpenSBI                                                         | paras forks; Parashakti                                                                        | Boots with extensions enabled in QEMU                                      | QEMU machine definitions                  |
| L4 Operating systems                 | xv6, MINIX, Linux, FreeRTOS, Zephyr                                                | paras forks; Parashakti                                                                        | The compatibility matrix                                                   | Derived builds                            |
| L5 Toolchain                         | binutils, GCC, LLVM, make; self-hosting                                            | paras forks; Parashakti’s self-hosting plan                                                    | Extension inputs: .insn macros, opcode entries, intrinsics, patterns       | Generated patches                         |
| L6 Languages of code                 | Hindawi shailis, BURP ingestion, Romenagri, PANIR                                  | hindawi2026.10, burp, romenagri2026.10, chandah, tajziya                                       | Construct lists for new mnemonics; ingestible JavaScript                   | Construct lists; BURP round trips         |
| L7 Representations                   | Numbers, characters, scripts, encodings                                            | Hindawi transducers, APCISR, Romenagri and AyeHandSum, read as oracles                         | Representation specifications, generators and conformance                  | Representation specification (SPC)        |
| L8 Computational models              | Computations independent of any substrate                                          | Nothing before this build                                                                      | Model specifications; the cross-substrate compiler; the capability matrix  | CMS, XSC                                  |
| L9 Applications and learning         | AI, IoT, robotics, high-performance computing, teaching                            | The AI frameworks the author asked paras to ingest; his robotics and teaching work             | The application specification interface; teaching labs; browser simulators | APP                                       |
| Across all layers: provenance        | Seals, intents, timestamps, DOIs, assurance reports                                | zops, Candor, Tok DOI, misty-doi, satsneha                                                     | Run records and in-toto statements for every run                           | PRV                                       |
| Across all layers: reproducibility   | Containers and pinned versions                                                     | paras in Docker; the author’s container rulings                                                | Kept containers; pinned releases; recorded references                      | GOV-01; PRF                               |
| Across all layers: evidence          | States of claims and parameters                                                    | AyeKnow states; dhancha’s Unknown and rungs                                                    | States on every claim and parameter                                        | GOV-08; SUB-03; XSC-04                    |

# 5 How this build complements paras and SHAKTI

| **Concern**                               | **paras and Parashakti**                                                     | **This build**                                                                                                                 | **Where they meet**                            |
|-------------------------------------------|------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| Sources of every layer                    | Ingested into every Hindawi language as hmnsq forks, one branch per language | Resolved from those forks first; gaps reported back (TCH-02)                                                                   | The fork registry; BURP’s missing-item reports |
| The processor                             | SHAKTI is the target; its SDK is ingested first                              | Extensions and hardware units aimed at SHAKTI once its extension mechanism is read (HDL-06); any open RISC-V core by parameter | The ingested SHAKTI sources                    |
| Firmware, operating systems and toolchain | The sovereign stack, built and on its way to self-hosting                    | Booted and compiled with generated extensions in QEMU, never rewritten (INT-03, INT-04)                                        | Derived builds; the compatibility matrix       |
| Languages                                 | Every package localised and round-tripped by BURP                            | New mnemonics as construct lists (ISA-11); every JavaScript source ingestible (WEB-03)                                         | Construct lists; BURP results                  |
| Representation                            | Inherited from upstream                                                      | Chosen by specification and regenerated (SPC and DEP groups)                                                                   | hmnsq/repsynth                                 |
| Substrate                                 | Digital electronics                                                          | Mechanical, analogue, quantum and optical beside digital (SUB, MEC, ANA, QNT and OPT groups)                                   | hmnsq/subcore and the simulators               |
| Distribution                              | paras-ilm and burp-ilm on PyPI; per-language releases                        | repsynth through pipx; the simulators as Pages sites, offline and on phones                                                    | PyPI; Pages                                    |

# 6 The build matrix

Divide and conquer: every build is a cell of representation, substrate,
target and language. A cell is built and tested on its own, and it
depends on another cell only through a stated prerequisite (INT-12). The
first build fills these cells:

| **Representation or model**                   | **Software** | **Tier A in QEMU**                | **Tier B in QEMU** | **Hardware units**     | **Mechanical**                     | **Analogue**                     | **Quantum**                 | **Optical**    |
|-----------------------------------------------|--------------|-----------------------------------|--------------------|------------------------|------------------------------------|----------------------------------|-----------------------------|----------------|
| Binary integer (performance baseline)         | First build  | First build: base instruction set | First build        | First build: open core | First build: adder                 | Not applicable                   | Later                       | Not applicable |
| Balanced ternary                              | First build  | First build: extension            | First build        | First build: units     | First build: adder                 | Not applicable                   | Later                       | Not applicable |
| Packed decimal                                | First build  | Candidate                         | Later              | Candidate              | Later                              | Not applicable                   | Not applicable              | Not applicable |
| AyeHandSum dynamic base                       | First build  | Candidate                         | Later              | Candidate              | Later                              | Not applicable                   | Not applicable              | Not applicable |
| Transliteration (Romenagri)                   | First build  | Candidate                         | Not applicable     | Candidate              | Not applicable                     | Not applicable                   | Not applicable              | Not applicable |
| Script structure (9-grid)                     | First build  | Not applicable                    | Not applicable     | Not applicable         | Not applicable                     | Not applicable                   | Not applicable              | Not applicable |
| Continuous models: decay, oscillators, Lorenz | First build  | First build: fixed-point programs | Later              | Later                  | First build: differential analyser | First build: patches             | First build: the oscillator | Later          |
| Function generation y = f(x)                  | First build  | Candidate                         | Later              | Candidate              | First build: cams                  | First build: function generators | Not applicable              | Later          |
| Linear maps                                   | First build  | Candidate                         | Later              | Candidate              | Not applicable                     | Later                            | Not applicable              | Later: M13     |

First build: packets exist in the Build Plan. Candidate: built when
measurement promotes it (ISA-03). Later: a later milestone. Every code
cell can also be written in any Hindawi language and compiled through
Hindawi’s front end (D5 shows one), and every JavaScript source is
checked for ingestibility (D12).

# 7 Binary and balanced ternary

Both run (RD5). Binary is the performance baseline: every performance
figure is reported beside the binary implementation of the same
computation on the same target (NUM-06, D14). Balanced ternary is the
representation-change demonstrator: changing its encoding regenerates
software, instructions and hardware (D2), and it runs as an instruction
extension, as a standalone machine, as hardware units and as a
mechanism. One parametric machine family yields both standalone machines
(ISB-01).

# 8 Global by default

- SHAKTI is the first silicon target; any open RISC-V core is a
  parameter, so any country or community can target cores of its own.

- The whole ILM registry is in scope for scripts, with a first working
  set spanning regions.

- Physical realisations use generic part classes and printable geometry,
  so a build needs no single vendor or country.

- Open process design kits from more than one country, through jugaad28.

- One laptop, offline after the first fetch; every page usable on a
  phone.

- No country, language, script, numeral system or locale is the default.

# 9 Principles at every layer

- We do not reinvent the wheel: existing tools serve every layer, and
  this build generates their inputs.

- Legacy work is the reference: oracles, read-only, run through their
  own drivers.

- Web first and ingestible: plain JavaScript, and libraries only when
  paras and BURP can ingest their sources.

- Nothing pretends: done means executed, and a failure is shown with its
  command, exit code and output.

- Simulated is not built.

- Nothing is installed on the host; containers are built once and kept.

- The author pushes, seeds and mints; implementers deliver zips.

# 10 Working decisions

The author makes architectural decisions once he has seen the build
working. Until then these working decisions stand; MRD section 16
records every decision with its state, and any change with its date.

| **ID** | **Decision**                                 | **Working value**                                             |
|--------|----------------------------------------------|---------------------------------------------------------------|
| RD3    | Vendor prefix for extension names            | xaye                                                          |
| RD6    | Licence of generated hardware descriptions   | CERN-OHL-S-2.0, as proposed in jugaad28; confirmed at release |
| RD8    | First working set of scripts                 | As in SCR-05                                                  |
| RD9    | Localisation of specifications through paras | After the first build                                         |
| RD11   | Machine unit for analogue patches            | Normalised 1, shown as ±10 V                                  |
| RD12   | The browser quantum circuit library          | Chosen at P12.4                                               |
| RD13   | Physical builds as teaching labs             | Later; realisation models are produced now                    |
| RD14   | Timing of the optical lane                   | After M12                                                     |

# 11 Evidence

| **Claim**                                                                         | **State**                                                                       | **Checked by** |
|-----------------------------------------------------------------------------------|---------------------------------------------------------------------------------|----------------|
| BURP’s coverage of JavaScript                                                     | Not established                                                                 | P9.1           |
| SHAKTI’s extension mechanism                                                      | Not established; read from the ingested sources                                 | P5.6           |
| The AI frameworks paras was asked to ingest                                       | Asked on 20 October 2026; their state is not established here                   | P0.2           |
| The machine-stack explainer, the APCISR WebAssembly trace, AyeHandSum’s mechanism | Received in R2; unverified                                                      | P0.2           |
| NI2A2; MSRR                                                                       | Named in R3; NI2A2 found only in a conversation summary; MSRR not in the record | P0.2           |
| 58 of 71 stack packages published as hmnsq forks                                  | Stated by the author from his run of 22 October 2026                            | P0.2           |
| Memory of the reference unit                                                      | 16 GB in the record; 32 GB in R2; settled by measurement                        | P0.6           |
