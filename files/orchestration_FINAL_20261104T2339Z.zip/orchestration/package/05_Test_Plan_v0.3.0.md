**Test Plan**

How every claim of the MRD is proven

*Package repsynth 0.3.0*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: defined. Generated from the same source as the other four
documents of the package.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 Purpose and scope

3 Test levels

4 Oracles

5 Tolerances

6 Test catalogue

7 Demonstrator acceptance

8 Mutation testing

9 Ingestibility

10 Browser and device matrix

11 Human tests

12 Traceability and coverage

13 Entry, exit and regression

14 Environment

15 Records

# 1 Document control

| **Item**   | **Value**                                                                                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title      | Test Plan                                                                                                                                               |
| Package    | repsynth 0.3.0, document 05; the package holds documents 00 to 05                                                                                       |
| Version    | 0.3.0, 4 November 2026                                                                                                                                  |
| Author     | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                   |
| Applies to | hmnsq/repsynth, hmnsq/subcore, hmnsq/mechsim, hmnsq/anasim, hmnsq/optisim                                                                               |
| Status     | Defined. Nothing described here is built; claims follow AyeKnow states.                                                                                 |
| Licences   | Documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0 (master contract clause 2).                                                 |
| Trademarks | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification. |

# 2 Purpose and scope

This plan says how every claim of the MRD is proven: at which level,
against which oracle, within which bound, and with which planted defects
showing that each test can fail. It covers both tracks, M0 to M13.

# 3 Test levels

| **Level**                     | **What it tests**                                                                | **Where it runs**             | **Gate or report**                                                   |
|-------------------------------|----------------------------------------------------------------------------------|-------------------------------|----------------------------------------------------------------------|
| L0 Static                     | Schemas, licences, notices, admission states, the no-eval rule, BURP round trips | Containers; Node.js           | Gate for schemas, secrets, notices and versions; report for the rest |
| L1 Unit                       | Reference functions, solvers, parsers, element models                            | Node.js; native C             | Gate: the repository’s own tests                                     |
| L2 Component                  | Generators, lanes, engines, exporters                                            | Containers; Node.js           | Gate                                                                 |
| L3 Integration                | End-to-end lane runs, operating-system boots, browser and Node.js parity         | Containers; browsers          | Gate for the packet’s acceptance                                     |
| L4 Cross-target conformance   | One vector set across every runner                                               | Containers; Node.js; browsers | Gate for promoted operations                                         |
| L5 Reference cross-validation | Free and open-source reference simulators                                        | Containers                    | Gate within the tolerance table                                      |
| L6 Demonstrators              | D1 to D13                                                                        | The author’s machine          | Programme acceptance                                                 |
| L7 Mutation                   | Planted defects show each suite bites                                            | Every level                   | Gate: every planted defect caught                                    |
| L8 Human                      | Native-reader reviews, the author’s confirmations, phone checks                  | People                        | Recorded; never automated away                                       |

# 4 Oracles

| **Oracle**                                                      | **Used for**                                     | **Why it is independent**                        |
|-----------------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Legacy implementations (Hindawi, Romenagri, APCISR, AyeHandSum) | Specifications extracted from them               | The author’s code, run through its own drivers   |
| Arbitrary-precision integers (Python, GMP)                      | Balanced ternary and decimal arithmetic          | Exact arithmetic in another system               |
| Analytic solutions                                              | Decay and oscillators                            | Closed form                                      |
| mpmath high-precision integration                               | The Lorenz system and models without closed form | Arbitrary precision at tight tolerance           |
| OpenModelica                                                    | Mechanical and analogue models                   | An equation-based simulator with its own solvers |
| ngspice                                                         | Analogue patches at circuit level                | A circuit simulator with device-level models     |
| Project Chrono                                                  | Gear trains and differentials in 3D              | A multibody engine                               |
| Qiskit Aer; QuTiP                                               | Quantum circuits and Hamiltonians                | Independent quantum simulators                   |
| QEMU; Verilator; GHDL                                           | Digital lanes                                    | Established simulators                           |
| HarfBuzz and the Unicode rules                                  | The script lane                                  | The standard shaping engine and data             |
| Published reference vectors and formulas                        | The seeded generator; involute geometry          | Published values                                 |

# 5 Tolerances

These are working values for the first build. A change is recorded in
this plan with its reason before a run uses it.

| **Comparison**                                         | **Metric**                                                              | **Working value**              | **Rationale**                                                               |
|--------------------------------------------------------|-------------------------------------------------------------------------|--------------------------------|-----------------------------------------------------------------------------|
| Fixed-step runs, Node.js against Chromium              | Byte equality of traces                                                 | Identical                      | One engine, the same arithmetic                                             |
| Fixed-step runs, other engines                         | Maximum relative difference                                             | 1e-12                          | Transcendental functions are not correctly rounded by every engine          |
| Discrete results (ternary, instructions, counters)     | Equality                                                                | Exact                          | Discrete semantics                                                          |
| Adaptive ideal models against analytic solutions       | Maximum relative error over the horizon, with an absolute floor of 1e-9 | 1e-7 at solver tolerance 1e-10 | Well inside the solver’s error control                                      |
| Fixed-step RK4 ideal models against analytic solutions | Maximum absolute error over amplitude                                   | 1e-4 at the configured step    | Fourth-order global error                                                   |
| Lorenz system, t ≤ 5, against mpmath                   | Maximum absolute error                                                  | 1e-6                           | Before trajectories diverge                                                 |
| Lorenz attractor statistics, t from 50 to 500          | Means and standard deviations of x, y and z                             | Within 2 per cent              | Chaotic dynamics                                                            |
| Browser ideal models against OpenModelica              | Maximum relative error                                                  | 1e-5                           | Both at tight tolerances                                                    |
| Non-ideal analogue against ngspice                     | RMS error over the horizon, over the machine unit                       | 1 per cent                     | Element models differ in form                                               |
| Overload onset                                         | Absolute time difference over the horizon                               | 1 per cent                     | Event detection                                                             |
| Mechanical lumped dynamics against Modelica            | RMS error over the output range                                         | 0.5 per cent                   | The same lumped physics                                                     |
| Backlash dead band                                     | Absolute error                                                          | 1e-9 rad                       | A configured parameter                                                      |
| Gear ratio in Chrono                                   | Relative error                                                          | 1e-6                           | Constraint solver accuracy                                                  |
| Gear phase after 100 revolutions in Chrono             | Absolute error                                                          | 1e-4 rad                       | Accumulated drift                                                           |
| Involute profile                                       | Deviation from the ideal involute                                       | 1e-6 of the module             | Geometric construction                                                      |
| Quantum measurement distributions                      | Total variation distance                                                | 0.02 at 100,000 shots          | Sampling error is near 0.005 for eight outcomes, so the bound leaves margin |
| Quantum state vectors                                  | Maximum amplitude difference after global phase alignment               | 1e-10                          | Double precision                                                            |
| Optical meshes                                         | Maximum absolute matrix-element error, ideal mesh                       | 1e-9                           | Double precision                                                            |

# 6 Test catalogue

| **ID** | **Level** | **Item**                                                       | **Oracle**                          | **Pass condition**                                                    | **Packets**                |
|--------|-----------|----------------------------------------------------------------|-------------------------------------|-----------------------------------------------------------------------|----------------------------|
| T-01   | L0        | Specification validator refuses planted defects                | Planted defects                     | Each refused with its path                                            | P1.1                       |
| T-02   | L1        | Canonical hash invariance                                      | Property tests                      | Unchanged by reordering and whitespace; changed by any value change   | P1.2                       |
| T-03   | L1        | Balanced ternary reference functions                           | Arbitrary-precision integers        | Exact on reduced-width exhaustive domains and seeded full-width cases | P1.3                       |
| T-04   | L1        | Packed decimal reference functions                             | Python decimal module               | Exact                                                                 | P1.4                       |
| T-05   | L2        | Romenagri extraction                                           | Romenagri                           | Every mapping reproduced                                              | P1.5                       |
| T-06   | L2        | APCISR Devanagari extraction                                   | APCISR                              | Every cell assignment reproduced                                      | P1.6                       |
| T-07   | L2        | AyeHandSum extraction                                          | AyeHandSum                          | Every rule reproduced                                                 | P1.7                       |
| T-08   | L3        | Hindawi pipeline through its drivers                           | Hindawi’s own samples               | Forward and reverse runs recorded as Hindawi produces them            | P1.8                       |
| T-09   | L4        | Software differential run                                      | Oracles and reference functions     | Every runner agrees on every vector                                   | P2.3                       |
| T-10   | L7        | Software mutation                                              | Planted defects                     | Every planted defect caught                                           | P2.5                       |
| T-11   | L2        | Undeclared read detection                                      | A planted generator                 | Fails, naming the path                                                | P3.1                       |
| T-12   | L3        | Exact regeneration under four changes                          | Expected sets                       | Predicted, observed and expected sets equal                           | P3.5, P5.9                 |
| T-13   | L3        | Expected divergence                                            | Expected sets                       | Passes on equal sets; fails on any other difference                   | P3.6                       |
| T-14   | L2        | Encoding allocation and collisions                             | RISC-V opcode database              | Refused or reported as specified                                      | P4.1                       |
| T-15   | L3        | QEMU user mode and the illegal-instruction guard               | Reference functions                 | Equal results; SIGILL with the property off                           | P4.3                       |
| T-16   | L3        | Instruction counts                                             | QEMU counting plugin                | Recorded for every candidate                                          | P4.4                       |
| T-17   | L2        | Assembler and disassembler round trip                          | Specification encodings             | Every mnemonic assembles and disassembles                             | P4.5                       |
| T-18   | L3        | xv6-riscv boot and test program                                | Vectors                             | Equal results                                                         | P4.6                       |
| T-19   | L3        | Linux boot and test binary                                     | Vectors                             | Equal results                                                         | P4.7                       |
| T-20   | L3        | Program in a Hindawi language                                  | Vectors                             | Equal results, or the issue text recorded                             | P4.9                       |
| T-21   | L7        | Instruction mutation                                           | Planted defects                     | Every planted defect caught                                           | P4.12                      |
| T-22   | L4        | Hardware units on Verilator and GHDL                           | Vectors                             | Every vector passes                                                   | P5.3                       |
| T-23   | L4        | Core co-simulation                                             | QEMU                                | Equal results                                                         | P5.5                       |
| T-24   | L7        | Hardware mutation                                              | Planted defects                     | Every planted defect caught                                           | P5.8                       |
| T-25   | L5        | Script conformance                                             | HarfBuzz and Unicode rules          | Status recorded per script                                            | P6.4                       |
| T-26   | L8        | Native-reader reviews                                          | Readers                             | Recorded with role and date                                           | P6.6                       |
| T-27   | L3        | Tier B boots, binary and balanced ternary machines             | Vectors                             | Every vector passes on both                                           | P7.4                       |
| T-28   | L3        | Binary baseline instruction counts                             | QEMU counting plugin                | Recorded with tool versions; identical on rerun                       | P4.13                      |
| T-29   | L3        | Binary baseline cycles and synthesis figures                   | Verilated core; Yosys and nextpnr   | Recorded with tool versions; identical on rerun                       | P5.11                      |
| T-30   | L0        | BURP round trip per file and library                           | BURP                                | Byte-identical, or the gap recorded                                   | P9.1                       |
| T-31   | L0        | Substrate specifications and planted defects                   | Planted defects                     | Valid specifications pass; defects refused                            | P9.2                       |
| T-32   | L1        | Expression grammar round trip through Modelica and SPICE forms | Re-parse                            | Identical syntax trees                                                | P9.3                       |
| T-33   | L1        | Node.js and browser parity, fixed step                         | Itself                              | Byte-identical on Chromium; within the cross-engine bound elsewhere   | P9.4                       |
| T-34   | L1        | Integrators against analytic solutions                         | Analytic solutions                  | Within the tolerance table                                            | P9.4, P9.6                 |
| T-35   | L1        | Lorenz system, short horizon                                   | mpmath reference                    | Within the tolerance table up to t = 5                                | P9.6                       |
| T-36   | L1        | Lorenz attractor statistics                                    | Long reference run                  | Within 2 per cent                                                     | P9.6                       |
| T-37   | L7        | Core mutation                                                  | Planted defects                     | Every planted defect caught                                           | P9.7                       |
| T-40   | L0        | Mechanism configurations and planted defects                   | Planted defects                     | Valid configurations pass; defects refused                            | P10.1                      |
| T-41   | L1        | Gear trains and differentials                                  | Algebra                             | Exact ratios; differential means within 1e-12                         | P10.2                      |
| T-42   | L1        | Wheel-and-disc integrator                                      | Analytic solutions                  | Within the tolerance table                                            | P10.2                      |
| T-43   | L1        | Mechanical binary and balanced ternary adders                  | Reference functions                 | Exact on every vector                                                 | P10.3                      |
| T-44   | L5        | Lumped dynamics against Modelica                               | OpenModelica                        | Within the tolerance table; backlash dead band exact                  | P10.4, P10.7               |
| T-45   | L1        | Involute geometry and meshes                                   | Gear geometry relations             | Within the tolerance table; watertight meshes                         | P10.6                      |
| T-46   | L5        | Gear train and differential in Chrono                          | Project Chrono                      | Ratio and phase within the tolerance table                            | P10.8                      |
| T-47   | L6        | Differential analyser solves the CMS-03 models                 | Analytic and mpmath references      | Within the tolerance table                                            | P10.9                      |
| T-48   | L7        | Mechanical mutation                                            | Planted defects                     | Every planted defect caught                                           | P10.10                     |
| T-49   | L8        | Mechanism views on phone and desktop                           | Visual check                        | Every element drawn; frame times recorded                             | P10.5                      |
| T-50   | L0        | Patches and planted defects                                    | Planted defects                     | Valid patches pass; defects refused                                   | P11.1                      |
| T-51   | L1        | Scaling and overload prediction                                | Simulation                          | Predicted overloads equal simulated overloads                         | P11.2                      |
| T-52   | L1        | Ideal patches against analytic solutions                       | Analytic and mpmath references      | Within the tolerance table                                            | P11.3                      |
| T-53   | L1        | Non-ideal effects against first-order theory                   | Theory                              | Within the tolerance table; seeds reproduce runs                      | P11.4                      |
| T-54   | L5        | Patches against ngspice                                        | ngspice                             | Within the tolerance table; overloads agree                           | P11.5                      |
| T-55   | L5        | Patches against OpenModelica                                   | OpenModelica                        | Within the tolerance table                                            | P11.6                      |
| T-56   | L7        | Analogue mutation                                              | Planted defects                     | Every planted defect caught                                           | P11.9                      |
| T-57   | L8        | Patch views on phone and desktop                               | Visual check                        | Renders; works offline after first load                               | P11.7                      |
| T-60   | L3        | Cross-substrate compilation of the harmonic oscillator         | Analytic solution                   | Every cell classed with its record                                    | P12.1, P12.5               |
| T-61   | L5        | Quantum circuit set across simulators                          | Qiskit Aer; Panini Q; QuTiP         | Within the tolerance table                                            | P12.4                      |
| T-62   | L1        | Qubit-ordering and phase conventions                           | Constructed circuits                | Every mapping test passes                                             | P12.4                      |
| T-63   | L7        | Cross-substrate mutation                                       | Planted defects                     | Every planted defect caught                                           | P12.6                      |
| T-64   | L0        | Ingestibility of every substrate repository                    | BURP                                | Byte-identical, or the gap recorded                                   | P9.1, P9.8, P10.11, P11.10 |
| T-70   | L5        | Optical meshes against matrix products                         | Direct products; photonic reference | Within the tolerance table                                            | P13.1                      |

# 7 Demonstrator acceptance

| **ID** | **Demonstrator**                                                                                                                                    | **Milestone**   | **Accepted when**                                                                                                                                                                                                         | **Tests**        |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| D1     | Software agreement: legacy and generated builds agree with their oracles and reference functions on native, WebAssembly and Python targets          | M2              | The software conformance run exits 0, and its mutation report shows every planted defect caught                                                                                                                           | T-09, T-10       |
| D2     | Exact regeneration under the four changes of DEP-05                                                                                                 | M3, again in M5 | For each change, the predicted, observed and expected sets of regenerated artefacts are equal, and every other artefact hash is unchanged                                                                                 | T-11, T-12       |
| D3     | Tier A in QEMU with GNU tools and Parashakti operating systems                                                                                      | M4              | Promoted instructions, compiled by the GNU cross tools, give the vector results in QEMU user mode, in xv6-riscv and in Linux; with the CPU property off they raise illegal-instruction exceptions                         | T-15, T-18, T-19 |
| D4     | One program on two machines                                                                                                                         | M5              | The same compiled program gives equal results on the Verilated core with the generated unit and in QEMU                                                                                                                   | T-23             |
| D5     | A program in a Hindawi language using the extension                                                                                                 | M4              | It runs in QEMU with the vector results, or the Hindawi issue text records the command, exit code and output                                                                                                              | T-20             |
| D6     | Script status across the ILM registry                                                                                                               | M6              | The status page lists every registry script with its state and evidence                                                                                                                                                   | T-25, T-26       |
| D7     | Two new instruction sets in QEMU: binary and balanced ternary word machines                                                                         | M7              | Both Tier B machines boot bare-metal test images that pass their vectors, and their mutation self-tests catch every planted defect                                                                                        | T-27             |
| D8     | A mechanical computer in the browser: the CMS-03 models on a simulated differential analyser, and the mechanical binary and balanced ternary adders | M10             | Trajectories meet the analytic and high-precision bounds; both adders equal their reference functions on every vector; Modelica and Chrono cross-checks meet their bounds                                                 | T-41 to T-48     |
| D9     | An analogue computer in the browser: the CMS-03 models as patches                                                                                   | M11             | Ideal runs meet the analytic bounds; ngspice and Modelica cross-checks meet theirs; predicted and simulated overloads agree                                                                                               | T-50 to T-56     |
| D10    | One model, four substrates                                                                                                                          | M12             | The harmonic oscillator runs on mechanical, analogue, digital and quantum substrates as the compiler classes it, each class carrying its record                                                                           | T-60             |
| D11    | Quantum agreement                                                                                                                                   | M12             | A fixed circuit set agrees across the browser library, Panini Q where it applies, and Qiskit Aer, under the Test Plan’s statistical bounds                                                                                | T-61, T-62       |
| D12    | Ingestible sources                                                                                                                                  | M9 to M11       | Every JavaScript file of every substrate repository, vendored libraries included, round-trips through BURP byte for byte, or its gap is recorded with command, exit code and output                                       | T-30, T-64       |
| D13    | Optical linear maps (SHOULD)                                                                                                                        | M13             | Mesh realisations of a set of unitary matrices agree with direct products within the Test Plan bound                                                                                                                      | T-70             |
| D14    | Binary performance baseline                                                                                                                         | M4, M5          | Workload instruction counts on RV32 and RV64 in QEMU, cycles on the Verilated open core and synthesis figures are recorded and reproduce on rerun; every extension and ternary figure is shown beside its binary baseline | T-28, T-29       |

# 8 Mutation testing

| **Lane**          | **Planted defects**                                                 | **Caught by** |
|-------------------|---------------------------------------------------------------------|---------------|
| Specifications    | A missing section; a guessed value; an undefined reference function | T-01          |
| Software          | A table entry; an off-by-one; swapped operands                      | T-09, T-10    |
| Dependency engine | An undeclared read; a stale slice                                   | T-11, T-12    |
| Tier A            | A wrong funct3; swapped intrinsic operands; a wrong helper          | T-15, T-21    |
| Hardware          | A flipped bit; swapped ports                                        | T-22, T-24    |
| Substrate core    | A wrong RK4 coefficient; a wrong unit factor; a precedence error    | T-33 to T-37  |
| Mechanical        | A wrong ratio; swapped differential inputs; an integrator sign      | T-41 to T-48  |
| Analogue          | A summer sign; a coefficient; an initial condition                  | T-52 to T-56  |
| Cross-substrate   | A wrong scale factor; a reversed qubit order                        | T-60 to T-63  |

# 9 Ingestibility

- BURP runs on every JavaScript file of every substrate repository,
  vendored libraries included, for every Hindawi language paras ingests,
  and the returned sources must be byte-identical.

- The probe of P9.1 runs first, on a minimal module and each candidate
  library, so BURP’s coverage is known before code depends on it.

- A gap is recorded with its command, exit code and output, an issue
  text is prepared for BURP’s next round, and the library keeps the
  state pending BURP.

- A branch passes when its sources convert back to the baseline byte for
  byte, and the reverted sources pass the baseline tests.

# 10 Browser and device matrix

| **Class**                 | **Engines or devices**                          | **Required**      |
|---------------------------|-------------------------------------------------|-------------------|
| Desktop, Chromium-based   | Current stable, through Playwright              | Yes               |
| Desktop, Firefox          | Current stable, through Playwright              | Yes               |
| Desktop, WebKit           | Through Playwright                              | Yes               |
| Phone profiles, automated | Playwright device profiles on the three engines | Yes               |
| Physical low-cost phone   | One device, recorded by model and memory        | Yes (needs:human) |
| Offline                   | Reload with the network off after first load    | Yes               |
| Node.js                   | The pinned LTS release                          | Yes               |

# 11 Human tests

- Native-reader reviews for the script lane (P6.6).

- The author’s confirmation of the 9-grid reading record (P6.1) and of
  the Panini Q reading record (P12.3).

- A walk-through of each simulator on a physical phone: load, run a
  program, export a trace, work offline.

- Visual checks of mechanisms and patches against their programs: every
  element drawn and every connection visible.

# 12 Traceability and coverage

- Every requirement names its verifying packet or record (MRD section
  10), and every packet names its tests (section 6);
  data/traceability.csv joins them.

- A requirement with no test is reported, never silently accepted.

- Code coverage is measured and reported; it never gates.

# 13 Entry, exit and regression

- A packet starts when its prerequisites are accepted.

- A packet exits when its acceptance command passes and its mutation
  tests catch every planted defect.

- Every iteration reruns every test that passed before; a test is
  removed only with a recorded reason.

- A failing reference cross-check stops the claim, not the lane: the
  result is recorded as failing with its numbers, and the lane continues
  with the packets it does not block.

# 14 Environment

- The containers of MRD section 9.7, with substrate-node and
  substrate-ref.

- Node.js at a pinned LTS release in substrate-node.

- Playwright for the browser engines.

- Seeds for every random process recorded in run records.

# 15 Records

- Every test run writes a run record (PRV-01) and updates RESUME.md.

- Reference outputs are recorded with tool versions and hashes, so
  simulator tests compare against recorded references without
  containers; references rerun when a model changes (DEP-04).

- The status page shows pass, fail and not run for every test, never a
  summary that hides a failure.
