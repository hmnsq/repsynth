**Repository Map**

Where every part of the programme lives, and under what name

*Package repsynth 0.3.0*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: defined. Generated from the same source as the other four
documents of the package.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 Principles

3 Repositories

4 Dependencies

5 Projection names

6 What every repository carries

7 Seeding order

8 Ingestion and branches

# 1 Document control

| **Item**   | **Value**                                                                                                                                               |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title      | Repository Map                                                                                                                                          |
| Package    | repsynth 0.3.0, document 03; the package holds documents 00 to 05                                                                                       |
| Version    | 0.3.0, 4 November 2026                                                                                                                                  |
| Author     | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                   |
| Applies to | Every repository the programme creates or uses                                                                                                          |
| Status     | Defined. Nothing described here is built; claims follow AyeKnow states.                                                                                 |
| Licences   | Documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0 (master contract clause 2).                                                 |
| Trademarks | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification. |

# 2 Principles

- Core stem repositories belong to Humanesque (hmnsq), by the author’s
  ruling of 28 September 2026.

- Every project is replicated across the projections with its name,
  terminology and perhaps context changed, by his ruling of 4 October
  2026; how projections are carried (forks or branches) is his SCM
  decision.

- One repository per component with its own reason to change: the
  harness, the shared core and each simulator change for different
  reasons.

- Names are culturally appropriate, carry no religious significance in
  public, and collide with no existing name in the estate.

- The names in this map, projection names included, are the author’s,
  accepted on 4 November 2026 (RD1, RD2, RD10).

# 3 Repositories

| **Repository**  | **Status**  | **Track** | **Purpose**                                                                                                                                                                                               | **Depends on**                                           | **Licence**                              | **Pages**                       |
|-----------------|-------------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------|------------------------------------------|---------------------------------|
| hmnsq/repsynth  | New         | H         | The harness: specification meta-models, generators, dependency and conformance engines, Tier A and Tier B lanes, script lane, cross-substrate compiler, status page                                       | hmnsq/subcore; the oracles; hmnsq/paras; zistgah/paniniq | GPL-3.0-or-later; documents CC-BY-SA-4.0 | Status page                     |
| hmnsq/subcore   | New         | S         | The shared web core: substrate and model schemas, expression grammar, units, integrators, events, seeded generator, traces, vectors, browser and Node.js command surface, reference containers and runner | Vendored math.js and js-yaml                             | GPL-3.0-or-later                         | API reference and demonstration |
| hmnsq/mechsim   | New         | S         | The mechanical computer simulator                                                                                                                                                                         | hmnsq/subcore; vendored three.js and JSCAD               | GPL-3.0-or-later; geometry per RD6       | The simulator                   |
| hmnsq/anasim    | New         | S         | The analogue computer simulator                                                                                                                                                                           | hmnsq/subcore; vendored uPlot                            | GPL-3.0-or-later                         | The simulator                   |
| hmnsq/optisim   | Later (M13) | S         | The optical lane                                                                                                                                                                                          | hmnsq/subcore                                            | GPL-3.0-or-later                         | The simulator                   |
| zistgah/paniniq | Existing    | Read only | The quantum realisation backend; the adapter lives in hmnsq/repsynth                                                                                                                                      | As recorded                                              | As recorded                              | As recorded                     |

## 3.1 Existing repositories the programme uses

| **Repository**                                                                 | **Role**                                                       |
|--------------------------------------------------------------------------------|----------------------------------------------------------------|
| hmnsq/paras; hmnsq/burp                                                        | Ingestion; BURP round trips; gap reports for their next rounds |
| hindawiai/hindawi2026.10; hindawiai/chintamani; project-ilm/romenagri2026.10   | Oracles, read-only                                             |
| zistgah/tajziya                                                                | The script registry                                            |
| zistgah/jugaad28; zistgah/zamin                                                | Hardware hand-off: binary CMOS and native ternary              |
| zistgah/dhancha                                                                | Unknown semantics and rungs                                    |
| hmnsq/satsneha                                                                 | Reporting from run records                                     |
| hmnsq forks made by paras (QEMU, binutils, GCC, xv6-riscv, Linux and the rest) | Toolchain, firmware and operating-system sources               |

# 4 Dependencies

<img src="media/d7b42957b947c6ff6929ec8f0f72f0b331c0394f.png"
title="Repositories" style="width:6.66667in;height:5.125in"
alt="Figure 1. Repositories and their dependencies. Dashed edges are BURP round trips and the later optical lane." />

*Figure 1. Repositories and their dependencies. Dashed edges are BURP
round trips and the later optical lane.*

# 5 Projection names

Kaivalyik is the Indic projection, Zistgah the Persian and Islamicate
one, and Cosmopolis (c-polis) the Greek, Western and Classical one. The
names of the CJKV and Polynesian projections are not established, and
neither are their repository names.

| **Core**       | **Kaivalyik**                 | **Zistgah**                 | **Cosmopolis**                | **Sense**                                         |
|----------------|-------------------------------|-----------------------------|-------------------------------|---------------------------------------------------|
| hmnsq/repsynth | akriti (आकृति, form)           | paikar (پیکر, form, figure) | morphe (μορφή, form)          | The harness that gives representations their form |
| hmnsq/subcore  | neev (नींव, foundation)        | bunyad (بنیاد, foundation)  | hyle (ὕλη, matter)            | The shared foundation of the substrate simulators |
| hmnsq/mechsim  | yantriki (यांत्रिकी, mechanics) | charkh (چرخ, wheel)         | mechane (μηχανή, machine)     | The mechanical computer                           |
| hmnsq/anasim   | anurup (अनुरूप, analogous)      | mumasil (مماثل, analogous)  | analogon (ἀνάλογον, analogue) | The analogue computer                             |
| hmnsq/optisim  | prakash (प्रकाश, light)        | roshni (روشنی, light)       | lumen (Latin, light)          | The optical lane                                  |

Words avoided on purpose: yantra (Hindawi’s assembly shaili), chakra
(the CHAKRA observatory), zamin and tasvir (existing estate elements),
aadhaar (a national identity scheme), and words of religious
significance.

# 6 What every repository carries

The files of Implementation Guidelines section 4.3, a Pages site from
docs/, and lang/\<language\> branches made by paras.

# 7 Seeding order

1.  hmnsq/subcore, once S1 and S5 close its packets.

2.  hmnsq/anasim and hmnsq/mechsim, once S5 closes.

3.  hmnsq/repsynth, iteration by iteration in Track H.

4.  hmnsq/optisim, after M13.

The author seeds each repository with one seed or update script, its own
payload and its own gate, on his machine. Implementers never create
repositories.

# 8 Ingestion and branches

- Each repository’s sources pass BURP before release (D12); a branch
  passes when its sources convert back to the baseline byte for byte.

- Reverted sources pass the baseline tests.

- Upstream projects arrive as hmnsq forks made by paras, and the harness
  resolves sources from them first (TCH-02).
