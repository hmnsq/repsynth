**Representation Synthesis Harness**

Market requirements document for the harness build

*repsynth*

Version 0.3.0, 4 November 2026

Author: Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)

Status: requirements baseline for the implementers’ first iterations in
Track H (harness) and Track S (substrates). No component is built; every
claim carries its AyeKnow state.

© 1993–2026 Abhishek Choudhary. All rights reserved. AyeAI.

# Contents

1 Document control

2 Summary

3 Intent, as the author stated it

4 The received documents: what is adopted and what is amended

5 Market

6 Scope

7 What already exists

8 External tools reused

9 Architecture

10 Requirements

11 Build path, milestones and packets

12 Demonstrators and acceptance

13 Implementer protocol

14 Risks

15 Evidence register

16 Decisions

17 Glossary

# 1 Document control

| **Item**     | **Value**                                                                                                                                                                                                                                                     |
|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Title        | Representation Synthesis Harness (repsynth)                                                                                                                                                                                                                   |
| Document     | Market requirements document for the harness build                                                                                                                                                                                                            |
| Version      | 0.3.0, 4 November 2026. Supersedes 0.1.0 and 0.2.0 of the same date.                                                                                                                                                                                          |
| Author       | Abhishek Choudhary, AyeAI (ORCID 0009-0002-0684-8320)                                                                                                                                                                                                         |
| Implementer  | External implementers, an AI system or a person, working in numbered iterations under the protocol in section 13 and the Implementation Guidelines                                                                                                            |
| Status       | Requirements baseline. Every requirement and packet is at AyeKnow state defined; nothing is implemented.                                                                                                                                                      |
| Claim states | AyeKnow states: defined, implemented, executed, measured, verified, reproduced, open. A value that is not known reads not established, with its reason.                                                                                                       |
| Sources      | The author’s messages of 4 November 2026 (section 3); three documents received the same day from another AI assistant: R1, R2 and R3, which extends the work to computational substrates (section 4); the author’s records of his estate (sections 7 and 15). |
| Disclosure   | Unpublished working baseline. Publishing it is a dated public disclosure of the methods it describes (decision RD7).                                                                                                                                          |
| Licences     | Under master contract clause 2: documents CC-BY-SA-4.0; software GPL-3.0-or-later; schemas and data CC0-1.0. Generated files compiled into an upstream project take the licence that project accepts (GEN-04).                                                |
| Trademarks   | AyeAI®, AyeCNSe® and AyeAM® are registered trademarks of Abhishek Choudhary. Other names are the marks of their owners and are used for identification.                                                                                                       |
| Package      | Document 01 of package repsynth 0.3.0, with the Sovereignty Architecture (00), the Implementation Guidelines (02), the Repository Map (03), the Build Plan (04) and the Test Plan (05). All six are generated from one source.                                |

# 2 Summary

The two received documents propose a generative computing architecture.
Representations (number systems, character encodings, script structures,
instruction encodings, memory layouts) become design variables, and the
hardware and software that depend on them are regenerated from formal
specifications whenever a representation changes. The author accepts
that premise and sets its boundary in his own words: we do not reinvent
the wheel. A new instruction set is simulated in QEMU. Its toolchain is
the GNU cross-compilation toolchain. Firmware and the operating-system
stack already come from paras and the Parashakti stack.

What remains is a harness that joins these. It holds one specification
per representation; generates the native inputs of existing tools (QEMU
decodetree files and TCG helpers, binutils opcode entries and .insn
macros, GCC intrinsics and machine-description patterns, hardware
description for open simulators and synthesis, grid tables for APCISR);
runs those tools in containers that are built once and kept; holds every
target to one set of test vectors; and regenerates exactly what a change
touches. The author’s existing work is the reference throughout:
Hindawi, Romenagri, APCISR and AyeHandSum are read-only oracles, paras
and Parashakti supply sources and operating systems, jugaad28 and zamin
take hardware onward, and Candor and satsneha carry provenance.

**The optimum build path.** Each step is justified in section 11.

1.  Intake: retrieve, pin and run the existing work through its own
    drivers, and locate the three assets the received documents describe
    but the author’s record does not show.

2.  Specifications extracted from those oracles, plus balanced ternary
    as the first representation with no legacy code, so one end-to-end
    path never waits on an intake finding.

3.  Software conformance: generated and legacy builds held to shared
    vectors on native, WebAssembly and Python targets.

4.  The dependency and impact engine, proven on cheap artefacts before
    any hardware exists.

5.  Tier A: a representation’s operations as a RISC-V custom extension,
    first through stock QEMU and GNU tools with no patches, then with
    generated patches; xv6-riscv and Linux from Parashakti boot with it
    in QEMU.

6.  Hardware units only for instructions whose benefit has been
    measured, simulated against the same vectors and handed to jugaad28
    or zamin.

7.  The script lane, in parallel from intake onward, instantiating the
    author’s 9-grid model across the ILM registry.

8.  Tier B: standalone instruction sets, binary and balanced ternary, as
    new QEMU targets, last among the core lanes because they cost the
    most.

9.  Applications, teaching labs and release readiness.

Four amendments to the received documents carry the most weight. Legacy
implementations are oracles and are never replaced by generated code. No
instruction-set simulator, assembler, compiler, firmware or operating
system is generated. The author’s 9-grid model is instantiated for other
scripts, not replaced. The reference unit’s memory is recorded as a
conflict (16 GB in the author’s record, 32 GB in R2) and measured at
intake. Fourteen demonstrators decide acceptance (section 12); the
decisions and their states are in section 16.

Version 0.2.0 extends the programme to computational substrates. A
substrate (mechanical, analogue electronic, digital electronic, quantum
or optical) becomes a design variable beside the representation, with a
specification of its own. Mechanical and analogue computers are realised
first in simulation, by web-first simulators in plain JavaScript that
external implementers build on free and open-source libraries and check
against free and open-source reference simulators. Quantum work runs
through the author’s Panini Q and existing simulators; no new quantum
simulator is written. Optical work follows as a later milestone.
Molecular and biochemical substrates are outside the programme by the
author’s decision.

**The substrate track** runs beside the harness from the first day:

1.  Substrate foundations: substrate and computational-model
    specifications, the shared web core, the reference containers, and a
    BURP probe of JavaScript that decides which libraries may be relied
    on.

2.  A mechanical computer simulator and an analogue computer simulator
    in the browser, ideal models first, then non-ideal models checked
    against OpenModelica, ngspice and Project Chrono.

3.  Cross-substrate compilation of one model onto every substrate, with
    a capability class and its evidence for each, and the quantum lane
    through Panini Q.

4.  The optical lane, later.

Version 0.3.0 records the author’s rulings of 4 November 2026. The
repository names are accepted as suggested. The reference unit’s memory
is settled by measurement at P0.6. At his request the drafter decided
that binary and balanced ternary both run: binary is the performance
baseline beside which every figure is reported, and balanced ternary is
the representation-change demonstrator. Every other decision stands as a
working decision for the build, which the author reviews once he has
seen the build run. The Sovereignty Architecture (document 00) sets out
the whole stack bottom-up and how this build complements paras and
SHAKTI.

# 3 Intent, as the author stated it

The author’s words, verbatim, from his message of 4 November 2026:

> *Study this and suggest an optimum build path using whatever I have
> already built*
>
> *The attachments are from ChatGPT*
>
> *We do not reinvent the wheel.*
>
> *New ISA ... Sim in qemu*
>
> *New toolchain ... Utilize cross compilation tools for gcc*
>
> *Firmware, OS stack etc - already part of paras*
>
> *Give a harness build MRD for what remains, to initiate build by grok*

His prompt that opens R3, in part:

> *We extend it to mechanical computer realization (at least in
> simulation if not built), analogue computers, quantum, ...*

From his message of 4 November 2026 that extends the scope, verbatim:

> *Extend to these except the biotech part*
>
> *Give implementation guidelines*
>
> *Repository names*
>
> *A build plan*
>
> *A test plan*
>
> *Give as a package*
>
> *Grok or other AI should implement the simulator for the mechanical
> and analogue computers using foss tools*
>
> *The builds should be web first - simple js... Js libs are ok, as long
> as we can paras/ burp ingest the sources*

Molecular and biochemical substrates, which R3 also describes, are
outside this programme by that decision.

From his message of the same evening, with the speech-interface
corrections he asked for (paras for Paris, P0.6 for P.6, balanced
ternary for balance ternary, SHAKTI for Shakti):

> *Repo names are accepted as suggested*
>
> *balanced ternary has to be there, right? But then binary is what we
> actually demonstrate our performance with. So both of them. Take a
> call.*
>
> *I will be able to do architectural decisions, make architectural
> decisions after I see the build working.*
>
> *P0.6 measures it in any case.*
>
> *Let’s stick to the paradigms, I would say. Allow for all the
> different builds. That’s why we are doing a divide and conquer.*
>
> *First, give me for this build the complete ground up, ground zero,
> ... Sovereignty architecture that complements paras and SHAKTI*
>
> *Please give these requirements first. Let me see what’s getting
> built. There could be other changes needed.*

These statements are requirements INT-01 to INT-12. His standing
rulings, recorded across his estate, bind every build in it and are
requirements GOV-01 to GOV-17. Where a later section states a limit
(what one laptop can hold, what a text-mode renderer can be compared
with), the limit sits beside the requirement and never shrinks it.

# 4 The received documents: what is adopted and what is amended

R1 opens with the proposition that the work is larger than a universal
representation framework and closes with a generative computing
architecture reaching from physical logic to applications. R2 sets out a
build path from the author’s existing work in eight phases, a
coordinating repository, a first demonstrator, a schedule and three
architectural decisions. Both were read in full. Every point is mapped
below to a disposition and to the place in this document that carries
it. Received material is recorded as given; where it describes the
author’s assets, its descriptions stay unverified until intake (section
15). R3 extends the proposition to computational substrates and adds a
substrate specification, a second generative dimension, simulation as a
first-class target and cross-substrate compilation.

| **Ref**           | **Point in the received document**                                                                                                          | **Disposition**                       | **Where and why**                                                                                                                                                                                                                                                  |
|-------------------|---------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| R1 §1             | Representations become design variables; the architecture is generated rather than inherited.                                               | Adopted                               | The programme’s premise (section 2).                                                                                                                                                                                                                               |
| R1 §2             | The architecture is a dependency graph of representations and implementations, not a stack.                                                 | Adopted                               | DEP-01 to DEP-06. The graph runs on Ninja with field-level slices; no new build engine is written.                                                                                                                                                                 |
| R1 §3             | Every representation domain becomes replaceable, from physical logic to applications.                                                       | Adopted as scope, in stages           | The first build covers numeric, script structure, transliteration, symbolic pipeline and machine representations (SPC-07). Communication, cognitive and application representations follow (APP-01 and later amendments).                                          |
| R1 §4             | A representation change becomes an architectural change that can be compiled.                                                               | Adopted, within the author’s boundary | The harness generates the inputs existing tools take, never the tools (INT-01).                                                                                                                                                                                    |
| R1 §5             | Hindawi ILM is one part of the larger system.                                                                                               | Adopted, with a correction            | Hindawi’s transducers are fixed mappings and serve as oracles; the harness reads them and never regenerates them (GOV-03, GOV-17).                                                                                                                                 |
| R1 §6             | Physical limits (power, noise, timing, area, tolerances, cost) become constraints of synthesis.                                             | Adopted                               | The substrate section of every specification (section 9.3) and jugaad28’s substrate boundary (HDL-07).                                                                                                                                                             |
| R1 §8             | A meta-representational specification, not a universal intermediate representation.                                                         | Adopted                               | SPC-01. PANIR remains the author’s program IR; a harness specification describes a representation, never a program.                                                                                                                                                |
| R2 §1             | Five foundational assets: specification, transformation, dependency, generators, verification.                                              | Adopted, with a sixth                 | Integration with the estate (paras, Parashakti, Hindawi and the provenance tools) is the sixth asset (sections 7 and 8).                                                                                                                                           |
| R2 Phase 1        | Canonical representation specifications extracted from APCISR, AyeHandSum, Hindawi and one ILM script.                                      | Adopted; extraction amended           | Sources are retrieved and run first (M0). Extraction is descriptive and confirmed by executing the oracle (ORC-03). Hindawi is described as a pipeline of opaque transforms (P1.8).                                                                                |
| R2 Phase 2        | Make implementations derivable from specifications rather than maintain several hand-written ones.                                          | Amended                               | For a legacy asset the legacy source stays the implementation and is built unmodified for every target (GEN-01). Generation applies to representations without legacy code (GEN-02).                                                                               |
| R2 Phase 3        | A typed dependency graph and change propagation, not postponed.                                                                             | Adopted                               | DEP-02 keeps the seven edge types; M3 precedes all instruction and hardware work.                                                                                                                                                                                  |
| R2 Phase 4        | Do not force every script into APCISR’s existing 3x3 structure.                                                                             | Amended                               | The author’s 9-grid model is the structural family the script lane instantiates; his ruling of 20 October 2026 asks that the APCISR page explain how to build APCISR for other scripts with its grid model. Measured gaps become findings for his ruling (SCR-04). |
| R2 Phase 5        | A generated instruction-set simulator.                                                                                                      | Replaced                              | QEMU is the simulator (INT-02). The instruction set is generated as QEMU decodetree and helper inputs (ISA-05).                                                                                                                                                    |
| R2 Phase 5        | A general numeric representation model before any instruction set.                                                                          | Adopted                               | NUM-01 to NUM-05; balanced ternary is the first numeric demonstrator.                                                                                                                                                                                              |
| R2 Phase 6        | Software reference, then HDL and FPGA, then ASIC.                                                                                           | Adopted                               | HDL-01 to HDL-08. ASIC hand-off goes through jugaad28’s evidence rungs; native ternary circuits through zamin.                                                                                                                                                     |
| R2 Phase 7        | Generate boot, firmware, drivers, the operating system, assembler, linker, compiler backend and runtime.                                    | Replaced                              | Firmware and operating systems come from paras and Parashakti (INT-04); assembler, linker and compiler from GNU binutils and GCC (INT-03). The harness generates extension inputs only.                                                                            |
| R2 Phase 8        | Application requirements drive the generated infrastructure.                                                                                | Adopted as a later milestone          | APP-01 and APP-02 (M8).                                                                                                                                                                                                                                            |
| R2 §3             | A new coordinating repository, aye-representation-engine.                                                                                   | Amended                               | One tool, repsynth, in hmnsq by the author’s ruling (RD1, RD2). Existing repositories keep their histories and identities, as R2 itself says.                                                                                                                      |
| R2 §4             | First demonstrator: a self-regenerating representation system, shown with three changes.                                                    | Adopted and extended                  | D2 keeps the three changes and adds a change of trit encoding that crosses software, instruction and hardware artefacts (DEP-05).                                                                                                                                  |
| R2 §5             | A six-stage schedule.                                                                                                                       | Amended                               | Milestones M0 to M8, an iteration plan and mechanical acceptance (sections 11 to 13).                                                                                                                                                                              |
| R2 §6             | Binary is not the universal foundation; no single representation is a universal IR; semantic correctness is kept apart from optimisation.   | Adopted                               | The substrate section; SPC-01; one reference function per operation, many implementations (SPC-03).                                                                                                                                                                |
| R2 Phase 6, §7    | The existing Ubuntu laptop with 32 GB RAM suffices for the initial work.                                                                    | Amended                               | The author’s record gives 16 GB, nothing may be installed on the host, and disk is tight. All work runs in kept containers within a disk budget (GOV-01, PRF-02); the memory figure is measured at intake (P0.6, RD4).                                             |
| R2 §1, §3         | Pushkalāvatī as the formal rule-system and verification reference.                                                                          | Not adopted as a dependency           | The author’s review of those builds (15 October 2026) asked for corrections. No relationship is inferred.                                                                                                                                                          |
| R2 intro, §3, §7  | The machine-stack explainer, the APCISR WebAssembly trace and AyeHandSum’s mechanisms.                                                      | Recorded as given                     | They are not in the author’s record; intake locates and verifies them (ORC-04).                                                                                                                                                                                    |
| R2 Phase 7, §3    | AyeVDI as the deployment and orchestration reference.                                                                                       | Recorded; relationship proposed       | Visual wiring of the harness’s containers in M8 (P8.5).                                                                                                                                                                                                            |
| R3 §1             | The physical substrate becomes a design variable; mechanical, analogue electronic, quantum and digital electronic substrates are described. | Adopted                               | SUB-01 to SUB-05; section 9.9.                                                                                                                                                                                                                                     |
| R3 §1, §2, §4, §5 | Molecular and biochemical substrates.                                                                                                       | Excluded by the author’s decision     | No requirement, packet or test covers them (INT-07).                                                                                                                                                                                                               |
| R3 §2             | A Computational Substrate Specification of ten properties, distinct from the representation specification.                                  | Adopted and extended                  | Units, parameter evidence, capabilities and realisation models are added (SUB-01, SUB-03).                                                                                                                                                                         |
| R3 §3             | Two independent generative dimensions: what is computed and how it is physically realised.                                                  | Adopted                               | Computational model specifications (CMS-01) and substrate specifications (SUB-01) meet in the cross-substrate compiler (XSC-01); section 9.10.                                                                                                                     |
| R3 §4             | Simulation is a first-class target, with an executable computational model and a physical realisation model per substrate, compared.        | Adopted                               | MEC-02, ANA-02; section 9.11; the Test Plan’s reference cross-validation.                                                                                                                                                                                          |
| R3 §4             | A successful abstract simulation does not establish that a physical implementation is achievable.                                           | Adopted                               | XSC-04: simulated is never recorded as realised.                                                                                                                                                                                                                   |
| R3 §5             | Cross-substrate compilation of y = f(x), reporting supported, supported with restrictions, approximate, simulation only or not realisable.  | Adopted                               | XSC-01 to XSC-03; the capability matrix.                                                                                                                                                                                                                           |
| R3 §6             | Roles of existing work, including NI2A2, PEDLER and MSRR.                                                                                   | Recorded as given                     | NI2A2 appears in the author’s earlier work as the embodiment branch of PEDLER leading to ANGEL; MSRR is not in his record and is located at intake (ORC-04). No role is assigned beyond the record (section 7).                                                    |
| R3 §6             | Pushkalāvatī, the machine-stack explainer and AyeVDI in new roles.                                                                          | As for R2                             | The R2 rows above apply.                                                                                                                                                                                                                                           |
| R3 §7             | Six research programmes: representation, computational model, substrate, generative architecture, verification and experiment, application. | Adopted as an organising view         | Mapped to repositories in the Repository Map.                                                                                                                                                                                                                      |
| R3 §8             | An assessment of depth, breadth and complexity, and a statement of the ambition.                                                            | Recorded as given                     | Not a requirement; section 5.5 states the positioning.                                                                                                                                                                                                             |
| R3 close          | The system generates and studies many kinds of computer; it is not a universal computer.                                                    | Adopted                               | Section 5.5.                                                                                                                                                                                                                                                       |
| R3 images         | Third-party images embedded by link.                                                                                                        | Not carried                           | The package carries no third-party images.                                                                                                                                                                                                                         |

# 5 Market

## 5.1 The problem

Computing stacks inherit their representations: binary logic,
two’s-complement integers, IEEE binary floating point, byte-oriented
character encodings, shaping engines built around fonts, and instruction
encodings fixed by earlier choices. Every layer above takes these as
given. Changing one representation means coordinated edits across the
simulator, the assembler, the compiler, the libraries, the operating
system and the hardware, made by different teams with different tools
and checked, if at all, by separate test suites.

That cost shuts out three groups. Language and script communities whose
writing systems are served poorly by inherited encodings and shaping
assumptions, a gap the author’s Hindawi and ILM work has addressed at
the language level since 2004. Domains that need representations the
inherited stack lacks: ternary and other non-binary substrates, decimal
arithmetic, dynamic-base and reversible encodings, low-precision formats
for machine learning. And institutions and countries building
self-determined computing stacks on open instruction sets, who need to
own and change every layer without forking every tool.

## 5.2 Who it serves

| **Segment**                                                                                                    | **Need**                                                                                                         | **What the harness gives**                                                                                                                    |
|----------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| Sovereign and institutional stack builders, in major and low-resource economies alike                          | Change a representation without forking every tool, and show the stack works end to end                          | One specification drives QEMU, the GNU tools, operating-system boots and hardware units, with one conformance record                          |
| Custom-extension designers on RISC-V: start-ups, research groups, SoC teams                                    | Add instructions and see simulator, compiler and RTL agree                                                       | Generated decodetree files, helpers, intrinsics, opcode entries and RTL, all held to the same vectors                                         |
| Language and script communities and their standards bodies                                                     | Machine-level paths for their scripts and numerals, with evidence                                                | Grid tables per script, text-mode builds and published conformance status across the ILM registry                                             |
| Numeric-format researchers in machine learning, high-performance computing, finance and alternative substrates | Carry a format through the whole stack and measure it                                                            | Numeric specifications, oracle-checked arithmetic, instruction candidates with measured benefit, hardware cost                                |
| Educators and learners in computer architecture and compilers, in every country                                | Labs where a learner adds an instruction or changes an encoding and watches the stack follow                     | Teaching labs that run on one laptop from one command (APP-02)                                                                                |
| Low-resource laboratories                                                                                      | Work offline on a laptop and a low-cost FPGA board                                                               | Offline lanes after the first fetch, open flows, outputs readable on a phone                                                                  |
| Museums, historians and teachers of computing history                                                          | Show how differential analysers, mechanical calculators and analogue computers computed, and let people run them | Browser simulators of mechanical and analogue machines generated from specifications, with geometry and circuits exported for physical builds |
| Analogue and mixed-signal computing researchers                                                                | Compare an analogue program with circuit-level and digital solutions                                             | Patches checked against SPICE and Modelica references, with capability classes                                                                |
| Quantum computing learners and researchers                                                                     | Run one circuit across simulators and see where they agree                                                       | A circuit set compared across a browser library, Panini Q and reference simulators                                                            |

## 5.3 Global and low-resource reach

- No country, language, script, numeral system or locale is the default
  (GOV-14). The script lane covers the whole ILM registry, and its first
  working set spans South Asia, the Middle East, North and East Africa,
  South-East Asia, Europe and East Asia.

- The reference unit is one laptop, and every lane runs offline after
  its first fetch (GLB-01, GLB-02).

- Hardware routes use open flows and low-cost boards available
  worldwide; the ASIC route includes open process design kits from more
  than one country (GLB-04).

- Outputs meant for people run in a phone browser without a server
  (GLB-03).

- Toolchain and operating-system sources arrive through paras, which
  publishes the stack packages it has ingested with a branch per
  language.

## 5.4 Landscape

| **Category**                            | **Examples**                                                                                                                   | **Relation to the harness**                                                                                                                                                                   |
|-----------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Commercial processor design suites      | Suites built on architecture description languages such as CodAL and nML; vendor custom-extension frameworks such as Andes ACE | They generate simulators, compilers and RTL from one description, inside one vendor’s tools, for instructions. The harness targets open tools and covers representations beyond instructions. |
| Open ISA descriptions and formal models | riscv-opcodes; the RISC-V unified database; the Sail RISC-V model                                                              | Reused: allocation and collision checks, description format, an optional second semantics.                                                                                                    |
| Open simulators and toolchains          | QEMU; GNU binutils and GCC; LLVM                                                                                               | Reused as targets: the harness emits their inputs.                                                                                                                                            |
| Open hardware flows and cores           | Verilator, GHDL, Yosys, nextpnr, OpenROAD; cores with CV-X-IF                                                                  | Reused for simulation, synthesis, co-simulation and physical design.                                                                                                                          |
| Text processing                         | Unicode data, CLDR, ICU, HarfBuzz, Noto fonts                                                                                  | Reused as references; the harness adds the 9-grid structural path and machine-level paths for scripts.                                                                                        |
| Build systems                           | Ninja, Bazel, Nix                                                                                                              | Ninja reused as the executor; the harness adds field-level slices of representation specifications.                                                                                           |
| Equation-based and multibody modelling  | Modelica with OpenModelica; Project Chrono; MBDyn                                                                              | Reused as references for the mechanical and analogue simulators.                                                                                                                              |
| Circuit simulation                      | ngspice; Xyce                                                                                                                  | Reused as references for analogue patches.                                                                                                                                                    |
| Quantum software                        | Qiskit with Qiskit Aer; QuTiP; browser circuit libraries; OpenQASM 3                                                           | Reused: interchange format, references and the browser face.                                                                                                                                  |
| Browser physics and circuit simulators  | Educational simulators of one substrate each                                                                                   | The harness generates the machine from a specification, compares substrates and records evidence.                                                                                             |

Landscape entries are the drafter’s knowledge and are refreshed at
intake; nothing here states any product’s current commercial status.

## 5.5 Positioning

The harness is a tool in the manner of paras and BURP: installed with
pipx, run inside containers, pointed at specifications, and publishing
its evidence. It sits between the author’s language and script work
(Hindawi, Romenagri, APCISR, ILM, tajziya), his sovereign stack (paras,
Parashakti) and his hardware elements (jugaad28, zamin), and joins them
through one representation specification. Three properties set it apart:
it generates nothing an existing tool already does; legacy
implementations remain the authority; and every claim carries its
evidence state. From version 0.2.0 it generates and studies many kinds
of computer across physical substrates; it is not one universal machine.

## 5.6 Success measures

- Demonstrators D1 to D7 reproduced from a clean checkout on the
  reference unit by someone other than the implementer.

- The number of representation specifications at state verified.

- The number of scripts with published conformance status, and the share
  reviewed by native readers.

- Instructions promoted on measured benefit, and hardware units with
  synthesis results.

- Issues and contributions from outside the estate, once the author
  publishes (RD7).

# 6 Scope

## 6.1 In the first build

- The specification meta-model, its validator and five specification
  families (SPC-07).

- Oracle runners for Hindawi, Romenagri, APCISR and AyeHandSum.

- Software builds and conformance on native, WebAssembly and Python
  targets.

- The dependency and impact engine.

- Tier A: RISC-V custom extensions in QEMU, with GNU tools by the
  zero-patch and patch paths, and Parashakti’s xv6-riscv and Linux
  booted with them.

- Hardware units in SystemVerilog and VHDL, simulated, synthesised for
  an open FPGA flow, co-simulated with an open core, and handed to
  jugaad28 or zamin.

- The script lane across the ILM registry.

- Tier B: two standalone machines, binary and balanced ternary, as new
  QEMU targets.

- Provenance, reporting, the status page and the command-line tool.

- One application example and one teaching lab.

- Substrate and computational-model specifications, and the shared web
  core (hmnsq/subcore).

- A mechanical computer simulator and an analogue computer simulator in
  the browser, each with physical realisation models and reference
  cross-checks.

- Cross-substrate compilation with capability reports, and the quantum
  lane through Panini Q.

- The optical substrate specification; its simulator follows in a later
  milestone.

## 6.2 Not built by the harness, and what serves instead

| **Not built by the harness**               | **Served by**                                                                                                |
|--------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| Instruction-set simulator                  | QEMU                                                                                                         |
| Assembler, disassembler and linker         | GNU binutils; for Tier B test images, an existing retargetable assembler (customasm)                         |
| Compiler and code generator                | GCC cross compilers; LLVM where Parashakti uses it                                                           |
| Firmware and boot loaders                  | paras and Parashakti; the firmware bundled with the pinned QEMU where Parashakti carries none for the target |
| Operating systems, C libraries and drivers | paras and Parashakti: xv6-riscv, Linux, MINIX and the rest of the stack                                      |
| Ingestion of sources into human languages  | paras and BURP                                                                                               |
| Keyword localisation and transducers       | Hindawi                                                                                                      |
| Transliteration                            | Romenagri                                                                                                    |
| Program intermediate representation        | PANIR, the author’s                                                                                          |
| Text shaping engine                        | HarfBuzz, as a reference                                                                                     |
| Physical design and tape-out               | jugaad28 for binary CMOS; zamin for native ternary circuits                                                  |
| Sealing, attestation and minting           | The author’s estate procedure on his machine (zops, Candor, Tok DOI, misty)                                  |
| A GCC port for a Tier B machine            | A later amendment (ISB-04)                                                                                   |
| Rigid-body and multibody engines           | Existing JavaScript libraries in the browser; Project Chrono and OpenModelica as references                  |
| Circuit simulators                         | ngspice, with Xyce as an option, as references                                                               |
| Equation-based solvers                     | Library ODE solvers in the browser; OpenModelica as the reference                                            |
| Quantum simulators                         | Panini Q, an existing browser circuit library, Qiskit Aer and QuTiP                                          |
| CAD kernels                                | JSCAD in the browser for gear, cam and frame geometry                                                        |

## 6.3 Boundaries

- The harness never pushes, publishes or mints, and never creates
  repositories.

- It never edits a legacy source, a canon table or a paras fork.

- It installs nothing on the host.

- It makes no claim about silicon from simulation or synthesis reports.

- Molecular and biochemical substrates are outside the programme
  (INT-07).

- No mechanical or analogue machine is claimed as built; simulation
  results stay at state simulated until measurements exist (XSC-04).

# 7 What already exists

## 7.1 The author’s assets

Rows come from the author’s records. The forge is the authority, and
intake checks every row against it (P0.2).

| **Asset**                    | **Where**                                                             | **What it gives the harness**                                                                                                     | **Relationship**                                                                                     |
|------------------------------|-----------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| Hindawi 2026.10              | hindawiai/hindawi2026.10                                              | Shaili transducers and their drivers, the drop-in compiler front end, numerals through its filters; localised test programs       | Oracle, read-only                                                                                    |
| Romenagri                    | hindawiai/chintamani (Romenagri folder); project-ilm/romenagri2026.10 | The transliteration kernel: ASCII-7, diacritic-free, bijective and compiler-safe                                                  | Oracle, read-only                                                                                    |
| APCISR                       | hindawiai/chintamani (APCISR folder)                                  | The text-mode renderer for Indic scripts on the 9-grid (3 × 3) model                                                              | Oracle, and the engine the script lane builds per script                                             |
| AyeHandSum                   | The author’s ayehandsum or ayesha repositories                        | Dynamic encoding, as R2 describes it                                                                                              | Oracle once located                                                                                  |
| Machine-stack explainer      | Not in the author’s record                                            | An execution and rendering trace, as R2 describes it                                                                              | Located at intake                                                                                    |
| paras and Parashakti         | hmnsq/paras; paras-ilm on PyPI                                        | Upstream sources as hmnsq forks with a branch per language; the sovereign stack with xv6, MINIX, Linux, GCC, LLVM and WebAssembly | Source of toolchain, firmware and operating-system sources                                           |
| BURP                         | hmnsq/burp; burp-ilm on PyPI                                          | Ingestion of a file, a project and its build system; missing-item reports                                                         | Carries the harness’s gaps to paras’s next round                                                     |
| chandah                      | project-ilm/chandah                                                   | Raising and lowering layers over Hindawi’s Sanskrit layer                                                                         | An example of a reversible transformation chain; no dependency in the first build                    |
| tajziya and the ILM registry | zistgah/tajziya, with the registry pinned from project-ilm/ilm.codes  | 7,867 languages and 226 scripts; language and script packages                                                                     | The script list                                                                                      |
| zamin                        | zistgah/zamin                                                         | Ternary logic hardware: MTCMOS ternary cells, a TEL accumulator, a SPICE library, gdsfactory layout                               | Proposed: the path for native ternary circuits                                                       |
| jugaad28                     | zistgah/jugaad28                                                      | IC descriptors, evidence rungs from CONCEPT to SILICON, a dockerised open-PDK laboratory                                          | Proposed: ASIC hand-off for binary units                                                             |
| dhancha                      | zistgah/dhancha                                                       | Unknown semantics, packets, rungs and ten spine invariants                                                                        | Proposed: its Unknown semantics (SPC-05) and packet discipline reused                                |
| PANINI family and PANIR      | zistgah/panini and related repositories                               | Programming intent and the program IR                                                                                             | Boundary only                                                                                        |
| Provenance tools             | zops, Candor, Tok DOI, misty-doi, satsneha                            | Sealing, attestation, minting, assurance reports                                                                                  | Run records in Candor’s form; satsneha in reporting mode                                             |
| AyeVDI                       | ayevdi/ayevdi                                                         | Wiring of container instances by their inputs and outputs                                                                         | Proposed: wiring of the harness’s containers (M8)                                                    |
| Panini Q                     | zistgah/paniniq                                                       | The author’s quantum-simulation realisation backend of PANINI: oscillator substrate, PEDLER engine, quantum validation            | Proposed: the quantum lane’s backend where its interface covers an operation (QNT-01, QNT-03)        |
| PEDLER                       | Point Event-Driven Learner (2001); project-ilm/qedler                 | A balanced ternary lineage and an event-driven research programme                                                                 | Recorded: the balanced ternary demonstrators share its number system; no other relationship inferred |
| NI2A2                        | Not located as a repository                                           | The embodiment branch of PEDLER leading to ANGEL, in the author’s earlier work                                                    | Located at intake; no role assigned                                                                  |
| MSRR                         | Not in the author’s record                                            | Modular physical and robotic systems, as R3 describes it                                                                          | Located at intake                                                                                    |

## 7.2 The reference unit

The reference unit is the author’s laptop: an ASUS TUF A15 with an AMD
Ryzen 7 7445HS (the operating system reports 12 processors), an NVIDIA
RTX 3050 Laptop GPU with 4 GB, and 16 GB of DDR5 memory according to the
author’s record. R2 states 32 GB; the conflict is recorded and settled
by measurement at intake (P0.6, decision RD4). The author recorded 10 to
15 GB of free disk on 18 October 2026, and nothing may be installed on
the host: everything installs inside Docker containers that are created
once and kept. The harness’s budgets (PRF-02, TCH-03) follow from these
figures.

# 8 External tools reused

These are the wheels. The harness drives them and generates their
inputs. Licences are as the drafter records them and are confirmed from
each project’s own licence file at intake (P0.4); a difference found
there replaces the entry.

| **Tool**                                                               | **Role in the harness**                                                                                         | **What the harness generates or drives**                                                                                                | **Licence (confirmed at intake)**                                                        |
|------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|
| QEMU                                                                   | Simulates every generated instruction set in user and system mode; counts instructions through TCG plugins      | Decodetree files, translation functions, helpers, CPU properties and build entries (Tier A); a new target with a minimal board (Tier B) | GPL-2.0 for the whole; file licences vary                                                |
| GNU binutils                                                           | Assembler, disassembler and linker                                                                              | .insn macros (zero patch); opcode entries, extension registration and gas tests (patch)                                                 | GPL-3.0-or-later                                                                         |
| GCC                                                                    | Cross compilers for RV64 and RV32                                                                               | Intrinsics header (zero patch); builtins and machine-description patterns (patch)                                                       | GPL-3.0-or-later with the GCC Runtime Library Exception                                  |
| LLVM                                                                   | Second compiler carried by Parashakti                                                                           | TableGen definitions (MAY)                                                                                                              | Apache-2.0 with LLVM exception                                                           |
| riscv-opcodes; RISC-V unified database                                 | Allocation and collision checks; description format                                                             | Read only                                                                                                                               | Per project                                                                              |
| Sail RISC-V model                                                      | Second reference semantics                                                                                      | Sail clauses (MAY)                                                                                                                      | BSD-2-Clause                                                                             |
| xv6-riscv, Linux, BusyBox                                              | Operating systems and user space from Parashakti                                                                | Derived builds with test programs                                                                                                       | MIT; GPL-2.0; GPL-2.0                                                                    |
| OpenSBI                                                                | Firmware for Linux on the QEMU virt machine, as bundled with QEMU, where Parashakti carries none for the target | Used unchanged                                                                                                                          | BSD-2-Clause                                                                             |
| customasm                                                              | Assembler for Tier B test images                                                                                | Generated instruction definitions                                                                                                       | Apache-2.0                                                                               |
| Verilator, GHDL, cocotb                                                | Hardware simulation from shared vectors                                                                         | cocotb tests                                                                                                                            | LGPL-3.0 or Artistic-2.0; GPL-2.0-or-later; BSD-3-Clause                                 |
| Yosys, SymbiYosys, nextpnr                                             | Synthesis reports, bounded proofs, place and route                                                              | Scripts                                                                                                                                 | ISC                                                                                      |
| PandA Bambu                                                            | Optional route from reference functions to hardware                                                             | Synthesis runs                                                                                                                          | GPL-3.0                                                                                  |
| OpenHW CV-X-IF with CV32E40X or CVA6                                   | Coprocessor interface and co-simulation core                                                                    | Wrapper                                                                                                                                 | Solderpad Hardware Licence 0.51                                                          |
| OpenROAD and open process design kits                                  | Physical design, through jugaad28                                                                               | Hand-off descriptors                                                                                                                    | BSD-3-Clause; per kit                                                                    |
| Unicode Character Database, CLDR, ICU                                  | Script properties, exemplar sets, reference normalisation                                                       | Read only                                                                                                                               | Unicode-3.0                                                                              |
| HarfBuzz, FreeType, Noto fonts                                         | Reference shaping and reference fonts                                                                           | Read only                                                                                                                               | MIT; FTL or GPL-2.0; OFL-1.1                                                             |
| SoftFloat and TestFloat, GMP, MPFR, libdecnumber                       | Numeric oracles                                                                                                 | Read only                                                                                                                               | BSD-3-Clause; LGPL-3.0-or-later or GPL-2.0-or-later; LGPL-3.0-or-later; per distribution |
| Hypothesis, Z3                                                         | Property-based tests; bounded proofs                                                                            | Tests                                                                                                                                   | MPL-2.0; MIT                                                                             |
| Ninja                                                                  | Executes the dependency graph                                                                                   | Generated build files                                                                                                                   | Apache-2.0                                                                               |
| wasi-sdk or Emscripten; cffi                                           | WebAssembly builds; Python bindings                                                                             | Build files                                                                                                                             | Apache-2.0 with LLVM exception; MIT or NCSA; MIT                                         |
| Docker                                                                 | Kept containers                                                                                                 | Dockerfiles                                                                                                                             | Per project                                                                              |
| in-toto and OpenTimestamps, through Candor and Tok DOI                 | Run attestations and timestamps                                                                                 | Statements                                                                                                                              | Per project                                                                              |
| math.js                                                                | Expression parsing, units, complex numbers, matrices and ODE solving in the browser, each confirmed at intake   | Vendored source; admission by BURP round trip                                                                                           | Apache-2.0                                                                               |
| js-yaml                                                                | Reading YAML specifications and programs in the browser                                                         | Vendored source                                                                                                                         | MIT                                                                                      |
| three.js                                                               | Three-dimensional views of mechanisms                                                                           | Vendored source                                                                                                                         | MIT                                                                                      |
| JSCAD                                                                  | Gear, cam and frame geometry; STL and 3MF export                                                                | Vendored source                                                                                                                         | MIT                                                                                      |
| planck.js                                                              | Optional two-dimensional contact dynamics for linkages                                                          | Vendored source                                                                                                                         | MIT                                                                                      |
| uPlot                                                                  | Scope and plotter traces                                                                                        | Vendored source                                                                                                                         | MIT                                                                                      |
| A browser quantum circuit library (candidates: quantum-circuit, Quirk) | Web face of the quantum lane                                                                                    | Vendored source                                                                                                                         | MIT; Apache-2.0                                                                          |
| OpenModelica with the Modelica Standard Library                        | Reference simulation of mechanical and analogue models                                                          | Generated Modelica models                                                                                                               | OSMC-PL or GPL-3.0; BSD-3-Clause                                                         |
| ngspice; Xyce                                                          | Circuit-level reference for analogue patches                                                                    | Generated SPICE netlists                                                                                                                | BSD-3-Clause with exceptions; GPL-3.0                                                    |
| Project Chrono (PyChrono)                                              | Three-dimensional multibody reference                                                                           | Generated scripts                                                                                                                       | BSD-3-Clause                                                                             |
| Qiskit with Qiskit Aer; QuTiP; OpenQASM 3                              | Quantum references and interchange                                                                              | Generated circuits                                                                                                                      | Apache-2.0; BSD-3-Clause; Apache-2.0                                                     |
| Perceval or Strawberry Fields                                          | Photonic reference for the optical lane (later)                                                                 | Generated circuits                                                                                                                      | MIT; Apache-2.0                                                                          |
| mpmath                                                                 | High-precision reference solutions                                                                              | Oracle scripts                                                                                                                          | BSD-3-Clause                                                                             |
| Embench-IoT                                                            | Binary performance workloads                                                                                    | Built with the GNU cross tools for RV32 and RV64                                                                                        | GPL-3.0                                                                                  |
| Node.js; Playwright                                                    | Headless runs of the simulators; browser tests on three engines and phone profiles                              | Test scripts                                                                                                                            | MIT; Apache-2.0                                                                          |

# 9 Architecture

## 9.1 Shape

The harness is a set of lanes around one store of specifications. A lane
reads specifications, emits artefacts in the native input formats of
existing tools, runs those tools in kept containers and checks the
results against shared vectors. Three engines run across every lane: the
dependency and impact engine decides what a change touches; the
conformance engine holds every target to the same vectors; the
provenance writer records every run. Lanes are independent: a lane that
fails stops itself and reports, and every other lane carries on.

## 9.2 Components

| **ID** | **Component**                      | **Owns**                                                                                                 | **Built on**                                                    |
|--------|------------------------------------|----------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------|
| H1     | Specification store and meta-model | YAML specifications, the JSON Schema, canonical form, paths, hashes, not_established values              | A YAML parser and a JSON Schema validator                       |
| H2     | Oracle runners                     | Pinned legacy checkouts, their builds and drivers, corpora                                               | The assets’ own build systems                                   |
| H3     | Software lane                      | Glue for legacy builds, generated sources for new representations, WebAssembly and Python builds         | clang or wasi-sdk, Emscripten, cffi                             |
| H4     | Dependency and impact engine       | Read declarations, slices, the edge list, Ninja files, impact reports                                    | Ninja                                                           |
| H5     | Conformance engine                 | Vectors, runners, the differ, property tests, bounded proofs, mutation self-tests                        | Hypothesis, Z3                                                  |
| H6     | Tier A lane                        | Allocation ledger; QEMU, binutils, GCC and Hindawi construct outputs                                     | QEMU, binutils, GCC, riscv-opcodes                              |
| H7     | Operating-system lane              | Derived builds of xv6-riscv and Linux, boot scripts, the compatibility matrix                            | Parashakti sources, QEMU                                        |
| H8     | Hardware lane                      | SystemVerilog and VHDL units, cocotb tests, synthesis reports, the CV-X-IF wrapper, hand-off descriptors | Verilator, GHDL, cocotb, Yosys, nextpnr, an open core, jugaad28 |
| H9     | Script lane                        | Candidate grid tables, APCISR builds per script, conformance status                                      | APCISR, Unicode data, CLDR, HarfBuzz, Noto fonts                |
| H10    | Numeric lane                       | Numeric specifications, reference functions, numeric oracles                                             | GMP, MPFR, SoftFloat, libdecnumber                              |
| H11    | Tier B lane                        | Machine specifications, generated QEMU targets, assembler definitions                                    | QEMU, customasm, binutils                                       |
| H12    | Provenance and reporting           | Run records, in-toto statements, the status page, RESUME.md                                              | Candor’s statement form; satsneha in reporting mode             |
| H13    | Command-line tool                  | repsynth and its subcommands, progress, resume                                                           | Python, pipx                                                    |

## 9.3 The specification meta-model

Every representation is one YAML document with the sixteen sections
below (SPC-01). A value that is not known is written as not_established
with its reason, and nothing downstream may consume it (SPC-05).

| **Section**     | **What it holds**                                                                                                                                 |
|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------|
| identity        | Identifier, version, family and title; equality and canonical form of the represented entities                                                    |
| domain          | The set of entities represented, with an enumerator when the set is finite                                                                        |
| structure       | Constituents and their arrangement: grid cells, digit positions, fields                                                                           |
| encoding        | The map from entity to code: bit layouts for machine encodings, symbol sequences for text                                                         |
| decoding        | The inverse map, or a partial map with defined error behaviour                                                                                    |
| semantics       | Reference functions by name, signature and source path, with a plain statement of meaning                                                         |
| operations      | Computational operations, each with its reference function, operand classes and whether it is an instruction candidate                            |
| composition     | How elements combine into larger units                                                                                                            |
| transformations | Named maps to other specifications, with what each preserves: lossless or lossy, and which invariants hold                                        |
| constraints     | Validity predicates, given as reference functions                                                                                                 |
| substrate       | Logical substrate (binary, ternary, other), word widths, packing and implementation limits, with not_established where nothing is measured        |
| interfaces      | What this specification imports from and exports to others                                                                                        |
| verification    | Properties to check (round trip, bijection on the domain, homomorphism with integer arithmetic, idempotent normalisation) and the method for each |
| generation      | Which generators apply, with their parameters: opcode space, target profiles, hardware route                                                      |
| evolution       | The compatibility class of each change and the rules for retiring encodings                                                                       |
| provenance      | Oracle repository, commit and path; extraction method; evidence state                                                                             |

## 9.4 One semantic source

Each operation’s meaning is one reference function in restricted C11
(SPC-03). The same function is compiled into the software targets,
called from the QEMU helper that implements the instruction, offered to
the high-level synthesis route, and used to compute every expected value
in the vectors. Its correctness is established against an independent
oracle: the legacy implementation where one exists, arbitrary-precision
arithmetic and stated properties where none does. A disagreement
anywhere downstream is therefore a defect in one target, never a second
opinion about meaning.

## 9.5 What is generated for each target

| **Target**                  | **Generated input**                                                                                    | **Consumed by**                     | **Checked by**                                                |
|-----------------------------|--------------------------------------------------------------------------------------------------------|-------------------------------------|---------------------------------------------------------------|
| Native, WebAssembly, Python | Glue and build files (legacy); C11 sources (new representations)                                       | clang, wasi-sdk or Emscripten, cffi | Vectors on every target                                       |
| QEMU, Tier A                | Decodetree files, translation functions, helper declarations and bodies, a CPU property, build entries | The QEMU build                      | Vectors in user and system mode; the illegal-instruction test |
| GNU binutils                | .insn macros; opcode entries, extension registration, gas tests                                        | gas, objdump                        | Assemble and disassemble round trip                           |
| GCC                         | Intrinsics header; builtins and machine-description patterns                                           | gcc                                 | Compiled test programs                                        |
| Hindawi                     | A construct list of new mnemonics                                                                      | Hindawi’s own process               | Nothing in the harness: the list is Hindawi’s input           |
| Hardware                    | SystemVerilog and VHDL units; cocotb tests                                                             | Verilator, GHDL, Yosys, nextpnr     | Vectors; synthesis reports                                    |
| jugaad28                    | Descriptors at rung RTL or VERIFIED                                                                    | The jugaad28 laboratory             | jugaad28’s own validation                                     |
| APCISR                      | Candidate grid tables per script, in APCISR’s own format                                               | The APCISR build                    | HarfBuzz and grapheme-cluster conformance                     |
| QEMU, Tier B                | A target directory, helpers and a minimal board                                                        | The QEMU build                      | Bare-metal vectors                                            |
| customasm                   | An instruction definition                                                                              | customasm                           | Encoding round trip against the specification                 |

## 9.6 Dependency and impact

Every generator declares the specification paths it reads. The slicer
writes each declared path’s canonical content to a slice file and
rewrites the file only when that content changes. The harness writes a
Ninja file whose edges run generators from slices to artefacts with
restat set, so an artefact that comes out unchanged stops the cascade.
The edge list records seven typed relationships (depends_on, implements,
transforms, preserves, accelerates, requires, validates) between
specifications, implementations, tools and tests, and the impact command
reads it to predict what a change will regenerate and which conformance
cells will rerun. After the build, the prediction is compared with the
set of artefacts whose hashes changed; any difference is a defect in a
declaration. For legacy oracles, a deliberate change carries an
expected-divergence set, so the harness can tell an intended difference
from a regression.

## 9.7 Containers

| **Container**                     | **Contents**                                                                                 | **Notes**                                 |
|-----------------------------------|----------------------------------------------------------------------------------------------|-------------------------------------------|
| repsynth-base                     | Python, build tools, Ninja, the JSON Schema validator, Hypothesis, Z3                        | Runs the tool itself                      |
| repsynth-cross                    | Distribution packages of the RISC-V GNU cross toolchains and QEMU user and system emulators  | The zero-patch lane                       |
| repsynth-qemu                     | QEMU sources at the pinned release; patched builds with plugins                              | Bounded build cache                       |
| repsynth-gnu                      | binutils and GCC sources at pinned releases; patched builds                                  | Bounded build cache                       |
| repsynth-os                       | Derived builds of xv6-riscv and Linux; BusyBox; initramfs tools                              | Sources from paras forks first            |
| repsynth-hdl                      | Verilator, GHDL, cocotb, Yosys, SymbiYosys, nextpnr, an open CV-X-IF core                    | No vendor tools required                  |
| repsynth-script                   | HarfBuzz, FreeType, ICU, Unicode data, CLDR, Noto fonts                                      | Versions pinned and hashed                |
| jugaad28 laboratory               | jugaad28’s own simulation, analogue and place-and-route images                               | Used as jugaad28 defines them             |
| substrate-node (in hmnsq/subcore) | Node.js at a pinned LTS release, Python with burp-ilm and mpmath, Playwright browser engines | Track S tests and the BURP probe          |
| substrate-ref (in hmnsq/subcore)  | OpenModelica, ngspice, Project Chrono, Qiskit Aer, QuTiP                                     | Built when first needed and kept (PRF-05) |

## 9.8 Repository layout

repsynth/

spec/schema/ meta-model (JSON Schema 2020-12)

spec/reps/\<family\>/\<id\>.yaml representation specifications

spec/ref/\<id\>/\*.c reference functions (restricted C11)

oracles/\<asset\>/ runners for legacy assets (pinned, read-only
checkouts)

gen/\<target\>/ generators, one directory per target

graph/ edges.txt, slices/, generated build.ninja

conformance/vectors/ shared vectors

conformance/runners/ one runner per target

conformance/mutants/ planted defects for self-tests

lanes/\<lane\>/ lane drivers: toolchain, qemu, os, hdl, script, isa-b

containers/ Dockerfiles

ledger/ encoding allocation ledger

reports/ generated reports and status data

docs/ generated status page

ops/verify.sh release gate (essentials only)

ops/selftest.sh mutation self-tests

RESUME.md generated, never edited by hand

README.md NOTICE.md CONTRACT.md CONTEXT.md AGENTS.md CITATION.cff
VERSION

## 9.9 Substrate specification

A substrate specification describes a physical medium of computation
(SUB-01). It is distinct from a representation specification: balanced
ternary is a representation, while detent wheels, multi-valued logic and
two-bit binary encodings are substrates that can realise it. A
realisation record links the two: the representation, the substrate, the
mechanism and the capability class (SUB-02). Every physical parameter
carries its evidence state (SUB-03).

| **Section**           | **What it holds**                                                                                   |
|-----------------------|-----------------------------------------------------------------------------------------------------|
| medium                | Mechanical, analogue electronic, digital electronic, quantum or optical                             |
| state space           | Discrete, continuous, quantum (a Hilbert space and its dimension) or hybrid, with ranges and units  |
| state transitions     | What physically changes the state: shaft rotation, capacitor charge, gate application, interference |
| operations            | The primitive operations the medium offers, each with its physical mechanism                        |
| observability         | How state is read, with resolution and the disturbance reading causes                               |
| controllability       | How inputs and operations are applied: cranks, potentiometers, pulses, phase settings               |
| temporal behaviour    | Latency, bandwidth, settling, evolution time and the admissible time scaling                        |
| noise and uncertainty | Backlash, friction, drift, offset, thermal noise, decoherence, with their models                    |
| resource constraints  | Energy, size, material, temperature, voltage range, qubit count                                     |
| interface             | How values cross to other substrates: encoders, converters, measurement                             |
| units                 | UCUM codes for every quantity                                                                       |
| parameters            | Values with evidence states: measured, sourced, assumed or not established                          |
| capabilities          | Which computational-model operations the substrate realises, and how                                |
| realisation models    | The executable model and the physical realisation model it supports                                 |
| provenance            | Sources, commits and evidence states                                                                |

## 9.10 Two dimensions and computational models

What is computed and how it is physically realised are independent
design variables (R3 §3). A computational model specification states
what is computed without reference to a substrate (CMS-01): state
variables, inputs, outputs, transitions and semantics. Continuous models
are equations in one restricted expression grammar, defined once and
shared by the browser evaluator and the Modelica and SPICE generators
(CMS-02); discrete models use reference functions (SPC-03); quantum
models are OpenQASM 3 circuits. The cross-substrate compiler turns a
model into a program for a substrate:

| **Substrate**       | **Program form**                                                                             | **Example**                                                      |
|---------------------|----------------------------------------------------------------------------------------------|------------------------------------------------------------------|
| Mechanical          | Mechanism configuration: shafts, gears, differentials, integrators, cams, counters           | A differential analyser set-up for the harmonic oscillator       |
| Analogue electronic | Patch: integrators, summers, coefficients, multipliers, comparators, with initial conditions | The same oscillator as two integrators and an inverter in a loop |
| Digital electronic  | An instruction sequence for a Tier A profile, or a hardware unit                             | A fixed-point integration loop on RV64 in QEMU                   |
| Quantum             | An OpenQASM 3 circuit or a Hamiltonian description                                           | A circuit set; a truncated oscillator Hamiltonian                |
| Optical             | An interferometer mesh with phase settings                                                   | A linear map as a mesh of Mach-Zehnder interferometers           |

## 9.11 Executable and physical models per substrate

| **Substrate**       | **Executable computational model**                            | **Physical realisation model**                                                                                       | **Browser face**                                                             | **References**                                          |
|---------------------|---------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------|---------------------------------------------------------|
| Mechanical          | Ideal kinematic network: constraints and integrator equations | Lumped dynamics (inertia, compliance, backlash, friction, integrator slip); geometry for printing                    | hmnsq/mechsim                                                                | OpenModelica (rotational and multibody); Project Chrono |
| Analogue electronic | Ideal computing elements assembled into an ODE system         | Op-amp circuits with finite gain and bandwidth, offset, drift, saturation, tolerances and noise; a bill of materials | hmnsq/anasim                                                                 | ngspice; OpenModelica                                   |
| Digital electronic  | Reference functions and instruction semantics                 | RTL and physical design inputs                                                                                       | Status pages and WebAssembly builds of reference functions in hmnsq/repsynth | QEMU, Verilator, GHDL                                   |
| Quantum             | Circuits and Hamiltonians                                     | Noise channels and connectivity taken from references                                                                | An existing browser circuit library, in hmnsq/repsynth                       | Panini Q, Qiskit Aer, QuTiP                             |
| Optical             | Linear transfer matrices                                      | Meshes with loss and phase error                                                                                     | hmnsq/optisim (M13)                                                          | Perceval or Strawberry Fields                           |

## 9.12 Cross-substrate compilation

The compiler takes a computational model and a substrate specification
and returns a program for that substrate, its scale factors, and one
capability class with its evidence (XSC-01, XSC-02). Analogue programs
need magnitude scaling, so every variable stays within the machine unit,
and time scaling, so the fastest dynamics fit the elements; mechanical
programs use ranges of shaft travel and gear ratios as scale factors.
The compiler records every factor and undoes them for display and
comparison.

| **Class**                               | **Assigned when**                                                                             | **Evidence carried**                                       |
|-----------------------------------------|-----------------------------------------------------------------------------------------------|------------------------------------------------------------|
| Supported                               | Every operation maps to a substrate element and the result meets the Test Plan bound          | The mapping and the comparison record                      |
| Supported with restrictions             | The bound is met only within stated ranges of time, magnitude or horizon                      | The ranges, and comparison records inside and outside them |
| Approximate                             | A bound wider than the Test Plan default is met                                               | The achieved bound and its comparison record               |
| Simulation only                         | No physical realisation model exists, or the model exceeds the substrate’s declared resources | The missing element or the exceeded resource               |
| Not realisable under stated constraints | A declared constraint is violated                                                             | The constraint, named                                      |

A class is never assigned without its record, and a simulated result is
never recorded as physically realised (XSC-04).

## 9.13 Web-first builds and ingestibility

- Simulators and browser faces are plain JavaScript ES modules that run
  from static files with no build step, bundler or transpiler (WEB-01).

- Third-party libraries are vendored as readable source with licence and
  provenance, and nothing loads from a CDN at run time (WEB-02).

- A library is relied on once BURP returns its sources byte for byte;
  each library’s admission state is recorded, and BURP’s gaps go to its
  next round (WEB-03). BURP’s coverage of JavaScript is probed first
  (P9.1).

- No eval, no new Function and no generated code; WebAssembly only from
  ingested sources (WEB-04).

- Offline after first load and usable on a phone, with long runs in Web
  Workers (WEB-05).

- The same modules run headless in Node.js for tests (WEB-06).

- The Implementation Guidelines (document 02) give the full rules, the
  admission procedure and the candidate libraries.

# 10 Requirements

MUST is mandatory; SHOULD is expected unless a recorded reason says
otherwise; MAY is optional. Every requirement is at AyeKnow state
defined. The last column names the packet, demonstrator or record that
verifies it.

## 10.1 Author’s intent (INT)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                          | **Verified by**                                 |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------|
| INT-01 | MUST      | The harness generates the inputs that existing tools take and drives those tools. It contains no instruction-set simulator, assembler, linker, compiler, firmware or operating system of its own.                                                                        | Wheel census (PRV-04); review of each iteration |
| INT-02 | MUST      | Every generated or extended instruction set runs in QEMU.                                                                                                                                                                                                                | D3, D7                                          |
| INT-03 | MUST      | The toolchain for every generated instruction set is GNU binutils and GCC as cross tools; the harness generates only their inputs: assembler macros, opcode entries, intrinsics and machine-description patterns.                                                        | D3                                              |
| INT-04 | MUST      | Firmware and operating systems come from paras and the Parashakti stack. The harness builds and boots them unchanged in derived builds and writes neither.                                                                                                               | Operating-system lane run records               |
| INT-05 | MUST      | The build starts from the author’s existing work, retrieved from the forge and pinned by commit, before anything is designed.                                                                                                                                            | P0.2 asset register                             |
| INT-06 | MUST      | The build is carried out by an external implementer in numbered iterations against this document, with acceptance decided by commands and their records.                                                                                                                 | Section 13                                      |
| INT-07 | MUST      | The programme extends to mechanical, analogue electronic, quantum and optical substrates beside digital electronic ones. Molecular and biochemical substrates are outside it.                                                                                            | Scope; SUB-04                                   |
| INT-08 | MUST      | Mechanical and analogue computers are realised at least in simulation, by simulators that an external implementer builds with free and open-source tools.                                                                                                                | D8, D9                                          |
| INT-09 | MUST      | Builds are web first: plain JavaScript that runs in a browser with no build step. JavaScript libraries are used only when paras and BURP can ingest their sources.                                                                                                       | WEB-01 to WEB-06; D12                           |
| INT-10 | MUST      | The programme is delivered as one package: the Sovereignty Architecture, this MRD, the Implementation Guidelines, the Repository Map, the Build Plan and the Test Plan, with briefs for the implementers.                                                                | Package index                                   |
| INT-11 | MUST      | Binary and balanced ternary both run, through every lane where the lane applies. Binary is the performance baseline: every performance figure is reported beside the binary implementation of the same computation on the same target (RD5).                             | NUM-06, NUM-07; D7, D14                         |
| INT-12 | MUST      | Every combination of representation, substrate, target and language is a separately buildable cell; a cell depends on another only through a stated prerequisite, so the work divides among implementers without waiting on the whole (the build matrix of document 00). | Build Plan; document 00                         |

## 10.2 Standing rules of the estate (GOV)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                 | **Verified by**                               |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|
| GOV-01 | MUST      | Nothing is installed on the host. Every tool runs inside Docker containers that are created once and kept.                                                                                                                      | P0.1 build log                                |
| GOV-02 | MUST      | Every script works inside the folder it is run from and writes nothing outside it; temporary files stay inside that folder and never go to /tmp.                                                                                | Run records; review                           |
| GOV-03 | MUST      | Legacy implementations are read-only oracles. The harness never edits, regenerates or replaces Hindawi’s transducers, Romenagri, APCISR, AyeHandSum or any other legacy source; derived builds live in the harness’s work tree. | Oracle tree hashes before and after every run |
| GOV-04 | MUST      | Upstream projects stay unbroken: patches apply to pinned trees in derived builds, and the harness never modifies the paras forks in hmnsq.                                                                                      | Run records                                   |
| GOV-05 | MUST      | No report says that something does not work unless a recorded execution shows it; every failure is reported as the command, its exit code and its output.                                                                       | Report review; self-tests                     |
| GOV-06 | MUST      | Legacy pipelines run through their own drivers. Hindawi’s composing pipeline runs through its shaili drivers, never as one transducer read on its own.                                                                          | P0.3 logs                                     |
| GOV-07 | MUST      | Gates refuse only on what a release needs: the expected base, the built payload, the repository’s own tests and contract checks, secrets, oversized files and version agreement. Every other check reports and never refuses.   | ops/verify.sh                                 |
| GOV-08 | MUST      | Claims about the harness’s own work use AyeKnow states. A value that is not known is recorded as not established, with its reason, and is never filled with a guess.                                                            | Status page; specification validator          |
| GOV-09 | MUST      | Every tool’s --version and --help output, the README and the pages carry the copyright line, the licence and the trademark notices.                                                                                             | P8.3                                          |
| GOV-10 | MUST      | Every artefact carries the author’s copyright line (‘© 1993–2026 Abhishek Choudhary. All rights reserved.’) and the affiliation AyeAI. No published material names an AI as author or contributor.                              | Report check                                  |
| GOV-11 | MUST      | Every received document is cleaned of invisible characters before it is read; the original is kept byte-identical.                                                                                                              | P0.5                                          |
| GOV-12 | MUST      | The implementer never pushes, publishes, mints or creates repositories. Seeding and minting are the author’s acts, through his estate procedure on his machine.                                                                 | Section 13                                    |
| GOV-13 | MUST      | Tools and releases are held to the rigour of a critical system: every requirement traces to a test, every test is shown to fail before it passes, and builds are reproducible.                                                  | Traceability report; mutation reports         |
| GOV-14 | MUST      | Every decision considers major and low-resource economies alike; no country, language, script, numeral system or locale is the default.                                                                                         | Review                                        |
| GOV-15 | MUST      | A tool’s interface is read (its --help, its source or a recorded run) before the harness drives it; no flag, function or patch anchor is recalled from memory.                                                                  | Generator tests against pinned sources        |
| GOV-16 | MUST      | Output is verbose and plainly presented; no step’s output is discarded.                                                                                                                                                         | Review                                        |
| GOV-17 | MUST      | Hindawi’s construct tables belong to Hindawi. The harness emits new mnemonics and constructs as a list for Hindawi’s own process and never edits the tables.                                                                    | ISA-11 output                                 |

## 10.3 Specifications (SPC)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                  | **Verified by**      |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------|
| SPC-01 | MUST      | One meta-model describes every representation in sixteen sections: identity, domain, structure, encoding, decoding, semantics, operations, composition, transformations, constraints, substrate, interfaces, verification, generation, evolution and provenance (section 9.3).                   | P1.1                 |
| SPC-02 | MUST      | Specifications are human-readable YAML validated against a JSON Schema (draft 2020-12) meta-model. A JSON view, where one is produced, is labelled as an alternative.                                                                                                                            | P1.1                 |
| SPC-03 | MUST      | Each operation’s meaning is given by exactly one reference function in a restricted subset of C11: pure, fixed-width integer types, no allocation, no input or output, no undefined behaviour. That function is the single semantic source for software targets, QEMU helpers and the HLS route. | P1.3; sanitiser runs |
| SPC-04 | MUST      | Every field has a stable path (specification identifier plus JSON Pointer) and a hash of its canonical form.                                                                                                                                                                                     | P1.2                 |
| SPC-05 | MUST      | A value not yet established is written as not_established with its reason; the validator and every generator refuse to consume it and name it.                                                                                                                                                   | P1.1 planted defects |
| SPC-06 | MUST      | The provenance section names the oracle (repository, commit, path), the extraction method and the evidence state.                                                                                                                                                                                | P1.5 to P1.8         |
| SPC-07 | MUST      | The first build covers five families: numeric, script structure, transliteration, symbolic pipeline and machine (instruction extensions and standalone machines).                                                                                                                                | M1                   |
| SPC-08 | SHOULD    | The specification vocabulary is ingestible by paras, so specifications can be read and written in any Hindawi language with an exact round trip.                                                                                                                                                 | P8.4                 |
| SPC-09 | MUST      | Specifications carry semantic versions; the evolution section classes each change as compatible or breaking; instruction encodings follow the allocation ledger (ISA-04).                                                                                                                        | P4.1                 |

## 10.4 Oracles (ORC)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                          | **Verified by**    |
|--------|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| ORC-01 | MUST      | Each legacy asset has an oracle runner that builds and runs it from its pinned commit inside a container, through its own build system and drivers.                                                                                                                                      | P0.3               |
| ORC-02 | MUST      | Oracle corpora come first from the asset’s own samples, then from generated inputs, then from multilingual corpora in the estate (ILM and tajziya packages); each corpus is hashed.                                                                                                      | P0.3; P1.5 to P1.7 |
| ORC-03 | MUST      | Extracting a specification from an oracle is descriptive: every extracted rule is confirmed by executing the oracle on the corpus, and where extraction and oracle disagree, the oracle wins and the disagreement is recorded.                                                           | P1.5 to P1.7       |
| ORC-04 | MUST      | Assets that the received documents describe and the author’s record does not show (the machine-stack explainer, the APCISR WebAssembly trace, AyeHandSum’s mechanisms) are located at intake. An asset not found is recorded with every place searched, and no stand-in is built for it. | P0.2               |

## 10.5 Software generation (GEN)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                   | **Verified by**  |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| GEN-01 | MUST      | For a representation with a legacy implementation, the legacy source is the implementation. The harness builds it unmodified for native, WebAssembly and Python targets and generates only glue: bindings, build files and vectors.               | P2.2             |
| GEN-02 | MUST      | For a representation without a legacy implementation, the harness generates C11 sources from the specification and its reference functions, with WebAssembly builds, a JavaScript loader and Python bindings, using existing toolchains.          | P2.2             |
| GEN-03 | MUST      | Generation is deterministic: the same inputs give byte-identical outputs. Generated files carry the specification hash and generator version, and no timestamps.                                                                                  | P2.1 rerun check |
| GEN-04 | MUST      | Every generated file carries the licence of its destination: the harness’s licence in its own tree, and the licence the upstream accepts for files compiled into it (GPL-2.0-or-later for QEMU and Linux, GPL-3.0-or-later for binutils and GCC). | P0.4; review     |
| GEN-05 | MUST      | Candidate tables for scripts or transliterations outside the author’s canon are harness outputs, kept in its tree and marked candidate. Adopting them into APCISR, Romenagri or Hindawi is the author’s act.                                      | P6.3             |

## 10.6 Dependency and impact (DEP)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | **Verified by** |
|--------|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| DEP-01 | MUST      | Every generator declares the specification paths it reads, and the harness records the paths it actually reads. A read outside the declaration fails the generator’s own test.                                                                                                                                                                                                                                                                                                                                                                                    | P3.1            |
| DEP-02 | MUST      | The dependency graph is a plain-text edge list under version control, with seven edge types: depends_on, implements, transforms, preserves, accelerates, requires and validates. A rendering is generated from it.                                                                                                                                                                                                                                                                                                                                                | P3.3            |
| DEP-03 | MUST      | Ninja executes the graph. Each declared read is materialised as a slice file rewritten only when its canonical content changes, and generator steps restat their outputs, so a change rebuilds exactly its dependants.                                                                                                                                                                                                                                                                                                                                            | P3.2            |
| DEP-04 | MUST      | The impact command reports, before any build, which artefacts a proposed change will regenerate and which conformance cells will rerun; the following build confirms that exactly that set changed.                                                                                                                                                                                                                                                                                                                                                               | P3.4            |
| DEP-05 | MUST      | Demonstrator D2 holds for four changes: (a) one AyeHandSum encoding rule, regenerating its encoder, decoder, vectors and dependent instruction and hardware artefacts only; (b) one APCISR grid rule in a derived build, regenerating that script’s tables, builds and conformance only; (c) one new operation in a specification, generating its glue, instruction candidate and tests only; (d) the trit encoding of the balanced ternary specification, regenerating its software, QEMU helpers, intrinsics and hardware units and nothing in the script lane. | P3.5, P5.9      |
| DEP-06 | MUST      | A deliberate change against a legacy oracle carries an expected-divergence set. Conformance passes when the observed differences equal that set and fails on any other difference.                                                                                                                                                                                                                                                                                                                                                                                | P3.6            |

## 10.7 Tier A instruction extensions (ISA)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                                 | **Verified by** |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| ISA-01 | MUST      | Tier A extends a RISC-V base profile with custom extensions in the custom opcode space. Base profiles mirror the SHAKTI core classes that Parashakti targets, with parameters read from the ingested SHAKTI sources at intake; the working profiles are RV64GC and RV32IMAC.                                                                                                    | P4.1, P5.6      |
| ISA-02 | MUST      | First-build Tier A instructions are register-to-register operations with no new architectural state and no memory access. An instruction with state or memory access needs an architecture decision record first.                                                                                                                                                               | P4.1            |
| ISA-03 | MUST      | Candidate instructions come from specification operations marked as candidates. A candidate is promoted only when its measured benefit is recorded against the base instruction set running the same reference function: dynamic instruction count from QEMU’s counting plugin and, from M5, hardware resources. Candidates without recorded benefit are kept and not promoted. | P4.4            |
| ISA-04 | MUST      | Encodings are allocated once, in an allocation ledger kept in the tree. Allocations are checked against the RISC-V opcode database (a collision with a standard extension is refused) and against the vendor extensions the pinned binutils knows (a collision is reported). Regeneration never moves an allocated encoding.                                                    | P4.1            |
| ISA-05 | MUST      | The QEMU generator emits decodetree files, translation functions, helper declarations and helper bodies that call the reference functions, a CPU property that guards the extension, and build entries. It applies them to a pinned QEMU tree through exact-anchor patches that stop and name the anchor when it has moved.                                                     | P4.2            |
| ISA-06 | MUST      | With the CPU property off, every new instruction raises an illegal-instruction exception: SIGILL in user mode, a trap in system mode.                                                                                                                                                                                                                                           | P4.3            |
| ISA-07 | MUST      | The zero-patch path works with stock GNU tools: generated assembler macros use the .insn directive, and generated C intrinsics are inline assembly built on it.                                                                                                                                                                                                                 | P4.3            |
| ISA-08 | MUST      | The patch path generates binutils opcode entries, extension registration and gas tests, so the assembler and disassembler know every mnemonic. It builds from pinned sources in its own container.                                                                                                                                                                              | P4.5            |
| ISA-09 | SHOULD    | The patch path generates GCC builtins, machine-description patterns and the -march extension name for promoted instructions.                                                                                                                                                                                                                                                    | P4.10           |
| ISA-10 | MAY       | Sail definitions of the new instructions for the RISC-V Sail model, as a second reference; LLVM TableGen definitions for the LLVM carried by Parashakti.                                                                                                                                                                                                                        | P4.11           |
| ISA-11 | MUST      | The generator emits the new mnemonics as a construct list in the form Hindawi’s construct tables take, for Hindawi’s own localisation process (GOV-17).                                                                                                                                                                                                                         | P4.9            |

## 10.8 Toolchain (TCH)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                              | **Verified by**  |
|--------|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| TCH-01 | MUST      | The zero-patch lane uses distribution packages of the RISC-V GNU cross toolchain and QEMU inside a container. The patch lane builds binutils, GCC and QEMU from pinned sources.                                                                                                                                                                                              | P0.1, P4.2, P4.5 |
| TCH-02 | MUST      | Every upstream source resolves first to its paras fork in hmnsq (the English baseline branch), then to the pinned upstream release, and the run records which was used. The author’s paras run of 22 October 2026 recorded binutils-gdb, musl, newlib and bash as stopping at the fork stage; the fallback for these is recorded per run and reported to paras’s next round. | Run records      |
| TCH-03 | MUST      | Build parallelism is set from measured free memory and processors. Peak memory, disk and time are recorded for every build.                                                                                                                                                                                                                                                  | Run records      |
| TCH-04 | SHOULD    | Test programs written in Hindawi languages are compiled through Hindawi’s drop-in front end to the cross compiler. Where the front end cannot drive a cross compiler, an issue text for the Hindawi repository records the command, its exit code and its output.                                                                                                            | P4.9             |

## 10.9 Operating systems (OSL)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                          | **Verified by** |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| OSL-01 | MUST      | xv6-riscv, from its paras fork or the pinned upstream, boots in qemu-system-riscv64 with the extension enabled, and a user program runs the new instructions with results equal to the vectors.                                                                          | P4.6            |
| OSL-02 | MUST      | A minimal Linux kernel with a static initramfs boots on the QEMU virt machine with the extension enabled and runs the same test binary. Firmware resolves to Parashakti’s first and to the firmware bundled with the pinned QEMU otherwise; the source used is recorded. | P4.7            |
| OSL-03 | MUST      | A compatibility matrix records, from executions, which Parashakti operating systems boot on which harness targets. A cell that has not been run reads not established.                                                                                                   | P4.8            |
| OSL-04 | MUST      | Operating-system builds are derived builds in the harness’s work tree; the paras forks stay untouched.                                                                                                                                                                   | Run records     |

## 10.10 Hardware (HDL)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                               | **Verified by** |
|--------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| HDL-01 | MUST      | For each promoted operation the harness produces synthesisable SystemVerilog and VHDL-2008 units, either generated directly from the specification’s tables and bit definitions or produced by an open high-level synthesis tool from the reference function. The route is recorded per unit. | P5.1, P5.2      |
| HDL-02 | MUST      | Units are simulated with Verilator and GHDL through one cocotb test per unit that reads the shared vectors.                                                                                                                                                                                   | P5.3            |
| HDL-03 | SHOULD    | Units with small input domains are checked exhaustively in simulation or by bounded proof with SymbiYosys.                                                                                                                                                                                    | P5.3            |
| HDL-04 | MUST      | Yosys reports resources and nextpnr reports timing for at least one low-cost FPGA family with an open flow. These are recorded as measurements, never as claims about silicon.                                                                                                                | P5.4            |
| HDL-05 | SHOULD    | A coprocessor wrapper conforming to the OpenHW CV-X-IF interface attaches the units to an open core that implements it, and the same compiled test program runs on the Verilated core and in QEMU with equal results (D4).                                                                    | P5.5            |
| HDL-06 | MUST      | Integration with a SHAKTI core starts from a study that reads the SHAKTI core sources ingested by Parashakti and records their extension mechanism. No mechanism is assumed.                                                                                                                  | P5.6            |
| HDL-07 | MUST      | ASIC hand-off uses jugaad28’s descriptors, evidence rungs and open-PDK containers. Units that emulate ternary on binary logic follow the binary flow; native ternary circuits go to zamin, keeping jugaad28’s substrate boundary (its invariant J4).                                          | P5.7            |
| HDL-08 | MAY       | On-board FPGA runs are needs:human packets carried out when a board is at hand, with the board and toolchain versions recorded beside the result.                                                                                                                                             | P5.10           |

## 10.11 Scripts (SCR)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                | **Verified by** |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| SCR-01 | MUST      | The script lane instantiates the author’s 9-grid model as APCISR defines it, read from APCISR’s source and the author’s paper at intake and confirmed by him (P6.1). No grid semantics are assumed beyond what is read.                                                        | P6.1            |
| SCR-02 | MUST      | For each script, the generator derives candidate grid tables in APCISR’s own table format from the Unicode Character Database, CLDR exemplar sets and, where they exist, the script’s Romenagri tables, and builds APCISR itself with them for native and WebAssembly targets. | P6.3            |
| SCR-03 | MUST      | Per-script conformance compares cluster boundaries and positional classes with HarfBuzz shaping of the same text in a reference font of the Noto family, and with Unicode grapheme cluster rules. Results are published as status per script.                                  | P6.4            |
| SCR-04 | MUST      | Gaps between a script and the grid model are recorded as findings for the author’s ruling. The harness never alters or replaces the model to close a gap.                                                                                                                      | P6.7            |
| SCR-05 | MUST      | The lane covers every script in the ILM registry pinned in tajziya. Its first working set spans regions: Devanagari, Tamil, Arabic in Urdu orthography, Khmer, Ethiopic, Tifinagh, Hebrew, Cyrillic and Han.                                                                   | P6.3, P6.5      |
| SCR-06 | MUST      | Native-reader review of rendered samples is a needs:human packet per script. Coverage is published as status and never used as a gate.                                                                                                                                         | P6.6            |

## 10.12 Numeric representations (NUM)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                                                           | **Verified by**          |
|--------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------|
| NUM-01 | MUST      | The first-build numeric specifications are two’s-complement binary integer (the performance baseline), balanced ternary, the dynamic-base encoding of AyeHandSum as extracted at intake, and packed decimal.                                                                                                                                                                                              | P1.3, P1.4, P1.7         |
| NUM-02 | MUST      | Definition of balanced ternary (RD5, decided): two bits per trit (00 is 0, 01 is +1, 10 is -1, 11 is invalid); 32 trits in a 64-bit register and 16 in a 32-bit register; operations negate, add, subtract, multiply (low half), compare, shift by trits, and conversion to and from two’s complement. The specification defines the result of overflow, of invalid codes and of out-of-range conversion. | P1.3                     |
| NUM-03 | MUST      | A second trit encoding, as two bit-planes, is specified beside the first and is the change used in D2(d).                                                                                                                                                                                                                                                                                                 | P1.3                     |
| NUM-04 | MUST      | Numeric oracles are independent of the reference functions: arbitrary-precision integers (Python or GMP) for ternary and decimal homomorphism checks, Python’s decimal module or libdecnumber for decimal, and SoftFloat with TestFloat for any IEEE binary format added later.                                                                                                                           | P1.3, P1.4               |
| NUM-05 | SHOULD    | Further numeric families follow through the same lanes as later milestones: fixed point, posits, low-precision formats for machine learning and arbitrary precision.                                                                                                                                                                                                                                      | Later amendment          |
| NUM-06 | MUST      | Binary is the performance baseline. A fixed workload set (Embench-IoT kernels and the CMS-03 continuous models as fixed-point programs) runs on RV32 and RV64 in QEMU, on the binary Tier B machine and on a Verilated open core, with dynamic instruction counts, cycles and synthesis figures recorded; emulator counts are never stated as hardware speed.                                             | P4.13, P5.11; D14        |
| NUM-07 | MUST      | Binary and balanced ternary run through the software, Tier A, Tier B, hardware and mechanical lanes; packed decimal and the AyeHandSum dynamic base follow wherever measurement promotes them.                                                                                                                                                                                                            | P7.1, P10.3; document 00 |

## 10.13 Conformance (CNF)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                                                                                                           | **Verified by**         |
|--------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------|
| CNF-01 | MUST      | Vectors are plain text, one case per line, in hexadecimal fields, with a header naming the specification identifier, version and hash. Every runner reads the same files.                                                                                                                                                                                                                                                                                 | P2.1                    |
| CNF-02 | MUST      | The runners are native C, WebAssembly, Python, QEMU user mode, QEMU system mode under each booted operating system, Verilator, GHDL and core co-simulation. A promoted operation passes only when every applicable runner agrees with the reference on every vector.                                                                                                                                                                                      | M2, M4, M5              |
| CNF-03 | MUST      | Each runner enumerates finite domains exhaustively from the domain description, without storing them, up to a configured bound (working value 1,048,576 cases per operation), restricting operands to their low digits where the full width is larger. Beyond the bound, stored boundary cases from the specification and seeded random cases are used (working value 100,000 per operation), with property-based tests (Hypothesis) on software targets. | P2.1, P2.4              |
| CNF-04 | MUST      | Every lane has a mutation self-test that plants specified defects (a table entry, an off-by-one, a wrong funct3, swapped operands, a flipped hardware bit) and shows the conformance suite catching each one. The report gives planted and caught counts.                                                                                                                                                                                                 | P2.5, P4.12, P5.8, P7.4 |
| CNF-05 | SHOULD    | Round-trip and homomorphism properties of reference functions with small widths are proved by bounded methods (Z3 or a C bounded model checker).                                                                                                                                                                                                                                                                                                          | P2.4                    |

## 10.14 Provenance and reporting (PRV)

| **ID** | **Level** | **Requirement**                                                                                                                                                                           | **Verified by** |
|--------|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| PRV-01 | MUST      | Every run writes a run record: input specification hashes, oracle commits, tool versions, container image digests, output artefact hashes, conformance results and AyeKnow states.        | Every milestone |
| PRV-02 | MUST      | Each run record is also written as an in-toto Statement v1 in Candor’s form. Timestamping with OpenTimestamps happens on the author’s machine.                                            | M2 onwards      |
| PRV-03 | MUST      | Reports are actionable: each finding states what it means, what to do and where.                                                                                                          | Review          |
| PRV-04 | MUST      | A generated status page shows the compatibility matrix, script coverage, the wheel census (which external tool did the work at each layer) and AyeKnow states, and reads well on a phone. | P8.3            |
| PRV-05 | MUST      | satsneha consumes run records in reporting mode only.                                                                                                                                     | P8.3            |
| PRV-06 | MUST      | RESUME.md is generated from the run records at the end of every run and gives each packet’s state with its evidence. It is never edited by hand.                                          | Every iteration |

## 10.15 Command-line tool (CLI)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                    | **Verified by**  |
|--------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| CLI-01 | MUST      | One command-line tool, repsynth, with subcommands doctor, intake, spec check, gen, impact, run, conform, report and selftest. One command runs a whole milestone or iteration end to end (repsynth run --milestone M, repsynth run --iteration N). | P0.1 onwards     |
| CLI-02 | MUST      | The operator’s intent is taken once per run. The tool has no irreversible action of its own, so it carries no typed gates beyond confirming the deletion of its own caches.                                                                        | Review           |
| CLI-03 | MUST      | A run shows live progress (what is running and what remains) and stops and resumes from any stage without repeating completed stages.                                                                                                              | P0.1 onwards     |
| CLI-04 | MUST      | doctor is timed, never installs anything on the host and reports what is missing; doctor --build builds the containers once.                                                                                                                       | P0.1             |
| CLI-05 | SHOULD    | A colour terminal status display in the manner of paras, and placement of heavy jobs on chosen processors.                                                                                                                                         | Later iterations |
| CLI-06 | MUST      | The tool is a Python package installable with pipx; its containers build from Dockerfiles in its tree.                                                                                                                                             | P8.3             |
| CLI-07 | MUST      | repsynth compile and repsynth capability produce substrate programs and the capability matrix.                                                                                                                                                     | P12.1, P12.2     |

## 10.16 Global and low-resource (GLB)

| **ID** | **Level** | **Requirement**                                                                                                                                                      | **Verified by** |
|--------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| GLB-01 | MUST      | After the first fetch, every lane runs offline from caches inside the run folder.                                                                                    | Run records     |
| GLB-02 | MUST      | The whole first build fits the reference unit: 16 GB of memory, the disk budget of PRF-02, one heavy build at a time.                                                | Run records     |
| GLB-03 | MUST      | Outputs meant for people (WebAssembly builds of representations, the status page, script samples) run in a phone browser without a server.                           | P8.3            |
| GLB-04 | MUST      | Hardware routes favour open flows and low-cost boards available worldwide; ASIC routes include open process design kits from more than one country through jugaad28. | P5.4, P5.7      |
| GLB-05 | SHOULD    | The harness’s own repository passes paras ingestion with an exact round trip in every Hindawi language, as the stack packages do.                                    | P8.4            |

## 10.17 Resources (PRF)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                        | **Verified by** |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| PRF-01 | MUST      | Peak memory, disk and wall time are measured for every build and recorded in the run record.                                                                                                                                                                                                           | Run records     |
| PRF-02 | MUST      | The disk budget for the working set is a configuration value (working value 8 GB). Before a run, the harness computes each lane’s need from recorded peaks (estimates, labelled as such, on a first run), reports any shortfall up front, runs the lanes that fit and says why the others did not run. | Run records     |
| PRF-03 | MUST      | Build directories are removed once their artefacts are captured and hashed; clones are shallow where history is not needed; caches are bounded.                                                                                                                                                        | Run records     |
| PRF-04 | MUST      | Regeneration after a one-field change leaves unaffected lanes unbuilt, and its time is recorded.                                                                                                                                                                                                       | P3.5            |
| PRF-05 | MUST      | Reference containers are built when their lane first needs them and are kept; before a new image is built, the run reports each image’s size and the total against free disk.                                                                                                                          | P9.5            |

## 10.18 Tier B standalone machines (ISB)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                                                | **Verified by** |
|--------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| ISB-01 | MUST      | One parametric machine generator produces two standalone machines from their specifications, a binary word machine and a balanced ternary word machine encoded on a binary host (RD5); each is a new QEMU target with a CPU, decodetree translation, helpers and a minimal board with memory, a UART and an exit device, and both boot bare-metal test images. | P7.2, P7.4      |
| ISB-02 | MUST      | Tier B test images are assembled by an existing retargetable assembler (customasm) from a generated instruction definition.                                                                                                                                                                                                                                    | P7.3            |
| ISB-03 | SHOULD    | A binutils port for the Tier B machine (assembler, disassembler, and a linker with a minimal ELF backend) is generated from the machine specification and assembles the same sources to identical images.                                                                                                                                                      | P7.5            |
| ISB-04 | MUST      | A GCC port for a Tier B machine lies outside the first build and needs its own amendment to this document.                                                                                                                                                                                                                                                     | Scope           |

## 10.19 Applications (APP)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                 | **Verified by** |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| APP-01 | SHOULD    | An application specification declares the representations, precisions and latency an application needs; the harness proposes representation choices and instruction candidates for it and measures them through the same lanes. | P8.1            |
| APP-02 | MAY       | Teaching labs package exercises (add an instruction, change an encoding, watch the stack regenerate) for computer architecture and compiler courses, each runnable on one laptop from one command.                              | P8.2            |

## 10.20 Substrate specifications (SUB)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                           | **Verified by** |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| SUB-01 | MUST      | One substrate meta-model describes every substrate in fifteen sections: medium, state space, state transitions, operations, observability, controllability, temporal behaviour, noise and uncertainty, resource constraints, interface, units, parameters, capabilities, realisation models and provenance (section 9.9). | P9.2            |
| SUB-02 | MUST      | A substrate specification is distinct from a representation specification. A realisation record links them: the representation, the substrate, the mechanism and the capability class.                                                                                                                                    | P9.2, P10.3     |
| SUB-03 | MUST      | Every physical parameter carries an evidence state: measured (with its record), sourced (with its citation), assumed (stated as an assumption) or not established. Results show the assumed and not-established parameters they depend on.                                                                                | P9.2            |
| SUB-04 | MUST      | The first build specifies five substrates: mechanical, analogue electronic, digital electronic, quantum and optical.                                                                                                                                                                                                      | P9.2            |
| SUB-05 | MUST      | Every quantity carries a UCUM unit or is declared dimensionless.                                                                                                                                                                                                                                                          | P9.2            |

## 10.21 Computational models (CMS)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                           | **Verified by** |
|--------|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| CMS-01 | MUST      | A computational model specification describes a computation without reference to any substrate: state variables, inputs, outputs, transitions and semantics, given as equations for continuous models, as reference functions for discrete models (SPC-03) and as OpenQASM 3 circuits for quantum models. | P9.3            |
| CMS-02 | MUST      | The restricted expression grammar for equations is defined once, in EBNF, with one parser in the shared web core and generators to Modelica equations and SPICE behavioural expressions; every model’s generated forms re-parse to the same syntax tree.                                                  | P9.3            |
| CMS-03 | MUST      | The first computational models are exponential decay, the harmonic oscillator, a damped driven oscillator, the Lorenz system, function generation y = f(x) for a stated set of functions, and balanced ternary addition (NUM-02).                                                                         | P9.3, P9.6      |

## 10.22 Cross-substrate compilation (XSC)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                          | **Verified by**     |
|--------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| XSC-01 | MUST      | The cross-substrate compiler maps a computational model to a program for each substrate (a mechanism configuration, an analogue patch, an instruction sequence, a quantum circuit, an interferometer mesh), performs the magnitude and time scaling the substrate needs, and records every scale factor. | P12.1               |
| XSC-02 | MUST      | For every model and substrate the compiler reports exactly one capability class (supported; supported with restrictions; approximate, with its bound; simulation only; not realisable under stated constraints, naming the constraint) and attaches the record that justifies it.                        | P12.1, P12.2        |
| XSC-03 | MUST      | The capability matrix of models by substrates is published on the status page, each cell with its class and record.                                                                                                                                                                                      | P12.2               |
| XSC-04 | MUST      | A simulated result is recorded as simulated and never as physically realised. A physical claim needs measurements entered with their evidence, on dhancha’s rungs (SPEC, MODEL, SIMULATED, BENCH, FLIGHT) or jugaad28’s rungs for integrated circuits.                                                   | Review; status page |

## 10.23 Web-first builds (WEB)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                               | **Verified by**    |
|--------|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| WEB-01 | MUST      | Every simulator and every browser face of the harness is plain JavaScript in ES modules that runs in a current browser with no build step, bundler or transpiler, served from GitHub Pages or any static server.                                                                                              | P9.4, P10.5, P11.7 |
| WEB-02 | MUST      | Third-party JavaScript is vendored as readable, unminified source under vendor/\<name\>/\<version\>/ with its licence file, upstream source, version and a sha256 for every file; nothing is fetched from a CDN at run time.                                                                                  | P9.1               |
| WEB-03 | MUST      | A library or source file is admitted only after BURP returns its sources byte for byte. The admission state of each library (admitted, pending BURP, rejected) is recorded, and every BURP gap is reported with its command, exit code and output for BURP’s next round.                                      | P9.1; D12          |
| WEB-04 | MUST      | Sources use no eval, no new Function and no generated code. WebAssembly appears only when built from sources that are themselves ingested (the C reference functions), never as the only form of a library.                                                                                                   | P9.1; review       |
| WEB-05 | MUST      | Simulators work offline after first load and on a phone browser. Long runs execute in Web Workers, and a heavy run lowers its resolution rather than freezing the page.                                                                                                                                       | P10.5, P11.7       |
| WEB-06 | MUST      | Every simulator exposes one command surface in the browser and in Node.js. Fixed-step results are byte-identical between Node.js and Chromium-based browsers, and within the Test Plan’s cross-engine bound on other engines, because ECMAScript does not require correctly rounded transcendental functions. | P9.4               |
| WEB-07 | SHOULD    | Every simulator page shows the author’s notices, links to its run records and the capability matrix, and exports and imports programs and traces as plain text.                                                                                                                                               | P10.11, P11.10     |

## 10.24 Mechanical simulator (MEC)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                           | **Verified by** |
|--------|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| MEC-01 | MUST      | The mechanical simulator (hmnsq/mechsim) simulates computing mechanisms from a mechanism configuration: shafts, gear pairs and trains, differentials, wheel-and-disc integrators, cams and followers, lead screws, ratchets, counter wheels with carry, crank inputs, dials and plotters. | P10.1, P10.2    |
| MEC-02 | MUST      | Two levels of model run from one configuration: an ideal kinematic model (constraints and integrator equations) and a lumped dynamic model (inertia, compliance, backlash, friction and integrator slip), every parameter with its evidence state.                                        | P10.2, P10.4    |
| MEC-03 | MUST      | Discrete mechanisms (detents, carries, ratchets) simulate exactly. Mechanical binary and balanced ternary adders, with two and three detent positions per wheel, run from their specifications and equal their reference functions on every vector.                                       | P10.3           |
| MEC-04 | MUST      | Configurations export geometry (involute gears, cams, frames) through JSCAD as STL or 3MF with tolerances recorded. Geometry is a realisation model, not a claim of a working build.                                                                                                      | P10.6           |
| MEC-05 | MUST      | Ideal and lumped results are cross-checked against Modelica models generated from the same configuration and run in OpenModelica in a container; a three-dimensional multibody check with Project Chrono covers at least one gear train and one differential.                             | P10.7, P10.8    |
| MEC-06 | MUST      | The page shows mechanisms moving (2D in SVG or canvas; 3D with three.js), plots outputs against time or input, and the same modules run headless in Node.js.                                                                                                                              | P10.5           |
| MEC-07 | MUST      | Differential analyser configurations solve the continuous models of CMS-03 mechanically (D8).                                                                                                                                                                                             | P10.9           |

## 10.25 Analogue simulator (ANA)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                                                                                                | **Verified by** |
|--------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| ANA-01 | MUST      | The analogue simulator (hmnsq/anasim) simulates analogue computer programs given as patches: integrators with initial conditions, summers, coefficient potentiometers, inverters, multipliers, comparators, limiters, function generators and sample-and-hold elements, under mode control (initial condition, operate, hold). | P11.1, P11.3    |
| ANA-02 | MUST      | Two levels of model run from one patch: ideal computing elements assembled into an ODE system, and non-ideal elements with finite gain and bandwidth, offset, drift, saturation at the machine unit, component tolerances and seeded noise, every parameter with its evidence state.                                           | P11.3, P11.4    |
| ANA-03 | MUST      | The patch compiler scales magnitudes to the machine unit and time to the elements’ bandwidth, records the factors, and reports any overload with the element and the time at which it occurs.                                                                                                                                  | P11.2           |
| ANA-04 | MUST      | Patches export SPICE netlists of op-amp realisations, using a generic macro-model rather than any vendor’s model, and Modelica models; both run in containers and are compared with the browser results within the Test Plan bounds.                                                                                           | P11.5, P11.6    |
| ANA-05 | MUST      | The page shows the patch as a diagram and its traces on a scope view, and the same modules run headless in Node.js.                                                                                                                                                                                                            | P11.7           |
| ANA-06 | SHOULD    | A bill of materials by generic part class and a breadboard-level netlist form the physical realisation model of a patch.                                                                                                                                                                                                       | P11.8           |

## 10.26 Quantum lane (QNT)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                                                          | **Verified by** |
|--------|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| QNT-01 | MUST      | No new quantum simulator is written. The quantum lane uses Panini Q where its interface covers an operation, an existing browser circuit library for the web face, and Qiskit Aer and QuTiP in a container as references; OpenQASM 3 is the interchange. | P12.3, P12.4    |
| QNT-02 | MUST      | Quantum results are compared as state vectors where every simulator exposes them and as measurement distributions otherwise, under the Test Plan’s statistical bounds; qubit ordering and phase conventions are recorded and tested.                     | P12.4           |
| QNT-03 | MUST      | Panini Q is read at intake and its interface recorded, citing files and lines, before any adapter is designed; Panini Q itself changes only by the author’s ruling.                                                                                      | P12.3           |

## 10.27 Optical lane (OPT)

| **ID** | **Level** | **Requirement**                                                                                                                                                                                                         | **Verified by** |
|--------|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
| OPT-01 | SHOULD    | Optical models are linear transfer matrices realised as interferometer meshes by a published decomposition; a later milestone (M13) builds the browser face in hmnsq/optisim and compares it with a photonic reference. | P13.1           |

# 11 Build path, milestones and packets

## 11.1 The path, and why it runs in this order

| **Step** | **Milestone**                               | **Why it sits here**                                                                                                                                                                                                                                                    |
|----------|---------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1        | M0 Intake and baseline                      | Three assets in the received documents are not in the author’s record, and the estate’s first rule is to retrieve before building. Running the oracles through their own drivers also fixes what correct means before anything is generated.                            |
| 2        | M1 Specifications                           | Specifications are extracted from oracles that have just been run. Balanced ternary and packed decimal need no legacy code, so the end-to-end path proceeds whatever intake finds.                                                                                      |
| 3        | M2 Software conformance                     | Every later lane reuses the same vectors and reference functions. Proving agreement on cheap targets first makes every later disagreement a defect in one target.                                                                                                       |
| 4        | M3 Dependency and impact                    | Exact regeneration is the centre of the proposition. It is proven while artefacts are cheap to rebuild, and proven again once instruction and hardware artefacts exist (P5.9).                                                                                          |
| 5        | M4 Tier A                                   | A RISC-V custom extension reuses the whole Parashakti stack unchanged: stateless register instructions need no operating-system change. The zero-patch path proves semantics with stock tools before any upstream patch is generated.                                   |
| 6        | M5 Hardware                                 | Hardware is generated only for instructions whose benefit was measured in M4, so hardware effort follows evidence.                                                                                                                                                      |
| 7        | M6 Scripts                                  | Independent of M2 to M5 and able to run from intake onward; the author’s confirmation of the 9-grid reading record (P6.1) is its only gate.                                                                                                                             |
| 8        | M7 Tier B                                   | The costliest lane. It reuses the decodetree and helper generators proven in M4, so it starts from a working core.                                                                                                                                                      |
| 9        | M8 Applications and release readiness       | Applications and teaching labs consume every lane; release readiness closes the build for the author’s seeding.                                                                                                                                                         |
| 10       | M9 Substrate foundations                    | The two simulators share their numerical core, their specification formats and their reference containers, and BURP’s handling of JavaScript decides which libraries are admitted; all of this is settled before either simulator grows. It needs nothing from Track H. |
| 11       | M10 Mechanical simulator                    | Runs beside M11 on the shared core: the ideal kinematic model first, then dynamics, geometry and the reference cross-checks.                                                                                                                                            |
| 12       | M11 Analogue simulator                      | Runs beside M10: ideal elements first, then non-ideal elements and the circuit-level reference.                                                                                                                                                                         |
| 13       | M12 Cross-substrate compilation and quantum | Joins the tracks: one model is compiled to every substrate and compared, so it needs M4, M10 and M11.                                                                                                                                                                   |
| 14       | M13 Optical                                 | Last: it reuses the core and the compiler, and nothing waits on it.                                                                                                                                                                                                     |

<img src="media/91320c86ff23a973daf9fa63764e83c7a273a296.png"
title="Build path" style="width:6.66667in;height:3.19792in"
alt="Figure 1. Build path in two tracks: Track H (harness) and Track S (substrates), joined at M12. D2 is shown over software artefacts in M3 and again over instruction and hardware artefacts in M5." />

*Figure 1. Build path in two tracks: Track H (harness) and Track S
(substrates), joined at M12. D2 is shown over software artefacts in M3
and again over instruction and hardware artefacts in M5.*

## 11.2 Iteration plan

A working plan in two tracks: Track H (harness, I1 to I9) and Track S
(substrates, S1 to S6), joined by J1. The author may reorder it; M6 can
run beside any of I2 to I6. Each iteration closes with one command on
the author’s machine, the repository’s ops/run.sh, which runs everything
inside its containers; acceptance is read from that run’s records.

| **Iteration** | **Packets**                                                                | **Closes with**                                                                  |
|---------------|----------------------------------------------------------------------------|----------------------------------------------------------------------------------|
| I1            | P0.1, P0.4, P0.5, P0.6, P1.1 to P1.4, P2.1, and the code for P0.2 and P0.3 | Intake run on the author’s machine; specifications without legacy code validated |
| I2            | P1.5 to P1.8, P2.2 to P2.5                                                 | D1                                                                               |
| I3            | P3.1 to P3.6                                                               | D2 over software artefacts                                                       |
| I4            | P4.1 to P4.4, P4.12                                                        | Tier A in user mode; promotion report                                            |
| I5            | P4.5 to P4.9, P4.13                                                        | D3, D5; binary baseline counts                                                   |
| I6            | P5.1 to P5.9, P5.11                                                        | D4; D2 over instruction and hardware artefacts; D14                              |
| I7            | P6.1 to P6.7                                                               | D6                                                                               |
| I8            | P7.1 to P7.5                                                               | D7                                                                               |
| I9            | P8.1 to P8.5, P4.10, P4.11, P5.10                                          | Release readiness                                                                |
| S1            | P9.1 to P9.4, P9.6, P9.7                                                   | BURP probe recorded; core parity and accuracy                                    |
| S2            | P9.5, P10.1 to P10.3, P11.1 to P11.3                                       | Reference containers; ideal mechanical and analogue models                       |
| S3            | P11.4 to P11.7, P11.9                                                      | Analogue references agree                                                        |
| S4            | P10.4 to P10.8, P10.10                                                     | Mechanical references agree                                                      |
| S5            | P10.9, P11.8, P9.8, P10.11, P11.10                                         | D8, D9, D12; three repositories ready for seeding                                |
| J1            | P12.1 to P12.6 (needs M4 of Track H)                                       | D10, D11                                                                         |
| S6            | P13.1 (later)                                                              | D13                                                                              |

## 11.3 Packets

Every packet, with its repository, prerequisites, outputs, acceptance
condition and capability labels, is in the Build Plan (document 04). The
Build Plan is generated from the same source as this document, so the
two cannot disagree.

# 12 Demonstrators and acceptance

| **ID** | **Demonstrator**                                                                                                                                    | **Milestone**   | **Accepted when**                                                                                                                                                                                                         |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------|-----------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| D1     | Software agreement: legacy and generated builds agree with their oracles and reference functions on native, WebAssembly and Python targets          | M2              | The software conformance run exits 0, and its mutation report shows every planted defect caught                                                                                                                           |
| D2     | Exact regeneration under the four changes of DEP-05                                                                                                 | M3, again in M5 | For each change, the predicted, observed and expected sets of regenerated artefacts are equal, and every other artefact hash is unchanged                                                                                 |
| D3     | Tier A in QEMU with GNU tools and Parashakti operating systems                                                                                      | M4              | Promoted instructions, compiled by the GNU cross tools, give the vector results in QEMU user mode, in xv6-riscv and in Linux; with the CPU property off they raise illegal-instruction exceptions                         |
| D4     | One program on two machines                                                                                                                         | M5              | The same compiled program gives equal results on the Verilated core with the generated unit and in QEMU                                                                                                                   |
| D5     | A program in a Hindawi language using the extension                                                                                                 | M4              | It runs in QEMU with the vector results, or the Hindawi issue text records the command, exit code and output                                                                                                              |
| D6     | Script status across the ILM registry                                                                                                               | M6              | The status page lists every registry script with its state and evidence                                                                                                                                                   |
| D7     | Two new instruction sets in QEMU: binary and balanced ternary word machines                                                                         | M7              | Both Tier B machines boot bare-metal test images that pass their vectors, and their mutation self-tests catch every planted defect                                                                                        |
| D8     | A mechanical computer in the browser: the CMS-03 models on a simulated differential analyser, and the mechanical binary and balanced ternary adders | M10             | Trajectories meet the analytic and high-precision bounds; both adders equal their reference functions on every vector; Modelica and Chrono cross-checks meet their bounds                                                 |
| D9     | An analogue computer in the browser: the CMS-03 models as patches                                                                                   | M11             | Ideal runs meet the analytic bounds; ngspice and Modelica cross-checks meet theirs; predicted and simulated overloads agree                                                                                               |
| D10    | One model, four substrates                                                                                                                          | M12             | The harmonic oscillator runs on mechanical, analogue, digital and quantum substrates as the compiler classes it, each class carrying its record                                                                           |
| D11    | Quantum agreement                                                                                                                                   | M12             | A fixed circuit set agrees across the browser library, Panini Q where it applies, and Qiskit Aer, under the Test Plan’s statistical bounds                                                                                |
| D12    | Ingestible sources                                                                                                                                  | M9 to M11       | Every JavaScript file of every substrate repository, vendored libraries included, round-trips through BURP byte for byte, or its gap is recorded with command, exit code and output                                       |
| D13    | Optical linear maps (SHOULD)                                                                                                                        | M13             | Mesh realisations of a set of unitary matrices agree with direct products within the Test Plan bound                                                                                                                      |
| D14    | Binary performance baseline                                                                                                                         | M4, M5          | Workload instruction counts on RV32 and RV64 in QEMU, cycles on the Verilated open core and synthesis figures are recorded and reproduce on rerun; every extension and ternary figure is shown beside its binary baseline |

Measures recorded for every run and shown on the status page. None is a
gate unless an acceptance above names it:

- Agreement per runner and per vector set.

- Predicted against observed regeneration.

- Dynamic instruction counts, base set against extension.

- Hardware resources and timing per unit and FPGA family.

- Peak memory, disk and time per build.

- Scripts by state, and native-reader reviews completed.

# 13 Implementer protocol

- Iterations are numbered. Each returns one zip of the whole tree, never
  a delta, named with the iteration number.

- Each iteration carries, for every packet it touches, a completion
  report: the commands run with their exit codes, what was produced,
  what was not done, the test shown failing before it passed, what was
  reused (file and hash), and the packet’s intent as written in this
  document.

- Done means executed. A packet whose acceptance command has not run is
  reported as not built, or as wired but unproven, never as done.

- Nothing pretends. An unimplemented function raises rather than
  returning a plausible value, and a gate is shown to refuse a planted
  defect before it is trusted.

- Steps that need the network, containers or the forge are delivered as
  code that the author runs with one command (repsynth run --iteration
  N). Acceptance is read from that run’s records. The author is never
  handed a sequence of commands.

- At the start of every iteration the implementer reads RESUME.md and
  the latest run records. After a context compaction it rereads them and
  never reconstructs state from memory.

- A packet that does not fit one working context is split, and the split
  is recorded.

- Received documents are cleaned of invisible characters before they are
  read (GOV-11).

- Questions for the author go in the completion report, and work
  continues on the packets they do not block.

- The implementer never pushes, publishes, mints or creates
  repositories, and never edits a legacy source or a paras fork (GOV-03,
  GOV-04, GOV-12).

- When the author seeds an iteration, every file of the zip is kept; a
  fix made on his side is recorded as a diff, with the original kept in
  an origin folder.

- Every library used carries its admission state (WEB-03), and the
  completion report lists those states.

- The Implementation Guidelines (document 02) hold the coding rules, the
  library admission procedure and this protocol in full.

# 14 Risks

| **ID** | **Risk**                                                                       | **Response**                                                                                                                          |
|--------|--------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|
| RK-01  | Context collapse in the implementer after a compaction                         | RESUME.md and run records reread at every iteration; packets sized to one context; state never reconstructed from memory (section 13) |
| RK-02  | Stubs that pass vacuously: stages that return success, checks that cannot fail | Mutation self-tests in every lane (CNF-04); acceptance only by executed commands                                                      |
| RK-03  | A second wheel built where one exists                                          | INT-01; the wheel census on the status page names the external tool doing each layer’s work                                           |
| RK-04  | Legacy work misread as broken                                                  | Oracles run through their own drivers (GOV-06); findings carry command, exit code and output (GOV-05)                                 |
| RK-05  | The 9-grid model flattened into another model                                  | SCR-01 and SCR-04; the reading record confirmed by the author before generation (P6.1)                                                |
| RK-06  | Encoding collisions in the custom opcode space                                 | The allocation ledger and collision checks (ISA-04); the CPU property guard (ISA-06)                                                  |
| RK-07  | Drift in QEMU, binutils or GCC                                                 | Pinned releases; exact-anchor patches that stop and name a moved anchor; one rebase packet per upgrade                                |
| RK-08  | Disk exhaustion on the reference unit                                          | The disk budget with an up-front shortfall report; build directories removed after capture; bounded caches (PRF-02, PRF-03)           |
| RK-09  | Memory pressure in GCC and Linux builds                                        | Parallelism from measured free memory; one heavy build at a time (TCH-03)                                                             |
| RK-10  | Licence incompatibility between harness output and an upstream                 | Licence templates per destination (GEN-04); licence intake (P0.4)                                                                     |
| RK-11  | paras forks missing for some packages                                          | Recorded fallback to the pinned upstream (TCH-02); the gap reported to paras’s next round                                             |
| RK-12  | Text-mode grid output not comparable with glyph shaping                        | Comparison of cluster boundaries and positional classes, not pixels; native-reader review (SCR-03, SCR-06)                            |
| RK-13  | Tier B growing into a compiler port                                            | ISB-04 keeps the GCC port out of the first build                                                                                      |
| RK-14  | Emulator counts or synthesis reports read as silicon performance               | Every figure labelled with what it measures; no silicon claims (HDL-04)                                                               |
| RK-15  | Disclosure before the author decides                                           | The document and the harness stay unpublished until his ruling (RD7)                                                                  |
| RK-16  | No FPGA board at hand                                                          | Synthesis and timing without a board; on-board runs as needs:human packets (HDL-08)                                                   |
| RK-17  | The SHAKTI extension mechanism unknown                                         | The study packet reads the ingested sources before any integration design (HDL-06)                                                    |
| RK-18  | BURP not yet covering JavaScript                                               | P9.1 probes it first; gaps go to BURP’s next round; libraries carry their admission state (WEB-03)                                    |
| RK-19  | A library available only minified or compiled                                  | Admission requires readable source (WEB-02); the library is replaced or its readable source vendored                                  |
| RK-20  | Stiff or chaotic models misread as simulator defects                           | Adaptive solvers with recorded tolerances; chaotic models compared over short horizons and by attractor statistics (Test Plan)        |
| RK-21  | Reference simulators idealise elements differently from the browser models     | Element-by-element mapping in the generators; comparisons by level: ideal against ideal, non-ideal against circuit level              |
| RK-22  | Simulation mistaken for a built machine                                        | XSC-04 and the rung ladders; geometry and netlists labelled as realisation models                                                     |
| RK-23  | Qubit-ordering and phase conventions differing between quantum tools           | Recorded conventions and mapping tests before any comparison (QNT-02)                                                                 |
| RK-24  | Reference containers exhausting disk                                           | Images built when first needed and kept; sizes reported before each build (PRF-05)                                                    |
| RK-25  | Phones too slow for long runs                                                  | Work in Web Workers; resolution lowered rather than freezing; run times recorded (WEB-05)                                             |
| RK-26  | Emulator counts read as hardware speed                                         | Counts labelled as dynamic instruction counts; hardware figures only from Verilated cycles and synthesis (NUM-06)                     |
| RK-27  | Work waiting on the whole build                                                | Every cell of the build matrix proceeds alone; packets stay small enough for any implementer (INT-12)                                 |

# 15 Evidence register

The AyeKnow evidence for every claim this document makes about things
outside the harness. The harness’s own requirements and packets are all
at state defined. Rows marked as received are kept as R1 and R2 state
them and stay unverified until the packet named beside them runs.

| **Claim**                                                                                                                                                                                                                              | **Source**                                               | **Evidence state**                                                                                                           | **Checked by**                         |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|----------------------------------------|
| APCISR has a C implementation and a WebAssembly build with an execution trace                                                                                                                                                          | R2                                                       | Received; unverified                                                                                                         | P0.2, P0.3                             |
| A machine-stack explainer exposes the execution and rendering path, including APCISR’s internal state                                                                                                                                  | R2                                                       | Received; unverified; not in the author’s record                                                                             | P0.2                                   |
| AyeHandSum provides a dynamic alphabet, value assignment, a dynamic base, framing and reversible encoding                                                                                                                              | R2                                                       | Received; unverified. The author’s record places his AyeCode work in his ayehandsum or ayesha repositories (19 October 2026) | P0.2, P1.7                             |
| APCISR is the author’s text-mode renderer for Indic scripts on a 9-grid (3 × 3) theory, with its source in the APCISR folder of hindawiai/chintamani, and its page is to explain building APCISR for other scripts with the grid model | Author’s record (19 and 20 October 2026)                 | Stated by the author                                                                                                         | P0.2, P6.1                             |
| Hindawi’s shaili transducers compose, and run through their drivers                                                                                                                                                                    | Author’s record (29 August 2026)                         | Stated by the author                                                                                                         | P0.3                                   |
| Hindawi 2026.10 is released and minted beneath concept DOI 10.5281/zenodo.23424410                                                                                                                                                     | Author’s record (16 to 20 October 2026)                  | Stated by the author, from his release runs                                                                                  | P0.2                                   |
| paras published 58 of 71 stack packages as hmnsq forks, each with a branch per language converting back exactly; binutils-gdb, musl, newlib and bash stopped at the fork stage, rust at the clone, GNU make in BURP                    | Author’s record (22 October 2026)                        | Stated by the author, from his run                                                                                           | P0.2                                   |
| Firmware and the operating-system stack are already part of paras                                                                                                                                                                      | The author’s message of 4 November 2026                  | Stated by the author; which firmware and operating systems, for which targets, is recorded at intake                         | P0.2, P4.8                             |
| The ILM registry pinned in tajziya holds 7,867 languages and 226 scripts                                                                                                                                                               | Author’s record (28 September 2026)                      | Stated by the author                                                                                                         | P0.2                                   |
| Romenagri 2026.10 is seeded and timestamped, without a DOI                                                                                                                                                                             | Author’s record (20 October 2026)                        | Stated by the author                                                                                                         | P0.2                                   |
| The reference unit has 32 GB of memory                                                                                                                                                                                                 | R2                                                       | Conflicts with the author’s record of 16 GB DDR5                                                                             | P0.6                                   |
| Pushkalāvatī is a formal rule-system and verification reference for this work                                                                                                                                                          | R2                                                       | Not adopted; no relationship inferred                                                                                        | None                                   |
| QEMU registers RISC-V vendor-extension decoders under guards; gas accepts .insn for arbitrary encodings; open cores implement CV-X-IF; customasm assembles user-defined instruction sets                                               | Drafter’s knowledge                                      | Defined; each interface is read from the pinned source before use (GOV-15)                                                   | P0.4, P4.2, P4.3, P5.5, P7.3           |
| Licences of the external tools in section 8                                                                                                                                                                                            | Drafter’s record                                         | To be confirmed from each project’s licence file                                                                             | P0.4                                   |
| Landscape entries in section 5.4                                                                                                                                                                                                       | Drafter’s knowledge                                      | Not re-verified; no claim about current commercial status                                                                    | Refreshed at intake                    |
| NI2A2 is the embodiment branch of PEDLER leading to ANGEL                                                                                                                                                                              | A summary of the author’s conversation of 25 August 2026 | Recorded from a conversation summary; no repository found                                                                    | P0.2                                   |
| MSRR offers a route to modular physical and robotic systems                                                                                                                                                                            | R3                                                       | Received; unverified; not in the author’s record                                                                             | P0.2                                   |
| Panini Q is the author’s quantum-simulation realisation backend of PANINI, live and minted (10.5281/zenodo.23020648); version 0.3.0 was supplied on 4 October 2026                                                                     | Author’s record (28 September and 4 October 2026)        | Stated by the author                                                                                                         | P12.3                                  |
| BURP returns source code in Hindawi’s languages and back byte for byte and reports what is missing                                                                                                                                     | BURP’s package description (burp-ilm 2026.10.0)          | Stated by the author’s published package; its coverage of JavaScript is not established                                      | P9.1                                   |
| math.js parses expressions and solves ODEs; JSCAD exports STL and 3MF; the Modelica Standard Library models rotational backlash and friction; Project Chrono models gears; browser libraries import OpenQASM                           | Drafter’s knowledge                                      | Defined; each is read from the pinned source before use (GOV-15)                                                             | P9.1, P9.4, P10.6, P10.7, P10.8, P12.4 |
| A balanced ternary number system can be realised by mechanical positions                                                                                                                                                               | R3 §2                                                    | Received; realised in simulation by MEC-03                                                                                   | P10.3                                  |

# 16 Decisions

Each decision has a state. Ruled decisions are the author’s. Working
decisions stand for the build; the author reviews them once he has seen
the build run, and a change is recorded here with its date.

| **ID** | **Decision**                                               | **State**                                                       | **Value**                                                                                                                                                   |
|--------|------------------------------------------------------------|-----------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
| RD1    | Name of the harness                                        | Ruled by the author, 4 November 2026                            | repsynth                                                                                                                                                    |
| RD2    | Organisation                                               | Ruled by the author, 4 November 2026                            | hmnsq                                                                                                                                                       |
| RD3    | Vendor prefix for extension names                          | Working, reviewed once the build runs                           | xaye                                                                                                                                                        |
| RD4    | Memory of the reference unit                               | Settled by measurement (P0.6)                                   | As measured                                                                                                                                                 |
| RD5    | Binary and balanced ternary                                | Decided by the drafter at the author’s request, 4 November 2026 | Both run: binary is the performance baseline; balanced ternary is the representation-change demonstrator; one parametric Tier B family yields both machines |
| RD6    | Licence of generated hardware descriptions                 | Working; the author confirms at release                         | CERN-OHL-S-2.0, as proposed in jugaad28                                                                                                                     |
| RD7    | Publication of this document and of the harness            | The author’s act at release                                     | Unpublished until then                                                                                                                                      |
| RD8    | First working set of scripts                               | Working, reviewed once the build runs                           | As in SCR-05                                                                                                                                                |
| RD9    | Localisation of specifications through paras               | Working, reviewed once the build runs                           | After the first build (SPC-08 is a SHOULD)                                                                                                                  |
| RD10   | Names of the new repositories and their projection names   | Ruled by the author, 4 November 2026                            | As in the Repository Map                                                                                                                                    |
| RD11   | Machine unit for analogue patches                          | Working, reviewed once the build runs                           | Normalised 1, shown as ±10 V                                                                                                                                |
| RD12   | The browser quantum circuit library                        | Working; chosen at P12.4                                        | After the ingestibility probe                                                                                                                               |
| RD13   | Physical builds of mechanisms and patches as teaching labs | Working, reviewed once the build runs                           | Later; realisation models are produced now                                                                                                                  |
| RD14   | Timing of the optical lane                                 | Working, reviewed once the build runs                           | After M12                                                                                                                                                   |

# 17 Glossary

| **Term**                          | **Meaning**                                                                                                                              | **Nearest common term**                          |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------|
| AyeKnow states                    | The author’s states for claims about work: defined, implemented, executed, measured, verified, reproduced, open                          | Verification status                              |
| Oracle                            | A legacy implementation used, read-only, as the authority for what a representation does                                                 | Reference implementation; test oracle            |
| Representation specification      | One YAML document describing a representation in the sixteen sections of the meta-model                                                  | Data model; description language entry           |
| Reference function                | The single restricted-C11 definition of an operation’s meaning                                                                           | Golden model                                     |
| Slice                             | One addressable field of a specification, materialised as a file for the build executor                                                  | Fine-grained build input                         |
| Lane                              | A path from specifications to one family of targets, independent of other lanes                                                          | Pipeline                                         |
| Packet                            | A unit of work small enough for one working context, with its acceptance command                                                         | User story with an executable definition of done |
| Demonstrator                      | A programme-level acceptance case, D1 to D7                                                                                              | Acceptance test                                  |
| Tier A                            | Custom extensions to a RISC-V base profile                                                                                               | ISA extension                                    |
| Tier B                            | A standalone instruction set with its own QEMU target                                                                                    | New ISA                                          |
| Custom opcode space               | The opcode ranges the RISC-V specification reserves for non-standard extensions                                                          | Custom opcodes                                   |
| decodetree                        | QEMU’s generator of instruction decoders from pattern files                                                                              | Decoder generator                                |
| TCG helper                        | A C function that QEMU’s translator calls to perform an instruction                                                                      | Emulation helper                                 |
| TCG plugin                        | A QEMU plugin that observes execution; here it counts instructions                                                                       | Instrumentation plugin                           |
| .insn                             | The GNU assembler directive that emits an arbitrary RISC-V encoding                                                                      | Raw instruction directive                        |
| Intrinsic                         | A C function that wraps one instruction                                                                                                  | Builtin                                          |
| Machine-description pattern       | GCC’s description of an instruction for code generation                                                                                  | Instruction pattern                              |
| CV-X-IF                           | OpenHW’s interface for attaching custom-instruction coprocessors to RISC-V cores                                                         | Coprocessor interface                            |
| Allocation ledger                 | The record that fixes each instruction’s encoding once                                                                                   | Opcode map                                       |
| Expected-divergence set           | The differences a deliberate change is meant to cause against an oracle                                                                  | Expected diff                                    |
| Wheel census                      | The report of which external tool did the work at each layer                                                                             | Tool provenance                                  |
| Run record                        | The record of one run: inputs, tools, outputs, results and states                                                                        | Build record; attestation                        |
| paras                             | The author’s tool that ingests a repository into every Hindawi language, publishing forks with a branch per language                     | Localisation pipeline                            |
| Parashakti                        | The author’s sovereign stack through Hindawi, targeting the SHAKTI processor                                                             | Distribution                                     |
| BURP                              | The author’s Bidirectional Universal Resource Parser: ingestion and missing-item reports                                                 | Ingestion tool                                   |
| Shaili                            | A Hindawi programming-language style with its transducer and driver, for example guru for C                                              | Language front end                               |
| Romenagri                         | The author’s transliteration kernel: ASCII-7, diacritic-free, bijective and compiler-safe                                                | Transliteration scheme                           |
| 9-grid model                      | The author’s 3 × 3 grid theory underlying APCISR                                                                                         | Glyph composition model                          |
| ILM registry                      | Project ILM’s registry of languages and scripts, pinned in tajziya                                                                       | Language and script inventory                    |
| Evidence rungs                    | jugaad28’s ladder: CONCEPT, SPEC, RTL, VERIFIED, PHYSICAL, SIGNOFF, TAPEOUT, SILICON                                                     | Maturity ladder                                  |
| not_established                   | dhancha’s Unknown: a value that names what is missing and refuses arithmetic                                                             | Null that cannot be summed                       |
| needs labels                      | Capability labels on packets: needs:code, needs:proof, needs:ontology, needs:visual, needs:testing, needs:legal, needs:human             | Skill tags                                       |
| Substrate specification           | A YAML document describing a physical medium of computation in the sections of section 9.9                                               | Platform model                                   |
| Computational model specification | A substrate-independent description of a computation: state, transitions, inputs, outputs and semantics                                  | Model; program specification                     |
| Capability class                  | The compiler’s report for a model on a substrate: supported, supported with restrictions, approximate, simulation only or not realisable | Feasibility assessment                           |
| Machine unit                      | The full-scale value of an analogue computer’s variables                                                                                 | Reference voltage                                |
| Magnitude and time scaling        | Rescaling variables and time so a model fits a substrate’s ranges and speeds                                                             | Scaling                                          |
| Patch                             | An analogue computer program: elements, connections, coefficients and initial conditions                                                 | Netlist; patch-panel program                     |
| Mechanism configuration           | A mechanical computer program: shafts, gears, differentials, integrators, cams and counters                                              | Kinematic netlist                                |
| Differential analyser             | A machine of integrators coupled by shafts and gears, solving differential equations mechanically                                        | Mechanical analogue computer                     |
| Wheel-and-disc integrator         | A wheel on a turning disc whose rotation is the integral of its distance from the disc’s centre                                          | Mechanical integrator                            |
| Backlash                          | Free play between meshing parts                                                                                                          | Lost motion                                      |
| Admission state                   | A library’s state under WEB-03: admitted, pending BURP or rejected                                                                       | Dependency approval                              |
| BURP round trip                   | Ingesting a source into a Hindawi language and back, compared byte for byte                                                              | Lossless transformation test                     |
| Vendored source                   | Third-party source kept in the repository as readable files with licence and provenance                                                  | Vendored dependency                              |
| Web first                         | Built to run in a browser from static files, with no build step                                                                          | Static web application                           |
| OpenQASM 3                        | The open interchange language for quantum circuits                                                                                       | Quantum assembly                                 |
| Modelica                          | The open equation-based modelling language, simulated here with OpenModelica                                                             | Equation-based model                             |
| SPICE netlist                     | A circuit description for SPICE simulators such as ngspice                                                                               | Circuit netlist                                  |
| Bottom-up reference architecture  | An architecture set out from the physical layer upwards, naming what each layer holds and who provides it (document 00)                  | Full-stack reference architecture                |
| Build matrix                      | The cells of representation, substrate, target and language, each buildable on its own (document 00)                                     | Configuration matrix                             |
| Performance baseline              | The binary implementation of a computation on a target, beside which every other figure is reported                                      | Baseline                                         |
